package com.module06.logging;

import java.util.logging.ConsoleHandler;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

class ColorFormatter extends Formatter {
    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String YELLOW = "\u001B[33m";
    private static final String BLUE = "\u001B[34m";
    private static final String CYAN = "\u001B[36m";

    @Override
    public String format(LogRecord record) {
        String color;
        switch (record.getLevel().getName()) {
            case "SEVERE": color = RED; break;
            case "WARNING": color = YELLOW; break;
            case "INFO": color = CYAN; break;
            default: color = BLUE; break;
        }
        return color + "[" + record.getLevel() + "] "
                + formatMessage(record) + RESET + "\n";
    }
}

public class Exercise_07_Custom_Formatter {
	public static void main(String[] args) {
        // TODO: Set different log levels and observe which messages appear.
        Logger logger = Logger.getLogger(Exercise_03_LogLevelDemo.class.getName());
        logger.setUseParentHandlers(false);
        logger.setLevel(Level.FINE);
        
        
        ConsoleHandler handler = new ConsoleHandler();
        handler.setFormatter(new ColorFormatter());
        handler.setLevel(Level.FINE);
        logger.addHandler(handler);

        logger.severe("SEVERE message");
        logger.warning("WARNING message");
        logger.info("INFO message");
        logger.config("CONFIG message");
        logger.fine("FINE message");
        logger.finer("FINER message");
        logger.finest("FINEST message");
    }
	
}
