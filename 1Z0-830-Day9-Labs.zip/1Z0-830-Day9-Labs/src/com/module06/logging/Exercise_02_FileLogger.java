package com.module06.logging;

import java.util.logging.*;
import java.io.IOException;

public class Exercise_02_FileLogger {
    public static void main(String[] args) {
        // TODO: Log messages to both console and file using appropriate handlers.
        Logger logger = Logger.getLogger("DemoLogger");
        try {
            // Create file handler with append mode
            FileHandler fileHandler = new FileHandler("app.log", true);
            fileHandler.setFormatter(new SimpleFormatter());

            // Add handlers
            logger.addHandler(fileHandler);
            logger.addHandler(new ConsoleHandler());

            logger.info("File and Console Logging Initialized");
            logger.warning("Sample warning message");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
