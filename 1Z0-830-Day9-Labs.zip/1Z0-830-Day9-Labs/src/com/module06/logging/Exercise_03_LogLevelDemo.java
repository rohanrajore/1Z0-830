package com.module06.logging;

import java.util.logging.*;

public class Exercise_03_LogLevelDemo {
    public static void main(String[] args) {
        // TODO: Set different log levels and observe which messages appear.
        Logger logger = Logger.getLogger(Exercise_03_LogLevelDemo.class.getName());
        logger.setUseParentHandlers(false);
        logger.setLevel(Level.FINER);
        
        
        ConsoleHandler handler = new ConsoleHandler();
        //handler.setLevel(Level.FINE);
        logger.addHandler(handler);

        logger.severe("SEVERE message");
        logger.warning("WARNING message");
        logger.info("INFO message");
        logger.config("CONFIG message");
        logger.fine("FINE message");
        logger.finer("FINER message");
        logger.finest("FINEST message");
    }
}
