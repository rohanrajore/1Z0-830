package com.module06.logging;

import java.util.logging.*;

public class Exercise_06_CertificationPractice {
    private static final Logger logger = Logger.getLogger(Exercise_06_CertificationPractice.class.getName());

    public static void main(String[] args) {
        // TODO: Explain difference between logger.info() and logger.log(Level.INFO, message).
        logger.info("This message uses info() - equivalent to Level.INFO with automatic formatting.");
        logger.log(Level.INFO, "This message uses log(Level.INFO, message) - allows explicit level and control.");
        
        try {
            int x = 10 / 0;
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Exception occurred", e);
        }
    }
}
