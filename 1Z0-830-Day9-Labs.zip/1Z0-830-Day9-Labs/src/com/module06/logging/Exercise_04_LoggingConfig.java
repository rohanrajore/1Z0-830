package com.module06.logging;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.*;

public class Exercise_04_LoggingConfig {
    public static void main(String[] args) {
        // TODO: Load logging configuration from a file and test various levels.
        try {
            LogManager.getLogManager().readConfiguration(new FileInputStream("logging.properties"));
            Logger logger = Logger.getLogger(Exercise_04_LoggingConfig.class.getName());
            logger.finest("This is FINEST message");
            logger.fine("This is FINE message");
            logger.info("This is INFO message");
            logger.warning("This is WARNING message");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
