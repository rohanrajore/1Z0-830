package com.module06.logging;

import java.util.logging.*;

public class Exercise_01_LoggingIntro {
    private static final Logger logger = Logger.getLogger(Exercise_01_LoggingIntro.class.getName());

    public static void main(String[] args) {
        // TODO: Create a simple logger and print informational and warning messages.
        logger.info("Application started successfully.");
        logger.warning("Low memory detected, please monitor usage.");
        logger.info("Application finished execution.");
    }
}
