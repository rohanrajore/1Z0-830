package com.module06.logging;

import java.util.logging.*;

public class Exercise_05_ExceptionLogger {
    private static final Logger logger = Logger.getLogger(Exercise_05_ExceptionLogger.class.getName());

    public static void main(String[] args) {
        // TODO: Log exceptions using logger.log(Level.SEVERE, message, exception)
        try {
            int result = 10 / 0;
            System.out.println(result);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Exception occurred during division operation", e);
        }
    }
}
