package com.module02.concurrency_advanced;

import java.util.concurrent.Semaphore;

public class Exercise_05_SemaphoreExample {
    public static void main(String[] args) {
        // TODO: Simulate a download manager where only two files can be downloaded concurrently using Semaphore
        Semaphore sem = new Semaphore(2);
        for (int i = 1; i <= 5; i++) {
            int fileId = i;
            new Thread(() -> {
                try {
                    sem.acquire();
                    System.out.println("Downloading file " + fileId + " by " + Thread.currentThread().getName());
                    Thread.sleep(1000);
                } catch (InterruptedException ignored) {}
                finally {
                    sem.release();
                    System.out.println("Completed file " + fileId);
                }
            }, "Downloader-" + i).start();
        }
    }
}
