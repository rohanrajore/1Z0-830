package com.module02.concurrency_advanced;

import java.util.concurrent.*;

public class Exercise_07_ProducerConsumer {
    public static void main(String[] args) {
        // TODO: Implement a producer-consumer example using LinkedBlockingQueue
        BlockingQueue<String> queue = new LinkedBlockingQueue<>(2);

        Thread producer = new Thread(() -> {
            try {
                for (char c = 'A'; c <= 'D'; c++) {
                    queue.put(String.valueOf(c));
                    System.out.println("Produced: " + c);
                    Thread.sleep(200);
                }
            } catch (InterruptedException ignored) {}
        });

        Thread consumer = new Thread(() -> {
            try {
                while (true) {
                    String item = queue.take();
                    System.out.println("Consumed: " + item);
                    Thread.sleep(300);
                }
            } catch (InterruptedException ignored) {}
        });

        producer.start();
        consumer.start();
    }
}
