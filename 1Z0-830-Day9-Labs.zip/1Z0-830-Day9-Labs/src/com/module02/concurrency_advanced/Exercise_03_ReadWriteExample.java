package com.module02.concurrency_advanced;

import java.util.concurrent.locks.*;

public class Exercise_03_ReadWriteExample {
    private static final ReadWriteLock rwLock = new ReentrantReadWriteLock();
    private static String cachedData = "Initial";

    public static void main(String[] args) {
        // TODO: Implement a cache using ReadWriteLock where multiple threads can read but only one can update
        Runnable reader = () -> {
            rwLock.readLock().lock();
            try {
                System.out.println(Thread.currentThread().getName() + " reads: " + cachedData);
                Thread.sleep(100);
            } catch (InterruptedException ignored) {} 
            finally { rwLock.readLock().unlock(); }
        };

        Runnable writer = () -> {
            rwLock.writeLock().lock();
            try {
                cachedData = "Updated by " + Thread.currentThread().getName();
                System.out.println(Thread.currentThread().getName() + " updated data");
            } finally { rwLock.writeLock().unlock(); }
        };

        new Thread(reader, "Reader-1").start();
        new Thread(reader, "Reader-2").start();
        new Thread(writer, "Writer-1").start();
    }
}
