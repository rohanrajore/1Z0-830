package com.module02.concurrency_advanced;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class Exercise_02_TryLockExample {
    private static final ReentrantLock lock = new ReentrantLock(true);

    public static void main(String[] args) {
        // TODO: Simulate multiple threads attempting to acquire a shared lock with a timeout using tryLock()
        Runnable task = () -> {
            try {
                if (lock.tryLock(200, TimeUnit.MILLISECONDS)) {
                    try {
                        System.out.println(Thread.currentThread().getName() + " acquired lock");
                        Thread.sleep(300);
                    } finally {
                        lock.unlock();
                        System.out.println(Thread.currentThread().getName() + " released lock");
                    }
                } else {
                    System.out.println(Thread.currentThread().getName() + " could not acquire lock");
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        };

        for (int i = 0; i < 4; i++) {
            new Thread(task, "Worker-" + i).start();
        }
    }
}
