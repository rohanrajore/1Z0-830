package com.module02.concurrency_advanced;

import java.util.concurrent.*;

public class Exercise_09_CombineFutures {
    public static void main(String[] args) {
        // TODO: Run two asynchronous computations and combine their results using thenCombine()
        CompletableFuture<Integer> f1 = CompletableFuture.supplyAsync(() -> 10);
        CompletableFuture<Integer> f2 = CompletableFuture.supplyAsync(() -> 20);

        f1.thenCombine(f2, Integer::sum)
          .thenAccept(sum -> System.out.println("Combined result: " + sum))
          .join();
    }
}
