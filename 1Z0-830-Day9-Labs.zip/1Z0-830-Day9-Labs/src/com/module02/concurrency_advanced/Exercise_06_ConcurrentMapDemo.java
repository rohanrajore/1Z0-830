package com.module02.concurrency_advanced;

import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public class Exercise_06_ConcurrentMapDemo {
    public static void main(String[] args) throws InterruptedException {
        // TODO: Use ConcurrentHashMap to count word frequencies from multiple threads safely
        ConcurrentMap<String, Integer> map = new ConcurrentHashMap<>();
        List<String> words = Arrays.asList("java", "lock", "thread", "java", "map", "thread", "java");

        Runnable task = () -> words.forEach(word -> map.merge(word, 1, Integer::sum));

        Thread t1 = new Thread(task);
        Thread t2 = new Thread(task);
        t1.start();
        t2.start();
        t1.join();
        t2.join();

        System.out.println("Word counts: " + map.entrySet().stream()
                .map(e -> e.getKey() + "=" + e.getValue())
                .collect(Collectors.joining(", ")));
    }
}
