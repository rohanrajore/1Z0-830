package com.module02.concurrency_advanced;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.IntStream;

public class Exercise_01_LockDemo {
    private static int counter = 0;
    private static final Lock lock = new ReentrantLock();

    public static void main(String[] args) throws InterruptedException {
        // TODO: Use ReentrantLock to protect a shared counter. Start multiple threads incrementing it safely.
        Runnable task = () -> {
            IntStream.range(0, 1000).forEach(i -> {
                lock.lock();
                try {
                    counter++;
                } finally {
                    lock.unlock();
                }
            });
        };

        Thread t1 = new Thread(task);
        Thread t2 = new Thread(task);
        t1.start();
        t2.start();
        t1.join();
        t2.join();

        System.out.println("Final counter value: " + counter);
    }
}
