package com.module02.concurrency_advanced;

import java.util.concurrent.*;

public class Exercise_08_FutureChain {
    public static void main(String[] args) {
        // TODO: Create a CompletableFuture chain that loads data, transforms it, and prints it asynchronously
        CompletableFuture.supplyAsync(() -> "Learnato Platform")
                .thenApply(String::toUpperCase)
                .thenApply(data -> data + " - Powered by Java")
                .thenAccept(System.out::println)
                .join();
    }
}
