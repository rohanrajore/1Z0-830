package com.module02.concurrency_advanced;

import java.util.concurrent.*;

public class Exercise_04_LatchBarrierDemo {
    public static void main(String[] args) throws Exception {
        // TODO: Demonstrate the difference between CountDownLatch and CyclicBarrier
        CountDownLatch latch = new CountDownLatch(3);
        CyclicBarrier barrier = new CyclicBarrier(3, () -> System.out.println("Barrier reached!"));

        for (int i = 0; i < 3; i++) {
            int id = i;
            new Thread(() -> {
                try {
                    Thread.sleep(200 * id);
                    System.out.println("Worker " + id + " done with task");
                    latch.countDown();
                    barrier.await();
                } catch (Exception ignored) {}
            }).start();
        }

        latch.await();
        System.out.println("All workers finished using CountDownLatch");
    }
}
