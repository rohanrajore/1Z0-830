package com.module02.concurrency_advanced;

public class Exercise_10_CertificationPractice {
    public static void main(String[] args) {
        // TODO: Identify which concurrency utility (Lock, Semaphore, Barrier, or Future) fits each scenario
        System.out.println("Lock → Fine-grained control for mutual exclusion.");
        System.out.println("Semaphore → Control access to limited resources.");
        System.out.println("Barrier → Synchronize multiple threads reaching a common point.");
        System.out.println("Future → Retrieve results of asynchronous computations.");
    }
}
