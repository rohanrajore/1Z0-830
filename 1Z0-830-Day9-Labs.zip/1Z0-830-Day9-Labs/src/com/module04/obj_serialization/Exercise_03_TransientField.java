package com.module04.obj_serialization;

import java.io.*;

class Account implements Serializable {
    private static final long serialVersionUID = 2L;
    String username;
    transient String password;

    Account(String username, String password) {
        this.username = username;
        this.password = password;
    }

    @Override
    public String toString() {
        return "Account{username='" + username + "', password='" + password + "'}";
    }
}

public class Exercise_03_TransientField {
    public static void main(String[] args) throws Exception {
        // TODO: Serialize an object containing a transient field and verify its value after deserialization
        Account acc = new Account("user1", "secret");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("account.ser"))) {
            oos.writeObject(acc);
        }
        System.out.println("Serialized: " + acc);

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("account.ser"))) {
            Account restored = (Account) ois.readObject();
            System.out.println("Deserialized: " + restored);
        }
    }
}
