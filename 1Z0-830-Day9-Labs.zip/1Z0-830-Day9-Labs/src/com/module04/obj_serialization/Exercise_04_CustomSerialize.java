package com.module04.obj_serialization;

import java.io.*;

class User implements Serializable {
    private static final long serialVersionUID = 3L;
    private String name;
    private transient String password;

    public User(String name, String password) {
        this.name = name;
        this.password = password;
    }

    
//    defaultWriteObject() → asks Java to perform normal serialization for the non-transient fields (name).
//    Then it manually writes a modified version of password to the stream — here, just prefixing it with "ENC:" as a toy example of “encryption.”
//    So instead of saving "mypassword", it writes "ENC:mypassword" to the file.
    private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
        oos.writeObject("ENC:" + password);
    }

    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        ois.defaultReadObject();
        String enc = (String) ois.readObject();
        password = enc.substring(4);
    }

    @Override
    public String toString() {
        return "User{name='" + name + "', password='" + password + "'}";
    }
}

public class Exercise_04_CustomSerialize {
    public static void main(String[] args) throws Exception {
        // TODO: Implement custom serialization to encrypt and decrypt a password field
        User u = new User("Rohan", "mypassword");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("user.ser"))) {
            oos.writeObject(u);
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("user.ser"))) {
            User restored = (User) ois.readObject();
            System.out.println("Restored: " + restored);
        }
    }
}
