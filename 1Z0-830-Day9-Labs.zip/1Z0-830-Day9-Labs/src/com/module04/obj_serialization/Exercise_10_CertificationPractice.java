package com.module04.obj_serialization;

public class Exercise_10_CertificationPractice {
    public static void main(String[] args) {
        // TODO: Explain what happens if a transient field is modified after serialization but before deserialization
        System.out.println("Transient fields are not serialized.");
        System.out.println("If modified after serialization but before deserialization,");
        System.out.println("the deserialized object will not reflect those changes — it resets to default value.");
    }
}
