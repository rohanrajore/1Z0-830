package com.module04.obj_serialization;

import java.io.*;

class EmployeeExternal implements Externalizable {
    String name;
    int id;

    public EmployeeExternal() {} // Required public no-arg constructor

    public EmployeeExternal(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(name);
        out.writeInt(id);
    }

    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        name = (String) in.readObject();
        id = in.readInt();
    }

    public String toString() { return "EmployeeExternal{name='" + name + "', id=" + id + "}"; }
}

public class Exercise_07_ExternalizableDemo {
    public static void main(String[] args) throws Exception {
        // TODO: Implement an Externalizable class and manually write and read all its fields
        EmployeeExternal emp = new EmployeeExternal("Ravi", 101);
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("employee_ext.ser"))) {
            oos.writeObject(emp);
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("employee_ext.ser"))) {
            System.out.println("Restored: " + (EmployeeExternal) ois.readObject());
        }
    }
}
