package com.module04.obj_serialization;

import java.io.*;

class SecureConfig implements Serializable {
    private static final long serialVersionUID = 6L;
    private String configName;

    SecureConfig(String name) { this.configName = name; }

    private void writeObject(ObjectOutputStream out) throws IOException {
        throw new NotSerializableException("Serialization not allowed for this class");
    }
}

public class Exercise_06_BlockSerialization {
    public static void main(String[] args) {
        // TODO: Implement a class that explicitly blocks its serialization and test the exception
        SecureConfig sc = new SecureConfig("AdminSettings");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("config.ser"))) {
            oos.writeObject(sc);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
