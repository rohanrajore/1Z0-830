package com.module04.obj_serialization;

import java.io.*;

class StudentV1 implements Serializable {
    private static final long serialVersionUID = 1001L;
    String name;

    StudentV1(String name) { this.name = name; }
    
    @Override
	public String toString() {
		return "StudentV1 [name=" + name + "]";
	}

}

public class Exercise_02_VersionConflict {
    public static void main(String[] args) throws Exception {
        // TODO: Change class structure and observe effect of missing/mismatched serialVersionUID
//        StudentV1 s1 = new StudentV1("Amit");
//        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("studentV1.ser"))) {
//            oos.writeObject(s1);
//        }

        System.out.println("Now, modify the class (add/remove fields or change UID) and try to deserialize.");
        System.out.println("Observe InvalidClassException if serialVersionUID mismatches.");
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("studentV1.ser"))) {
            StudentV1 s2 = (StudentV1) ois.readObject();
            System.out.println("Deserialized object: " + s2.toString());
        } catch (InvalidClassException e) {
            System.out.println("Version mismatch! serialVersionUID differs from the original class.");
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            System.out.println("Serialized file not found. Please run the serializer first.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
