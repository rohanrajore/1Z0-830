package com.module04.obj_serialization;

import java.io.*;

class StudentV1 implements Serializable {
    private static final long serialVersionUID = 1001L;
    String name;

    StudentV1(String name) { this.name = name; }
}

public class Exercise_02_VersionConflict {
    public static void main(String[] args) throws Exception {
        // TODO: Change class structure and observe effect of missing/mismatched serialVersionUID
        StudentV1 s1 = new StudentV1("Amit");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("studentV1.ser"))) {
            oos.writeObject(s1);
        }

        System.out.println("Now, modify the class (add/remove fields or change UID) and try to deserialize.");
        System.out.println("Observe InvalidClassException if serialVersionUID mismatches.");
    }
}
