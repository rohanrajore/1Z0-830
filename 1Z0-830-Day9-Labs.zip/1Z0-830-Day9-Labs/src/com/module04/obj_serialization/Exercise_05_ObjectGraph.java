package com.module04.obj_serialization;

import java.io.*;

class Employee implements Serializable {
    private static final long serialVersionUID = 4L;
    String name;
    Employee(String name) { this.name = name; }
}

class Department implements Serializable {
    private static final long serialVersionUID = 5L;
    String deptName;
    Employee emp;

    Department(String deptName, Employee emp) {
        this.deptName = deptName;
        this.emp = emp;
    }
}

public class Exercise_05_ObjectGraph {
    public static void main(String[] args) throws Exception {
        // TODO: Create a Department object containing an Employee and serialize the entire hierarchy
        Department d = new Department("Engineering", new Employee("John"));
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("dept.ser"))) {
            oos.writeObject(d);
        }
        System.out.println("Department and Employee serialized successfully.");
    }
}
