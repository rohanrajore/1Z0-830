package com.module04.obj_serialization;

import java.io.*;

class SerializableEmp implements Serializable {
    private static final long serialVersionUID = 7L;
    String name = "SerializableEmp";
}

class ExternalizableEmp implements Externalizable {
    String name = "ExternalizableEmp";

    public ExternalizableEmp() {}

    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(name);
    }

    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        name = (String) in.readObject();
    }
}

public class Exercise_08_CompareInterfaces {
    public static void main(String[] args) throws Exception {
        // TODO: Demonstrate both interfaces and identify when Externalizable provides performance benefits
        SerializableEmp sEmp = new SerializableEmp();
        ExternalizableEmp eEmp = new ExternalizableEmp();

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("compare.ser"))) {
            long start = System.nanoTime();
            oos.writeObject(sEmp);
            oos.writeObject(eEmp);
            long end = System.nanoTime();
            System.out.println("Serialization time (ns): " + (end - start));
        }
    }
}
