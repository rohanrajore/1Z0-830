package com.module04.obj_serialization;

import java.io.*;

class Singleton implements Serializable {
    private static final long serialVersionUID = 8L;
    private static final Singleton INSTANCE = new Singleton();

    private Singleton() {}

    public static Singleton getInstance() {
        return INSTANCE;
    }

    protected Object readResolve() {
        return INSTANCE;
    }
}

public class Exercise_09_SingletonSerialize {
    public static void main(String[] args) throws Exception {
        // TODO: Implement a serializable singleton and use readResolve() to maintain the single instance
        Singleton s1 = Singleton.getInstance();
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("singleton.ser"))) {
            oos.writeObject(s1);
        }

        Singleton s2;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("singleton.ser"))) {
            s2 = (Singleton) ois.readObject();
        }

        System.out.println("s1 hash: " + s1.hashCode() + ", s2 hash: " + s2.hashCode());
        System.out.println("Same instance? " + (s1 == s2));
    }
}
