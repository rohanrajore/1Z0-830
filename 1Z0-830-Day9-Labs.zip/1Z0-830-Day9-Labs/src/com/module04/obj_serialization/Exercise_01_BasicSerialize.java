package com.module04.obj_serialization;

import java.io.*;

class Student implements Serializable {
    private static final long serialVersionUID = 1L;
    String name;
    int age;

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{name='" + name + "', age=" + age + "}";
    }
}

public class Exercise_01_BasicSerialize {
    public static void main(String[] args) {
        // TODO: Create a Student class and serialize it to a file named student.ser
        Student s = new Student("Rohan", 20);
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("student.ser"))) {
            oos.writeObject(s);
            System.out.println("Student serialized: " + s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
