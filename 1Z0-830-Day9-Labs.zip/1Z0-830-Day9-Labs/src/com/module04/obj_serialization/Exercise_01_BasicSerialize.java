package com.module04.obj_serialization;

import java.io.*;

class Student implements Serializable {
    private static final long serialVersionUID = 1L;
    String name;
    int age;

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{name='" + name + "', age=" + age + "}";
    }
}

public class Exercise_01_BasicSerialize {
    public static void main(String[] args) {
        // TODO: Create a Student class and serialize it to a file named student.ser
        Student s = new Student("Rohan", 20);
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("student.ser"))) {
            oos.writeObject(s);
            System.out.println("Student serialized: " + s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}



//1️⃣ new FileOutputStream("student.ser")
//
//This part creates a byte stream connected to a physical file on disk.
//
//FileOutputStream is a low-level output stream that writes raw bytes.
//
//"student.ser" is the file where the serialized data will be stored.
//
//If the file doesn’t exist, it’s created automatically (unless permissions prevent it).
//
//At this point, you could write bytes like this:
//
//FileOutputStream fos = new FileOutputStream("student.ser");
//fos.write(65);  // writes ASCII 'A'
//fos.close();
//
//
//But that only writes raw bytes — not entire objects.
//
//2️⃣ Wrapping it inside new ObjectOutputStream(...)
//
//Now you wrap that file stream with an ObjectOutputStream, which adds a higher-level feature:
//
//It can write whole Java objects — not just bytes.
//
//This stream converts an object into a byte sequence following Java’s serialization format.
//
//That means it captures:
//
//The object’s class name
//
//Field values
//
//Class version (serialVersionUID)
//
//Type information (for deserialization later)