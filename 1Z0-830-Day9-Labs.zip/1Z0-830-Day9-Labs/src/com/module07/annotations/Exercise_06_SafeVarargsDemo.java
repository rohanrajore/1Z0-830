package com.module07.annotations;

import java.util.Arrays;

public class Exercise_06_SafeVarargsDemo {
    @SafeVarargs
    public static <T> void printAll(T... elements) {
        // TODO: Create a generic varargs method and annotate it with @SafeVarargs.
        Arrays.stream(elements).forEach(System.out::println);
    }

    public static void main(String[] args) {
        printAll("Java", "Annotations", "Demo");
        printAll(1, 2, 3, 4, 5);
    }
}

//
//🧠 Why Varargs Cause Trouble
//When you use varargs:
//
//<T> void method(T... args)

//the compiler turns that into something like:
//
//<T> void method(T[] args)
//But arrays and generics behave differently:
//Arrays are covariant (you can assign a String[] to an Object[]).
//Generics are invariant (you can’t assign List<String> to List<Object>).
//That mismatch leads to possible type confusion when generics meet varargs.
//
//✅ The Role of @SafeVarargs
//The annotation tells the compiler:
//“I, the developer, promise that this varargs method doesn’t perform any unsafe operations that could lead to heap pollution.”
//Once you add it, the compiler stops issuing warnings about unsafe generic varargs usage.
//It’s essentially a trusted declaration of safety.
//
//🧩 When You Can Use It
//Only on:
//Static methods
//Final instance methods
//Constructors
//
//Why not others?
//Because non-final instance methods can be overridden, and an override might introduce unsafe behavior — breaking the safety guarantee.