package com.module07.annotations;

public class Exercise_04_DeprecatedExample {
    @Deprecated
    void oldMethod() {
        // TODO: Mark an old method as deprecated and suggest a new replacement.
        System.out.println("This is a deprecated method. Use newMethod() instead.");
    }

    void newMethod() {
        System.out.println("This is the new replacement method.");
    }

    public static void main(String[] args) {
        Exercise_04_DeprecatedExample ex = new Exercise_04_DeprecatedExample();
        ex.oldMethod();
        ex.newMethod();
    }
}
