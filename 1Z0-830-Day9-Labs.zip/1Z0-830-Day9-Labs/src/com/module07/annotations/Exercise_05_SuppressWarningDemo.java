package com.module07.annotations;

public class Exercise_05_SuppressWarningDemo {

    // 1️⃣ A deprecated method (simulating old API)
    @Deprecated
    static void oldLoginAPI() {
        System.out.println("Using old login API...");
    }

    // 2️⃣ A method that uses the deprecated API WITHOUT suppression
    public static void useDeprecatedWithoutSuppression() {
        oldLoginAPI();  // ⚠️ Compiler warning: oldLoginAPI() is deprecated
    }

    // 3️⃣ The same thing, but WITH suppression
    @SuppressWarnings("deprecation")
    public static void useDeprecatedWithSuppression() {
        oldLoginAPI();  // ✅ No warning now
    }

    public static void main(String[] args) {
        useDeprecatedWithoutSuppression();
        useDeprecatedWithSuppression();
    }
}
