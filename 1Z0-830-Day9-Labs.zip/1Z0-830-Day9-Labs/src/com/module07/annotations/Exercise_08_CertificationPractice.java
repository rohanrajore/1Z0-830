package com.module07.annotations;

public class Exercise_08_CertificationPractice {
    public static void main(String[] args) {
        // TODO: Identify which annotations apply compile-time vs runtime and which allow multiple targets.
        System.out.println("Compile-time annotations: @Override, @FunctionalInterface, @SuppressWarnings");
        System.out.println("Runtime annotations: Custom annotations with RUNTIME retention like @Author");
        System.out.println("@SafeVarargs applies to static, final, or constructor methods only.");
    }
}
