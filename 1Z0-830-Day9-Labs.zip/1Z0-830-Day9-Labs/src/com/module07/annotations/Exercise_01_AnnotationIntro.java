package com.module07.annotations;

public class Exercise_01_AnnotationIntro {
    @Override
    public String toString() {
        // TODO: Create a class with annotated methods using @Override.
        return "Annotation Example";
    }

    public static void main(String[] args) {
        Exercise_01_AnnotationIntro obj = new Exercise_01_AnnotationIntro();
        System.out.println(obj);
    }
}
