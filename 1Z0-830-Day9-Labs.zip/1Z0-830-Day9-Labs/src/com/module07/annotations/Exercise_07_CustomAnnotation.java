package com.module07.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

// TODO: Define and use a custom annotation to tag author and date information.
@Retention(RetentionPolicy.RUNTIME)
@interface Author {
    String name();
    String date() default "N/A";
}

@Author(name = "Rohan Rajore", date = "2025-10-29")
public class Exercise_07_CustomAnnotation {
    public static void main(String[] args) {
        Author author = Exercise_07_CustomAnnotation.class.getAnnotation(Author.class);
        System.out.println("Author: " + author.name());
        System.out.println("Date: " + author.date());
    }
}
