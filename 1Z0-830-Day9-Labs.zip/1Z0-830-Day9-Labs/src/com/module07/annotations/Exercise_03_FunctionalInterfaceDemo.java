package com.module07.annotations;

@FunctionalInterface
interface Calculator {
    int add(int a, int b);
}

public class Exercise_03_FunctionalInterfaceDemo {
    public static void main(String[] args) {
        // TODO: Create a @FunctionalInterface and implement it using a lambda expression.
        Calculator calc = (a, b) -> a + b;
        System.out.println("Sum: " + calc.add(10, 20));
    }
}
