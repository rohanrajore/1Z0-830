package com.module07.annotations;

class Parent {
    void greet() {
        System.out.println("Hello from Parent");
    }
}

class Child extends Parent {
    @Override
    void greet() {
//  @Override  	
//  void greet(int x) {
        // TODO: Override a method from a parent class and verify compiler enforcement.
        System.out.println("Hello from Child");
    }
}

public class Exercise_02_OverrideDemo {
    public static void main(String[] args) {
        Parent p = new Child();
        p.greet();
    }
}
