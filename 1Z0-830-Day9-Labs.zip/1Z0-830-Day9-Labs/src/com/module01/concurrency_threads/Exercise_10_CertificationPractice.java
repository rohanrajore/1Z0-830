package com.module01.concurrency_threads;

import java.util.concurrent.*;

public class Exercise_10_CertificationPractice {
    public static void main(String[] args) throws Exception {
        // TODO: Identify the output and state transitions for a multithreaded program using Thread, Runnable, and ExecutorService
        Thread t = new Thread(() -> System.out.println("Thread running"));
        t.start();

        Runnable r = () -> System.out.println("Runnable running");
        new Thread(r).start();

        ExecutorService exec = Executors.newSingleThreadExecutor();
        Future<String> result = exec.submit(() -> "Task done");
        System.out.println(result.get());

        exec.shutdown();
    }
}
