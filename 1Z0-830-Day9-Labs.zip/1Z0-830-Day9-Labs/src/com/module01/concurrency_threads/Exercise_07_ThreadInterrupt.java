package com.module01.concurrency_threads;

public class Exercise_07_ThreadInterrupt {
    public static void main(String[] args) throws InterruptedException {
        // TODO: Implement a long-running loop that gracefully stops when interrupted
        Thread worker = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                System.out.println("Working...");
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            System.out.println("Worker stopped.");
        });

        worker.start();
        Thread.sleep(1000);
        worker.interrupt();
    }
}
