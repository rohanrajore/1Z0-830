package com.module01.concurrency_threads;

public class Exercise_07_ThreadInterrupt {
    public static void main(String[] args) throws InterruptedException {
        // TODO: Implement a long-running loop that gracefully stops when interrupted
        Thread worker = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                System.out.println("Working...");
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            System.out.println("Worker stopped.");
        });

        worker.start();
        Thread.sleep(1000);
        worker.interrupt();
    }
}


//When a thread is sleeping, waiting, or blocking, and you interrupt it, Java throws an InterruptedException.
//But here’s the subtle part:
//
//When that exception is thrown, Java automatically clears the interrupt flag on the thread.
//
//That means, after the catch, Thread.currentThread().isInterrupted() will return false again — as if the interrupt never happened.
//
//So, if you want the thread to know it was interrupted and stop gracefully after the catch block, you must re-set the flag manually:
//
//catch (InterruptedException e) {
//    Thread.currentThread().interrupt(); // put the flag back to true
//}
//
//
//This way, the loop condition
//
//while (!Thread.currentThread().isInterrupted())
//
//
//becomes false, and the thread exits.