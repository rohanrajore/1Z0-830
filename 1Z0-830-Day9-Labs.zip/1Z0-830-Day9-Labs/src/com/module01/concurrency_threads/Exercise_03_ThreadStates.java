package com.module01.concurrency_threads;

public class Exercise_03_ThreadStates {
    public static void main(String[] args) throws InterruptedException {
        // TODO: Print messages from within different thread lifecycle stages to observe transitions
        Thread t = new Thread(() -> System.out.println("Thread running..."));
        System.out.println("State before start: " + t.getState());
        t.start();
        System.out.println("State after start: " + t.getState());
        t.join();
        System.out.println("State after completion: " + t.getState());
    }
}
