package com.module01.concurrency_threads;

public class Exercise_04_ThreadNaming {
    public static void main(String[] args) {
        // TODO: Create three threads with custom names and different priorities. Observe execution order.
        Runnable task = () -> System.out.println("Running: " + Thread.currentThread().getName());

        Thread t1 = new Thread(task, "Learnato-Low");
        Thread t2 = new Thread(task, "Learnato-Normal");
        Thread t3 = new Thread(task, "Learnato-High");

        t1.setPriority(Thread.MIN_PRIORITY);
        t2.setPriority(Thread.NORM_PRIORITY);
        t3.setPriority(Thread.MAX_PRIORITY);

        t1.start();
        t2.start();
        t3.start();
    }
}
