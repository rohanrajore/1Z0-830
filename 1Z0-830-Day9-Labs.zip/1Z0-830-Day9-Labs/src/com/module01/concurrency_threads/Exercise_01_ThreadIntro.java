package com.module01.concurrency_threads;

public class Exercise_01_ThreadIntro {
    public static void main(String[] args) {
        // TODO: Create a program that prints messages from the main thread and a worker thread simultaneously
        System.out.println("Main thread starts");

        Thread worker = new Thread(() -> {
            for (int i = 0; i < 5; i++) {
                System.out.println("Worker thread running: " + i);
            }
        });
        worker.start();

        for (int i = 0; i < 5; i++) {
            System.out.println("Main thread running: " + i);
        }
    }
}
