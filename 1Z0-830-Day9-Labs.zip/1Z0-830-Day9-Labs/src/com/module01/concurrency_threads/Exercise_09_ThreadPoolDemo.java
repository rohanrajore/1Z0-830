package com.module01.concurrency_threads;

import java.util.concurrent.*;

public class Exercise_09_ThreadPoolDemo {
    public static void main(String[] args) {
        // TODO: Submit multiple tasks to a fixed thread pool and observe parallel execution
        ExecutorService pool = Executors.newFixedThreadPool(3);
        for (int i = 0; i < 5; i++) {
            pool.submit(() -> System.out.println("Running in: " + Thread.currentThread().getName()));
        }
        pool.shutdown();
    }
}
