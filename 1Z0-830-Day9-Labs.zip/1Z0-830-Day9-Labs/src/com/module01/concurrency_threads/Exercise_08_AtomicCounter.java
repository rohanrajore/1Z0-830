package com.module01.concurrency_threads;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

public class Exercise_08_AtomicCounter {
    public static void main(String[] args) {
        // TODO: Use AtomicInteger to count increments safely across multiple threads
        AtomicInteger counter = new AtomicInteger(0);
        IntStream.range(0, 1000).parallel().forEach(i -> counter.incrementAndGet());
        System.out.println("Final atomic counter value: " + counter.get());
    }
}
