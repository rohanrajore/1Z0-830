package com.module01.concurrency_threads;

class SubclassThread extends Thread {
    public void run() {
        System.out.println("Thread via subclass: " + Thread.currentThread().getName());
    }
}

public class Exercise_02_ThreadRun {
    public static void main(String[] args) {
        // TODO: Create two threads using both the subclass and Runnable approaches
        Thread t1 = new SubclassThread();
        Thread t2 = new Thread(() -> System.out.println("Thread via Runnable: " + Thread.currentThread().getName()));

        t1.start();
        t2.start();
    }
}
