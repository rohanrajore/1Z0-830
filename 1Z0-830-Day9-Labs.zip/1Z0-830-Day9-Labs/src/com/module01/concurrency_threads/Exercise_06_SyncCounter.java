package com.module01.concurrency_threads;

class Counter {
    private int count = 0;
    synchronized void increment() { count++; }
    int get() { return count; }
}

public class Exercise_06_SyncCounter {
    public static void main(String[] args) throws InterruptedException {
        // TODO: Create a synchronized counter and update it from multiple threads to verify correct results
        Counter counter = new Counter();

        Runnable task = () -> {
            for (int i = 0; i < 1000; i++) counter.increment();
        };

        Thread t1 = new Thread(task);
        Thread t2 = new Thread(task);
        t1.start();
        t2.start();
        t1.join();
        t2.join();

        System.out.println("Final counter value: " + counter.get());
    }
}
