package com.module01.concurrency_threads;

import java.util.concurrent.*;

public class Exercise_05_CallableExample {
    public static void main(String[] args) throws Exception {
        // TODO: Create a Callable that calculates the factorial of a number and prints the result
        Callable<Long> factorialTask = () -> {
            int n = 5;
            long result = 1;
            for (int i = 1; i <= n; i++) result *= i;
            return result;
        };

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Future<Long> future = executor.submit(factorialTask);

        System.out.println("Factorial result: " + future.get());
        executor.shutdown();
    }
}
