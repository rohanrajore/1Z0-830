package com.module05.localization;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

public class Exercise_08_MessageFormatDemo {

    
    public static void main(String[] args) {
        Object[] values = {"Rohan", 38787898};

        Locale[] locales = {Locale.US, Locale.FRANCE};

        for (Locale locale : locales) {
            ResourceBundle rb = ResourceBundle.getBundle("com.module05.localization.messages", locale);
            String pattern = rb.getString("notification");

            MessageFormat mf = new MessageFormat(pattern, locale);
            System.out.println(locale.getDisplayName() + ": " + mf.format(values));
        }
    }
}
