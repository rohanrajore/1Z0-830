package com.module05.localization;

import java.text.NumberFormat;
import java.util.Locale;

public class Exercise_06_CurrencyFormat {
    public static void main(String[] args) {
        // TODO: Display a price in at least three different currency formats (US, UK, Japan).
        double price = 12345.67;
        Locale[] locales = {Locale.US, Locale.UK, Locale.JAPAN};
        for (Locale locale : locales) {
            NumberFormat nf = NumberFormat.getCurrencyInstance(locale);
            System.out.println(locale.getDisplayCountry() + ": " + nf.format(price));
        }
    }
}
