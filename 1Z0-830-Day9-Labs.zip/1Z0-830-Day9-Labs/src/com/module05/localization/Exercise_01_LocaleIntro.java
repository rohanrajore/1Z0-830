package com.module05.localization;

import java.util.Locale;

public class Exercise_01_LocaleIntro {
    public static void main(String[] args) {
        // TODO: Create and print different locales like US, France, and Japan. Display their language and country codes.
        Locale[] locales = {Locale.US, Locale.FRANCE, Locale.JAPAN};
        for (Locale locale : locales) {
            System.out.println("Locale: " + locale.getDisplayName());
            System.out.println("Language: " + locale.getLanguage());
            System.out.println("Country: " + locale.getCountry());
            System.out.println();
        }
    }
}
