package com.module05.localization;

import java.util.Locale;

public class Exercise_01_LocaleIntro {
	public static void main(String[] args) {
        // TODO: Create and print different locales like US, France, and Japan. Display their language and country codes.
        Locale[] locales = {Locale.US, Locale.FRANCE, Locale.JAPAN};
        
        // Locale hindiIndia = new Locale("hi", "IN");

     	// This is to be used starting java19
     	// Locale hindiIndia = Locale.of("hi", "IN");

     	// Locale hindiIndia = Locale.forLanguageTag("hi-IN");

		//             Locale hindiIndia = new Locale.Builder()
		//                     .setLanguage("hi")
		//                     .setRegion("IN")
		//                     .build();

        
        for (Locale locale : locales) {
            System.out.println("Locale: " + locale.getDisplayName());
            System.out.println("Language: " + locale.getLanguage());
            System.out.println("Country: " + locale.getCountry());
            System.out.println();
        }
    }
}

//Locale locale = new Locale("fr", "FR");
//new Locale("fr", "CA") it would mean “French as used in Canada.”

//"fr" → the language code, following ISO 639-1 (two-letter lowercase).
//
//"fr" means French.
//
//"FR" → the country (or region) code, following ISO 3166-1 alpha-2 (two-letter uppercase).
//
//"FR" means France.
//
//Locales are used by Java’s internationalization (I18N) system