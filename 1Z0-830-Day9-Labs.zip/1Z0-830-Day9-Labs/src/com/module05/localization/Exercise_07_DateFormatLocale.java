package com.module05.localization;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

public class Exercise_07_DateFormatLocale {
    public static void main(String[] args) {
        // TODO: Print today’s date in FULL format for US, France, and India locales.
        LocalDate today = LocalDate.now();
        Locale[] locales = {Locale.US, Locale.FRANCE, new Locale("hi", "IN")};
        for (Locale locale : locales) {
            DateTimeFormatter fmt = DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(locale);
            System.out.println(locale.getDisplayCountry() + ": " + today.format(fmt));
        }
    }
}
