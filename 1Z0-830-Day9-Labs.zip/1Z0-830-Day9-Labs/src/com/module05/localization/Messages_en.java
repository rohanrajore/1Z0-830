package com.module05.localization;

import java.util.*;

public class Messages_en extends ListResourceBundle {
    @Override
    protected Object[][] getContents() {
        return new Object[][] {
            {"welcome", "Welcome to Learnato"},
            {"bye", "Goodbye"}
        };
    }
}