package com.module05.localization;

import java.util.*;

public class Exercise_05_ListResourceBundleDemo {
    public static void main(String[] args) {
        // TODO: Create a ListResourceBundle in code and load it instead of using .properties files.
        ResourceBundle rb = ResourceBundle.getBundle("com.module05.localization.Messages", Locale.ENGLISH);
        System.out.println(rb.getString("welcome"));
        System.out.println(rb.getString("bye"));
    }
}
