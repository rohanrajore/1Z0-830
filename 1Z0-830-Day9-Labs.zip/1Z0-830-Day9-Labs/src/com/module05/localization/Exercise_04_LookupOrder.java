package com.module05.localization;

import java.util.*;

public class Exercise_04_LookupOrder {
    public static void main(String[] args) {
        // TODO: Create multiple localized bundles and print which one is loaded for various locales.
        Locale[] testLocales = {
            new Locale("es", "ES"),
            new Locale("es", "MX"),
            new Locale("fr", "FR")
        };

        for (Locale locale : testLocales) {
            ResourceBundle rb = ResourceBundle.getBundle("labels", locale);
            System.out.println("Loaded bundle for " + locale + ": " + rb.getLocale());
            System.out.println("Message: " + rb.getString("welcome"));
            System.out.println();
        }
    }
}
