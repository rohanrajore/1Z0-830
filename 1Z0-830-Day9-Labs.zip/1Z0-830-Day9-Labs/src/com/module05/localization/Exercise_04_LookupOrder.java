package com.module05.localization;

import java.util.*;

public class Exercise_04_LookupOrder {
	public static void main(String[] args) {
        Locale[] testLocales = {
            Locale.of("es", "ES"),   // Spanish (Spain)
            Locale.of("es", "MX"),   // Spanish (Mexico) — doesn’t exist, will fallback
            Locale.of("en", "GB"),   // English (UK) — no region-specific file
            Locale.of("fr", "FR")    // French (France) — no file at all
        };

        for (Locale locale : testLocales) {
            ResourceBundle rb = ResourceBundle.getBundle("com.module05.localization.labels", locale);
            System.out.println("\nLocale: " + locale);
            System.out.println("Loaded bundle: " + rb.getBaseBundleName());
            System.out.println("welcome → " + rb.getString("welcome"));
            System.out.println("bye → " + rb.getString("bye"));
        }
    }
}
