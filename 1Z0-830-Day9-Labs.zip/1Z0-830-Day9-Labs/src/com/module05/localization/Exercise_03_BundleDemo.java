package com.module05.localization;

import java.text.MessageFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

public class Exercise_03_BundleDemo {	
	public static void main(String[] args) {
        Locale[] locales = {Locale.US, Locale.FRANCE};
        Date today = new Date();

        for (Locale locale : locales) {
            ResourceBundle rb = ResourceBundle.getBundle("com.module05.localization.messages", locale);

            System.out.println("\nLocale: " + locale);
            System.out.println(rb.getString("greeting"));
            System.out.println(rb.getString("farewell"));
        }
    }
}
