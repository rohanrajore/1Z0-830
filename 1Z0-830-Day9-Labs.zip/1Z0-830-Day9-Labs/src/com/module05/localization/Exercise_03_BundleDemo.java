package com.module05.localization;

import java.util.*;

public class Exercise_03_BundleDemo {
    public static void main(String[] args) {
        // TODO: Create messages_en_US.properties and messages_fr_FR.properties with greetings, then load and print them.
        Locale[] locales = {Locale.US, Locale.FRANCE};
        for (Locale locale : locales) {
            ResourceBundle rb = ResourceBundle.getBundle("messages", locale);
            System.out.println(locale + ": " + rb.getString("greeting"));
        }
    }
}
