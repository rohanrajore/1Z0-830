package com.module05.localization;

public class Exercise_10_CertificationPractice {
    public static void main(String[] args) {
        // TODO: Explain what happens if messages_fr_FR.properties is missing but messages_fr.properties exists for locale fr_FR.
        System.out.println("If messages_fr_FR.properties is missing but messages_fr.properties exists,");
        System.out.println("Java will automatically fall back to the language-only bundle (messages_fr.properties).");
        System.out.println("If that too is missing, it falls back to the default or base bundle.");
    }
}
