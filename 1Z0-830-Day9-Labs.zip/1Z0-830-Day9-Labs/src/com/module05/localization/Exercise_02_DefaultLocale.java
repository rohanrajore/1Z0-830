package com.module05.localization;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;

public class Exercise_02_DefaultLocale {
	public static void main(String[] args) {
		
		double number = 1234567.89;
		Date now = new Date();

		// English locale
		Locale englishIndia = Locale.of("en", "IN");
		Locale.setDefault(englishIndia);
		System.out.println("=== English (India) Locale ===");
		printLocaleDetails(englishIndia, number, now);

		// Hindi locale
		Locale hindiIndia = Locale.forLanguageTag("hi-IN-u-nu-deva"); // <-- Devanagari digits
		Locale.setDefault(hindiIndia);
		System.out.println("\n=== Hindi (India) Locale ===");
		printLocaleDetails(hindiIndia, number, now);

	}

	static void printLocaleDetails(Locale locale, double number, Date now) {
		System.out.println("Display name: " + locale.getDisplayName());
		System.out.println("Language: " + locale.getLanguage());
		System.out.println("Country: " + locale.getCountry());

		NumberFormat nf = NumberFormat.getInstance(locale);
		System.out.println("Formatted number: " + nf.format(number));

		NumberFormat cf = NumberFormat.getCurrencyInstance(locale);
		System.out.println("Currency format: " + cf.format(number));

		DateFormat df = DateFormat.getDateInstance(DateFormat.FULL, locale);
		System.out.println("Date format: " + df.format(now));
	}
}
