package com.module05.localization;

import java.util.Locale;

public class Exercise_02_DefaultLocale {
    public static void main(String[] args) {
        // TODO: Change the default locale to Hindi (India) and print the language and country codes.
        Locale hindiIndia = new Locale("hi", "IN");
        Locale.setDefault(hindiIndia);
        Locale current = Locale.getDefault();

        System.out.println("Default Locale: " + current.getDisplayName());
        System.out.println("Language: " + current.getLanguage());
        System.out.println("Country: " + current.getCountry());
    }
}
