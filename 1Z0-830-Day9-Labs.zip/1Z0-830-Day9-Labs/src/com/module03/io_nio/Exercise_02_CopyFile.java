package com.module03.io_nio;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Exercise_02_CopyFile {
    public static void main(String[] args) {
        // TODO: Copy a text file using FileReader and FileWriter
        try (FileReader reader = new FileReader("input.txt");
             FileWriter writer = new FileWriter("output_copy.txt")) {
            int ch;
            while ((ch = reader.read()) != -1) {
                writer.write(ch);
            }
            System.out.println("File copied successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


//| Feature                | `FileReader`                                                              | `FileInputStream`                        |
//| ---------------------- | ------------------------------------------------------------------------- | ---------------------------------------- |
//| **Purpose**            | Reads **characters (text)**                                               | Reads **bytes (binary data)**            |
//| **Data Type Returned** | `char` (16-bit Unicode)                                                   | `byte` (8-bit raw)                       |
//| **Typical Use Case**   | Text files (`.txt`, `.csv`, `.json`)                                      | Binary files (`.jpg`, `.mp3`, `.pdf`)    |
//| **Encoding Awareness** | Converts bytes → characters using platform/default encoding (UTF-8, etc.) | No conversion; gives raw bytes           |
//| **Extends**            | `Reader` (character stream)                                               | `InputStream` (byte stream)              |
//| **Buffering**          | Use `BufferedReader` for efficiency                                       | Use `BufferedInputStream` for efficiency |
