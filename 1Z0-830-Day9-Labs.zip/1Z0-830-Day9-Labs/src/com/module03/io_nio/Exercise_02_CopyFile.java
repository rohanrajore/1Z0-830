package com.module03.io_nio;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Exercise_02_CopyFile {
    public static void main(String[] args) {
        // TODO: Copy a text file using FileReader and FileWriter
        try (FileReader reader = new FileReader("input.txt");
             FileWriter writer = new FileWriter("output_copy.txt")) {
            int ch;
            while ((ch = reader.read()) != -1) {
                writer.write(ch);
            }
            System.out.println("File copied successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
