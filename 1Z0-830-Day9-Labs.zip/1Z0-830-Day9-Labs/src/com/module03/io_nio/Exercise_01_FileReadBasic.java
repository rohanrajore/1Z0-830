package com.module03.io_nio;

import java.io.FileInputStream;
import java.io.IOException;

public class Exercise_01_FileReadBasic {
    public static void main(String[] args) {
        // TODO: Create a simple file reader using FileInputStream to print a text file’s contents.
        try (FileInputStream fis = new FileInputStream("sample.txt")) {
            int b;
            int counter = 0;
            while ((b = fis.read()) != -1) {
            	System.out.println(counter++);
                System.out.print((char) b + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


// fis.read() reads one byte at a time