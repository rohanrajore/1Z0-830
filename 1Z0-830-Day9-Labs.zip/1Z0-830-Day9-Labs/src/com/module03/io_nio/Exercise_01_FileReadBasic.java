package com.module03.io_nio;

import java.io.FileInputStream;
import java.io.IOException;

public class Exercise_01_FileReadBasic {
    public static void main(String[] args) {
        // TODO: Create a simple file reader using FileInputStream to print a text file’s contents.
        try (FileInputStream fis = new FileInputStream("sample.txt")) {
            int b;
            while ((b = fis.read()) != -1) {
                System.out.print((char) b);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
