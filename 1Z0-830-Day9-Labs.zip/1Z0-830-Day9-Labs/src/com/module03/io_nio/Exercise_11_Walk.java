package com.module03.io_nio;

import java.nio.file.*;
import java.io.IOException;

public class Exercise_11_Walk {
    public static void main(String[] args) throws IOException {
    	
    	//Streams
        Path start = Paths.get("C:/projects");
        Files.walk(start)
             .forEach(System.out::println);
        
        
       //Filter Files
			Files.walk(Paths.get("C:/projects"))
			.filter(Files::isRegularFile)
			.filter(p -> p.toString().endsWith(".java"))
			.forEach(System.out::println);
		

        //Count Files
        long count = Files.walk(Paths.get("C:/data"))
                .filter(p -> p.toString().endsWith(".txt"))
                .count();
        System.out.println("Text files: " + count);

    }
}
