package com.module03.io_nio;

import java.nio.file.*;
import java.io.IOException;

public class Exercise_07_FileCopyNio {
    public static void main(String[] args) {
        // TODO: Use Files.copy() and Files.move() to back up and relocate a file
        Path source = Paths.get("input.txt");
        Path backup = Paths.get("backup_input.txt");
        Path moved = Paths.get("moved_input.txt");

        try {
            Files.copy(source, backup, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File copied to backup.");
            Files.move(backup, moved, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File moved successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
