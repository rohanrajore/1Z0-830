package com.module03.io_nio;

import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;

public class Exercise_09_MemoryMapDemo {
    public static void main(String[] args) {
        // TODO: Use a memory-mapped file to read and display a large text file’s content
        try (FileChannel fc = FileChannel.open(Paths.get("largefile.txt"), StandardOpenOption.READ)) {
            MappedByteBuffer mbb = fc.map(FileChannel.MapMode.READ_ONLY, 0, fc.size());
            for (int i = 0; i < fc.size(); i++) {
                System.out.print((char) mbb.get(i));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
