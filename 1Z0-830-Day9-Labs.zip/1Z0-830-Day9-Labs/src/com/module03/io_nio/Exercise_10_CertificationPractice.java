package com.module03.io_nio;

import java.io.*;
import java.nio.file.*;
import java.util.List;

public class Exercise_10_CertificationPractice {
    public static void main(String[] args) throws IOException {
        // TODO: Compare performance and syntax differences between FileReader and Files.readAllLines()
        long start1 = System.currentTimeMillis();
        try (FileReader reader = new FileReader("bigfile.txt")) {
            while (reader.read() != -1) {}
        }
        long end1 = System.currentTimeMillis();

        long start2 = System.currentTimeMillis();
        List<String> lines = Files.readAllLines(Paths.get("bigfile.txt"));
        long end2 = System.currentTimeMillis();

        System.out.println("FileReader time: " + (end1 - start1) + " ms");
        System.out.println("Files.readAllLines time: " + (end2 - start2) + " ms");
        System.out.println("Total lines read: " + lines.size());
    }
}
