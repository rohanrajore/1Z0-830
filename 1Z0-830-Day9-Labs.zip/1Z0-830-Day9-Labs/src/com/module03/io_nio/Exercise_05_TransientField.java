package com.module03.io_nio;

import java.io.*;

class Account implements Serializable {
    private static final long serialVersionUID = 1L;
    transient String password;
    String username;

    public Account(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String toString() {
        return "Account{username='" + username + "', password='" + password + "'}";
    }
}

public class Exercise_05_TransientField {
    public static void main(String[] args) throws Exception {
        // TODO: Demonstrate the effect of transient by serializing and deserializing an object with sensitive data
        Account acc = new Account("Rohan", "secret123");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("account.dat"))) {
            oos.writeObject(acc);
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("account.dat"))) {
            Account deserialized = (Account) ois.readObject();
            System.out.println("After deserialization: " + deserialized);
        }
    }
}
