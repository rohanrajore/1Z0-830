package com.module03.io_nio;

import java.io.*;

class Account implements Serializable {
    private static final long serialVersionUID = 1L;
    transient String password;
    String username;

    public Account(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String toString() {
        return "Account{username='" + username + "', password='" + password + "'}";
    }
}

public class Exercise_05_TransientField {
    public static void main(String[] args) throws Exception {
        // TODO: Demonstrate the effect of transient by serializing and deserializing an object with sensitive data
        Account acc = new Account("Rohan", "secret123");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("account.dat"))) {
            oos.writeObject(acc);
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("account.dat"))) {
            Account deserialized = (Account) ois.readObject();
            System.out.println("After deserialization: " + deserialized);
        }
    }
}


//What Is serialVersionUID?
//
//It’s a unique identifier that Java assigns to every Serializable class.
//It acts like a version number for that class’s serialized form.
//
//When you serialize (save) an object to a file, Java writes:
//
//The object data, and
//The class’s serialVersionUID.
//
//When you later deserialize (read) the object back, Java checks:
//“Does the class I’m reading now have the same serialVersionUID as the one stored in the file?”
//
//If yes → ✅ deserialization succeeds.
//If no → ❌ it throws an InvalidClassException.
