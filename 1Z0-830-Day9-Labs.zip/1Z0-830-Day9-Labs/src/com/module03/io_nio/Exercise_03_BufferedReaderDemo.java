package com.module03.io_nio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Exercise_03_BufferedReaderDemo {
    public static void main(String[] args) {
        // TODO: Read a large text file using BufferedReader and print only lines containing a keyword
        String keyword = "Java";
        try (BufferedReader br = new BufferedReader(new FileReader("notes.txt"))) {
            br.lines()
              .filter(line -> line.contains(keyword))
              .forEach(System.out::println);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
