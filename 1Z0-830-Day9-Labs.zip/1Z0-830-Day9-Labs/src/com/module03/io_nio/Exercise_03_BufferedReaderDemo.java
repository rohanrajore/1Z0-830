package com.module03.io_nio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Exercise_03_BufferedReaderDemo {
    public static void main(String[] args) {
        // TODO: Read a large text file using BufferedReader and print only lines containing a keyword
        String keyword = "Java";
        try (BufferedReader br = new BufferedReader(new FileReader("notes.txt"))) {
            br.lines()
              .filter(line -> line.contains(keyword))
              .forEach(System.out::println);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


//🧩 What It Does
//
//br.lines() returns a Stream<String> —
//a Java Stream where each element is one line from the underlying text source.
//
//In short:
//
//It turns your text file (or any BufferedReader) into a stream of lines that you can process with modern Java Stream API features.

//| Operation    | Without Buffer        | With Buffer             |
//| ------------ | --------------------- | ----------------------- |
//| Disk reads   | 1 per byte            | 1 per ~8 KB chunk       |
//| System calls | Thousands or millions | Dozens                  |
//| CPU overhead | High                  | Low                     |
//| Memory use   | Minimal               | Moderate (buffer array) |
//| Performance  | Slow                  | Much faster             |
