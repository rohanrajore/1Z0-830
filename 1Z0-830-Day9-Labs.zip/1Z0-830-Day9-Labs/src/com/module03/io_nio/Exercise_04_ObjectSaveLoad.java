package com.module03.io_nio;

import java.io.*;

class User implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name;
    private int age;

    public User(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String toString() {
        return "User{name='" + name + "', age=" + age + "}";
    }
}

public class Exercise_04_ObjectSaveLoad {
    public static void main(String[] args) {
        // TODO: Create a User class implementing Serializable, write and read it using object streams
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("user.dat"))) {
            oos.writeObject(new User("Rohan", 35));
            System.out.println("Object written successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("user.dat"))) {
            User user = (User) ois.readObject();
            System.out.println("Read object: " + user);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
