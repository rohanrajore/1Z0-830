package com.module03.io_nio;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;

public class Exercise_08_ChannelBuffer {
    public static void main(String[] args) {
        // TODO: Read a file using FileChannel and ByteBuffer instead of streams
        try (FileChannel channel = FileChannel.open(Paths.get("data.txt"), StandardOpenOption.READ)) {
        	
        	//allocate array of memory
            ByteBuffer buffer = ByteBuffer.allocate(64);
            
            //writes to buffer
            channel.read(buffer);
            
            //flips buffer to read mode
            buffer.flip();
            System.out.println(new String(buffer.array(), 0, buffer.limit()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


//new String(byte[] bytes, int offset, int length)
