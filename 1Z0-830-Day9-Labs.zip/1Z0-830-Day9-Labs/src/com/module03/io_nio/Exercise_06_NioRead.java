package com.module03.io_nio;

import java.nio.file.*;
import java.io.IOException;
import java.util.List;

public class Exercise_06_NioRead {
    public static void main(String[] args) {
        // TODO: Use Files.readAllLines() to read a file and count the number of lines
        Path path = Paths.get("data.txt");
        try {
            List<String> lines = Files.readAllLines(path);
            System.out.println("Total lines: " + lines.size());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
