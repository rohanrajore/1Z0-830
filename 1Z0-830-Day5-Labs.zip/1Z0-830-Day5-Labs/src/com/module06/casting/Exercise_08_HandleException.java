package com.module06.casting;

public class Exercise_08_HandleException {
    public static void main(String[] args) {
        // TODO: Handle ClassCastException safely
        try {
            Object obj = "Java 21";
            Integer num = (Integer) obj; // Invalid cast
        } catch (ClassCastException e) {
            System.out.println("Handled: " + e.getMessage());
        }
    }
}
