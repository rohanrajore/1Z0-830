package com.module06.casting;

import java.util.*;

public class Exercise_09_GenericCast {
    public static void main(String[] args) {
        // TODO: Demonstrate unsafe generic casting
        List list = new ArrayList<String>(); // raw type
        list.add(100); // allows wrong type
        try {
            String s = (String) list.get(0); // Runtime error
        } catch (ClassCastException e) {
            System.out.println("Caught: " + e.getMessage());
        }
    }
}
