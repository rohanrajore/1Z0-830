package com.module06.casting;

public class Exercise_07_ClassCastDeepDive {
    public static void main(String[] args) {
        // TODO: Simulate multiple invalid casts and handle exceptions
        Object[] items = { "Text", 10, 20.5 };

        for (Object item : items) {
            try {
                String s = (String) item;
                System.out.println("String value: " + s);
            } catch (ClassCastException e) {
                System.out.println("Invalid cast: " + e.getMessage());
            }
        }
    }
}
