package com.module06.casting;

public class Exercise_05_InstanceofCheck {
    public static void main(String[] args) {
        // TODO: Use instanceof before casting
        Media m = new Audio();
        if (m instanceof Audio a) {
            a.play();
        } else {
            System.out.println("Not an audio file");
        }
    }
}

abstract class Media { abstract void info(); }
class Audio extends Media { void play() { System.out.println("Playing audio"); } void info() {} }
class Video extends Media { void stream() { System.out.println("Streaming video"); } void info() {} }
