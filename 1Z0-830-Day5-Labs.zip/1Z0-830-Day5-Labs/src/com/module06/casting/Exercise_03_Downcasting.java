package com.module06.casting;

public class Exercise_03_Downcasting {
    public static void main(String[] args) {
        // TODO: Demonstrate safe downcasting
        Shape s = new Circle(); // Upcast
        if (s instanceof Circle) {
            Circle c = (Circle) s; // Downcast safely
            c.draw();
        }
    }
}

class Shape { void info() { System.out.println("Shape info"); } }
class Circle extends Shape { void draw() { System.out.println("Drawing circle"); } }
