package com.module06.casting;

public class Exercise_04_InvalidCast {
    public static void main(String[] args) {
        // TODO: Demonstrate ClassCastException
        Fruit f = new Apple();
        try {
            Orange o = (Orange) f; // Invalid cast
            o.peel();
        } catch (ClassCastException e) {
            System.out.println("Caught exception: " + e.getMessage());
        }
    }
}

class Fruit {}
class Apple extends Fruit {}
class Orange extends Fruit { void peel() { System.out.println("Peeling orange"); } }
