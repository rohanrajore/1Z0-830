package com.module06.casting;

public class Exercise_01_TypeCastingIntro {
    public static void main(String[] args) {
        // TODO: Demonstrate upcasting and downcasting between Vehicle and Car
        Vehicle v = new Car(); // Upcasting (safe, implicit)
        v.start();

        // Downcasting (explicit)
        Car c = (Car) v;
        c.drive();
    }
}

class Vehicle {
    void start() { System.out.println("Vehicle starting..."); }
}

class Car extends Vehicle {
    void drive() { System.out.println("Car driving..."); }
}
