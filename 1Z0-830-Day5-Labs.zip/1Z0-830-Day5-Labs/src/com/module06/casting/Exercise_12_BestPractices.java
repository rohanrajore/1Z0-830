package com.module06.casting;

public class Exercise_12_BestPractices {
    public static void main(String[] args) {
        // TODO: Apply best casting practices in a shape hierarchy
        Shape2 s = new Circle2();
        if (s instanceof Circle2 c) {
            c.draw();
        } else {
            System.out.println("Not a circle");
        }
    }
}

abstract class Shape2 { abstract void info(); }
class Circle2 extends Shape2 { void draw() { System.out.println("Drawing circle safely"); } void info() {} }
class Square extends Shape2 { void paint() { System.out.println("Painting square safely"); } void info() {} }
