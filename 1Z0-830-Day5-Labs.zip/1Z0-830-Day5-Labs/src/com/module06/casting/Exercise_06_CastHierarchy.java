package com.module06.casting;

public class Exercise_06_CastHierarchy {
    public static void main(String[] args) {
        // TODO: Build a 3-level hierarchy and test casts
        LivingBeing being = new Human();
        ((Human) being).speak();

        try {
            ((Animal2) being).makeSound(); // Invalid downcast
        } catch (ClassCastException e) {
            System.out.println("Invalid cast: " + e.getMessage());
        }
    }
}

class LivingBeing {}
class Animal2 extends LivingBeing { void makeSound() { System.out.println("Animal sound"); } }
class Human extends LivingBeing { void speak() { System.out.println("Human speaks"); } }
