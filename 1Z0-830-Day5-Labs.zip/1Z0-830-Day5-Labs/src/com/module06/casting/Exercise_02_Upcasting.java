package com.module06.casting;

public class Exercise_02_Upcasting {
    public static void main(String[] args) {
        // TODO: Show what methods remain accessible after upcasting
        Dog dog = new Dog();
        Animal animal = dog; // Upcasting
        animal.eat();
        // animal.bark(); // Not accessible after upcast
    }
}

class Animal {
    void eat() { System.out.println("Animal eats"); }
}

class Dog extends Animal {
    void bark() { System.out.println("Dog barks"); }
}
