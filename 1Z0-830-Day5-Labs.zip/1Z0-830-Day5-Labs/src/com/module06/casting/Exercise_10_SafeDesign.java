package com.module06.casting;

public class Exercise_10_SafeDesign {
    public static void main(String[] args) {
        // TODO: Use polymorphism instead of casting
        Message msg = new EmailMessage();
        msg.send();
    }
}

abstract class Message { abstract void send(); }
class EmailMessage extends Message { void send() { System.out.println("Sending email..."); } }
class SmsMessage extends Message { void send() { System.out.println("Sending SMS..."); } }
