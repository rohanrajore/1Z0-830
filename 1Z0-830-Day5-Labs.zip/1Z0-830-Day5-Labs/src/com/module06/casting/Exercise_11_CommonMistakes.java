package com.module06.casting;

public class Exercise_11_CommonMistakes {
    public static void main(String[] args) {
        // TODO: Show compile-time and runtime casting issues
        try {
            Object o = new Object();
            String s = (String) o; // Compiles, fails at runtime
        } catch (ClassCastException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
