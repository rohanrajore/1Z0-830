package com.module08.enums;

interface Payable { void pay(); }

enum PaymentMethod implements Payable {
    CASH, CARD, UPI;

    public void pay() {
        System.out.println("Paying via " + this.name());
    }
}

public class Exercise_11_EnumInterface {
    public static void main(String[] args) {
        // TODO: Implement interface in enum
        for (PaymentMethod p : PaymentMethod.values()) {
            p.pay();
        }
    }
}
