package com.module08.enums;

enum Direction {
    NORTH, SOUTH, EAST, WEST
}

public class Exercise_02_EnumInternals {
    public static void main(String[] args) {
        // TODO: Print name() and ordinal() for each constant
        for (Direction dir : Direction.values()) {
            System.out.println(dir.name() + " -> ordinal=" + dir.ordinal());
        }
    }
}
