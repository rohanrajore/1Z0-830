package com.module08.enums;

enum Day {
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
}

public class Exercise_01_EnumBasics {
    public static void main(String[] args) {
        // TODO: Print all days using a loop
        for (Day d : Day.values()) {
            System.out.println(d);
        }
    }
}
