package com.module08.enums;

// Incorrect (commented out):
// public enum Color {
//     RED, GREEN, BLUE
//     public Color() {} // public constructor not allowed
//     void info() {} // missing semicolon
// }

enum FixedColor {
    RED, GREEN, BLUE;

    void info() { System.out.println("Fixed version works"); }
}

public class Exercise_13_CommonMistakes {
    public static void main(String[] args) {
        // TODO: Identify and fix invalid enum syntax
        FixedColor.RED.info();
    }
}
