package com.module08.enums;

enum NotificationType {
    EMAIL { void sendMessage() { System.out.println("Sending Email Notification"); } },
    SMS { void sendMessage() { System.out.println("Sending SMS Notification"); } },
    PUSH { void sendMessage() { System.out.println("Sending Push Notification"); } };

    abstract void sendMessage();
}

public class Exercise_10_EnumCustomBehavior {
    public static void main(String[] args) {
        // TODO: Trigger custom sendMessage() per constant
        for (NotificationType n : NotificationType.values()) {
            n.sendMessage();
        }
    }
}
