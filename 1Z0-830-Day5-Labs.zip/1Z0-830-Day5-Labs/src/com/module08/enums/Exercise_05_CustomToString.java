package com.module08.enums;

enum Severity {
    CRITICAL, MAJOR, MINOR;

    @Override
    public String toString() {
        return switch (this) {
            case CRITICAL -> "Critical Issue";
            case MAJOR -> "Major Issue";
            case MINOR -> "Minor Issue";
        };
    }
}

public class Exercise_05_CustomToString {
    public static void main(String[] args) {
        // TODO: Print custom labels for each severity level
        for (Severity s : Severity.values()) {
            System.out.println(s);
        }
    }
}
