package com.module08.enums;

sealed interface Command permits Start, Stop {}
enum Start implements Command { INSTANCE }
enum Stop implements Command { INSTANCE }

public class Exercise_09_EnumSwitchPattern {
    static String handle(Command cmd) {
        // TODO: Pattern-matching switch using enums
        return switch (cmd) {
            case Start s -> "System Starting";
            case Stop t -> "System Stopping";
        };
    }

    public static void main(String[] args) {
        System.out.println(handle(Start.INSTANCE));
        System.out.println(handle(Stop.INSTANCE));
    }
}
