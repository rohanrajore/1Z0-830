package com.module08.enums;

enum UserRole {
    ADMIN { void performAction() { System.out.println("Full access granted"); } },
    USER { void performAction() { System.out.println("Limited access granted"); } },
    GUEST { void performAction() { System.out.println("View-only access"); } };

    abstract void performAction();
}

public class Exercise_14_BestPractices {
    public static void main(String[] args) {
        // TODO: Demonstrate role-based behavior
        for (UserRole role : UserRole.values()) {
            System.out.print(role + ": ");
            role.performAction();
        }
    }
}
