package com.module08.enums;

enum Currency {
    USD("$", "United States"),
    EUR("€", "European Union"),
    INR("₹", "India");

    private final String symbol;
    private final String country;

    Currency(String symbol, String country) {
        this.symbol = symbol;
        this.country = country;
    }

    public String getSymbol() { return symbol; }
    public String getCountry() { return country; }
}

public class Exercise_03_EnumWithFields {
    public static void main(String[] args) {
        // TODO: Print currency details
        for (Currency c : Currency.values()) {
            System.out.println(c.name() + " - " + c.getSymbol() + " (" + c.getCountry() + ")");
        }
    }
}
