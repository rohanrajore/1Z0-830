package com.module08.enums;

enum Membership {
    BASIC(100), GOLD(500), PLATINUM(1000);

    private final int price;

    Membership(int price) { this.price = price; }
    public int getPrice() { return price; }
}

public class Exercise_07_EnumConstructorParams {
    public static void main(String[] args) {
        // TODO: Print membership prices
        for (Membership m : Membership.values()) {
            System.out.println(m + " costs $" + m.getPrice());
        }
    }
}
