package com.module08.enums;

enum HttpStatus {
    OK(200), NOT_FOUND(404), INTERNAL_ERROR(500);

    private final int code;

    HttpStatus(int code) { this.code = code; }
    public int getCode() { return code; }

    static HttpStatus getByCode(int code) {
        for (HttpStatus h : values()) {
            if (h.code == code) return h;
        }
        return null;
    }
}

public class Exercise_12_EnumLookup {
    public static void main(String[] args) {
        // TODO: Lookup by code and print result
        System.out.println(HttpStatus.getByCode(200));
        System.out.println(HttpStatus.getByCode(404));
        System.out.println(HttpStatus.getByCode(999)); // null
    }
}
