package com.module08.enums;

enum OrderStatus {
    NEW, PROCESSING, SHIPPED, DELIVERED;

    public String getDescription() {
        return switch (this) {
            case NEW -> "Order created.";
            case PROCESSING -> "Order is being processed.";
            case SHIPPED -> "Order has been shipped.";
            case DELIVERED -> "Order delivered successfully.";
        };
    }
}

public class Exercise_04_EnumMethods {
    public static void main(String[] args) {
        // TODO: Print descriptions for all statuses
        for (OrderStatus s : OrderStatus.values()) {
            System.out.println(s + ": " + s.getDescription());
        }
    }
}
