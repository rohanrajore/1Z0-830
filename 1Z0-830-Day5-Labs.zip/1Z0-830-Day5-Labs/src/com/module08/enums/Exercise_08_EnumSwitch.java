package com.module08.enums;

enum Season { WINTER, SPRING, SUMMER, FALL }

public class Exercise_08_EnumSwitch {
    static String activity(Season s) {
        // TODO: Use switch expression with enum
        return switch (s) {
            case WINTER -> "Skiing";
            case SPRING -> "Hiking";
            case SUMMER -> "Swimming";
            case FALL -> "Camping";
        };
    }

    public static void main(String[] args) {
        for (Season s : Season.values()) {
            System.out.println(s + ": " + activity(s));
        }
    }
}
