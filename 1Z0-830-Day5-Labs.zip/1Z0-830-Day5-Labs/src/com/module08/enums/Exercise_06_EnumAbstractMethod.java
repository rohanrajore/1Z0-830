package com.module08.enums;

enum ShapeType {
    CIRCLE {
        double area(double val) { return Math.PI * val * val; }
    },
    SQUARE {
        double area(double val) { return val * val; }
    };

    abstract double area(double val);
}

public class Exercise_06_EnumAbstractMethod {
    public static void main(String[] args) {
        // TODO: Calculate and print area for both shapes
        System.out.println("Circle area: " + ShapeType.CIRCLE.area(5));
        System.out.println("Square area: " + ShapeType.SQUARE.area(4));
    }
}
