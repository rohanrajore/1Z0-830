package com.module02.method_overriding;

class Vehicle {
    Vehicle getVehicle() { return new Vehicle(); }
}

class Truck extends Vehicle {
    @Override
    Truck getVehicle() { return new Truck(); }
}

public class Exercise_05_CovariantReturn {
    public static void main(String[] args) {
        // TODO: Demonstrate covariant return
        Truck t = new Truck().getVehicle();
        System.out.println("Returned: " + t.getClass().getSimpleName());
    }
}
