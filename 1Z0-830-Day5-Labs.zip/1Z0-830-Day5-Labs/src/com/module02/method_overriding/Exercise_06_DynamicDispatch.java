package com.module02.method_overriding;

class Instrument {
    void play() { System.out.println("Playing generic instrument"); }
}

class Guitar extends Instrument {
    @Override
    void play() { System.out.println("Strumming the guitar"); }
}

class Piano extends Instrument {
    @Override
    void play() { System.out.println("Playing the piano"); }
}

public class Exercise_06_DynamicDispatch {
    public static void main(String[] args) {
        // TODO: Demonstrate runtime polymorphism
        Instrument i1 = new Guitar();
        Instrument i2 = new Piano();
        i1.play();
        i2.play();
    }
}
