package com.module02.method_overriding;

class BaseLogger {
    static void log() { System.out.println("Base logging"); }
    final void info() { System.out.println("Base info"); }
}

class AdvancedLogger extends BaseLogger {
    static void log() { System.out.println("Advanced log"); }
    // void info() {} // invalid override
}

public class Exercise_08_StaticFinalMethods {
    public static void main(String[] args) {
        // TODO: Observe static hiding and final restriction
        BaseLogger b = new AdvancedLogger();
        b.log();
        b.info();
    }
}
