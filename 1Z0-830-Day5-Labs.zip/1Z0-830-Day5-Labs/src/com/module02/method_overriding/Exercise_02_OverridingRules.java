package com.module02.method_overriding;

import java.io.*;

class DataProvider {
    protected Object getData() throws IOException {
        return null;
    }
}

class FileProvider extends DataProvider {
    @Override
    public String getData() {
        return "File data";
    }
}

public class Exercise_02_OverridingRules {
    public static void main(String[] args) throws IOException {
        // TODO: Test access, return type, and exception rules
        DataProvider dp = new FileProvider();
        System.out.println(dp.getData());
    }
}
