package com.module02.method_overriding;

class Parent {
    void greet() { System.out.println("Hello from Parent"); }
}

class Child extends Parent {
    // Incorrect - overloads, not overrides
    void greet(String msg) { System.out.println(msg); }

    // Correct override
    @Override
    void greet() { System.out.println("Hello from Child"); }
}

public class Exercise_11_CommonMistakes {
    public static void main(String[] args) {
        // TODO: Identify incorrect and correct overriding
        Parent p = new Child();
        p.greet();
        ((Child)p).greet("Custom message");
    }
}
