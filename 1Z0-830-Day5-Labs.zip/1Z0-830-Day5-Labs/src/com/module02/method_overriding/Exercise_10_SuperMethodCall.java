package com.module02.method_overriding;

class Employee {
    void work() { System.out.println("Employee works 8 hours"); }
}

class Manager extends Employee {
    @Override
    void work() {
        super.work();
        System.out.println("Manager works with team and reports");
    }
}

public class Exercise_10_SuperMethodCall {
    public static void main(String[] args) {
        // TODO: Use super.method() to extend behavior
        Manager m = new Manager();
        m.work();
    }
}
