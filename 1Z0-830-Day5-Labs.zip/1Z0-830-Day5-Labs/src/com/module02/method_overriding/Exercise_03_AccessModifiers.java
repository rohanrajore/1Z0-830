package com.module02.method_overriding;

class Animal {
    protected void move() { System.out.println("Animal moves"); }
}

class Dog extends Animal {
    @Override
    public void move() { System.out.println("Dog runs"); }
}

public class Exercise_03_AccessModifiers {
    public static void main(String[] args) {
        // TODO: Check allowed access modifier transitions
        Dog d = new Dog();
        d.move();
    }
}
