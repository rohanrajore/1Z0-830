package com.module02.method_overriding;

import java.io.*;

class ReaderBase {
    void readData() throws IOException {
        System.out.println("Reading data from base");
    }
}

class FileReaderExtended extends ReaderBase {
    @Override
    void readData() throws FileNotFoundException {
        System.out.println("Reading data from file");
    }
}

public class Exercise_04_ExceptionRules {
    public static void main(String[] args) throws IOException {
        // TODO: Show overriding with narrower checked exception
        ReaderBase rb = new FileReaderExtended();
        rb.readData();
    }
}
