package com.module02.method_overriding;

class Printer {
    void printDoc() { System.out.println("Printing document..."); }
}

class LaserPrinter extends Printer {
    @Override
    void printDoc() { System.out.println("LaserPrinter prints with high quality"); }

    // Uncomment to test compiler error
    // @Override void prinDoc() {}
}

public class Exercise_07_OverrideAnnotation {
    public static void main(String[] args) {
        // TODO: Demonstrate @Override validation
        Printer p = new LaserPrinter();
        p.printDoc();
    }
}
