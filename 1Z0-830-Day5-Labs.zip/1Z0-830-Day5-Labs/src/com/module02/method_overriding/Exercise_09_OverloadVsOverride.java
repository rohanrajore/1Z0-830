package com.module02.method_overriding;

class Calculator {
    void calculate(int a) { System.out.println("Square: " + (a * a)); }
}

class AdvancedCalculator extends Calculator {
    @Override
    void calculate(int a) { System.out.println("Cube: " + (a * a * a)); }

    void calculate(int a, int b) { System.out.println("Sum: " + (a + b)); }
}

public class Exercise_09_OverloadVsOverride {
    public static void main(String[] args) {
        // TODO: Compare overriding and overloading
        Calculator calc = new AdvancedCalculator();
        calc.calculate(3);
        ((AdvancedCalculator) calc).calculate(3, 4);
    }
}
