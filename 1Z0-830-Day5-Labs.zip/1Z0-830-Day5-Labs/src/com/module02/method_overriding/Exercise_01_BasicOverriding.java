package com.module02.method_overriding;

class Shape {
    void draw() { System.out.println("Drawing a generic shape"); }
}

class Circle extends Shape {
    @Override
    void draw() { System.out.println("Drawing a circle"); }
}

public class Exercise_01_BasicOverriding {
    public static void main(String[] args) {
        // TODO: Demonstrate basic method overriding
        Shape s = new Circle();
        s.draw();
    }
}
