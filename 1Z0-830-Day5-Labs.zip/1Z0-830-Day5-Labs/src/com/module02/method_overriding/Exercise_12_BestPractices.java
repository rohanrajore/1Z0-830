package com.module02.method_overriding;

class Appliance {
    void turnOn() { System.out.println("Appliance turning on"); }
}

class WashingMachine extends Appliance {
    @Override
    void turnOn() {
        super.turnOn();
        System.out.println("WashingMachine starts washing");
    }
}

class SmartWashingMachine extends WashingMachine {
    @Override
    void turnOn() {
        super.turnOn();
        System.out.println("SmartWashingMachine optimizes settings");
    }
}

public class Exercise_12_BestPractices {
    public static void main(String[] args) {
        // TODO: Follow LSP and proper use of super()
        Appliance a = new SmartWashingMachine();
        a.turnOn();
    }
}
