package com.module01.inhierarchy_constructorchaining;

class Engine {
    Engine() { System.out.println("Engine initialized"); }
}

class VehicleBase extends Engine {
    VehicleBase() { System.out.println("VehicleBase ready"); }
}

class SportsCar extends VehicleBase {
    SportsCar() { System.out.println("SportsCar built"); }
}

public class Exercise_06_MultiLevelChain {
    public static void main(String[] args) {
        // TODO: Show constructor chaining in three levels
        new SportsCar();
    }
}
