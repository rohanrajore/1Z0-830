package com.module01.inhierarchy_constructorchaining;

class Vehicle {
    void start() { System.out.println("Vehicle starting..."); }
}

class Car extends Vehicle {
    void honk() { System.out.println("Car honks!"); }
}

class ElectricCar extends Car {
    void charge() { System.out.println("ElectricCar charging..."); }
}

public class Exercise_01_InheritanceBasics {
    public static void main(String[] args) {
        // TODO: Demonstrate inheritance hierarchy with Vehicle → Car → ElectricCar
        ElectricCar ev = new ElectricCar();
        ev.start();
        ev.honk();
        ev.charge();
    }
}
