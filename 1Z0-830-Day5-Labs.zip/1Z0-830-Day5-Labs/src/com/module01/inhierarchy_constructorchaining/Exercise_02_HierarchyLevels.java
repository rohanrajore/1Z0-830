package com.module01.inhierarchy_constructorchaining;

class LivingBeing {
    void breathe() { System.out.println("LivingBeing breathes"); }
}

class Mammal extends LivingBeing {
    void warmBlooded() { System.out.println("Mammal is warm-blooded"); }
}

class Human extends Mammal {
    void think() { System.out.println("Human thinks"); }
}

public class Exercise_02_HierarchyLevels {
    public static void main(String[] args) {
        // TODO: Show inherited members and hierarchy check
        Human h = new Human();
        h.breathe();
        h.warmBlooded();
        h.think();
        System.out.println("Is Human instance of LivingBeing? " + (h instanceof LivingBeing));
    }
}
