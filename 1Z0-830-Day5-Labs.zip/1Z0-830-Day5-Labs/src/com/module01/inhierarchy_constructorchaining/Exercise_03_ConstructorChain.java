package com.module01.inhierarchy_constructorchaining;

class Alpha {
    Alpha() { System.out.println("Alpha constructor"); }
}

class Beta extends Alpha {
    Beta() { System.out.println("Beta constructor"); }
}

class Gamma extends Beta {
    Gamma() { System.out.println("Gamma constructor"); }
}

public class Exercise_03_ConstructorChain {
    public static void main(String[] args) {
        // TODO: Observe constructor chaining order
        new Gamma();
    }
}
