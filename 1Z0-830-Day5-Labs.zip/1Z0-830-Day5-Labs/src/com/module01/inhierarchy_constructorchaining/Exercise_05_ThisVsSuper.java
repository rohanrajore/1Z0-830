package com.module01.inhierarchy_constructorchaining;

class AlphaBase {
    AlphaBase(int x) { System.out.println("AlphaBase constructor: " + x); }
}

class AlphaChild extends AlphaBase {
    AlphaChild() {
        this(20);
        System.out.println("AlphaChild() called");
    }
    AlphaChild(int y) {
        super(y);
        System.out.println("AlphaChild(int) called");
    }
}

public class Exercise_05_ThisVsSuper {
    public static void main(String[] args) {
        // TODO: Compare this() and super() in constructors
        new AlphaChild();
    }
}
