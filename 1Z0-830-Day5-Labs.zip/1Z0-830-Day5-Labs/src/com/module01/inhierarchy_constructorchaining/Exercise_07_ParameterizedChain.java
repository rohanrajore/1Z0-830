package com.module01.inhierarchy_constructorchaining;

class Person {
    String name;
    Person(String name) {
        this.name = name;
        System.out.println("Person: " + name);
    }
}

class Student extends Person {
    int roll;
    Student(String name, int roll) {
        super(name);
        this.roll = roll;
        System.out.println("Student Roll No: " + roll);
    }
}

public class Exercise_07_ParameterizedChain {
    public static void main(String[] args) {
        // TODO: Demonstrate parameter passing through super()
        new Student("Ravi", 42);
    }
}
