package com.module01.inhierarchy_constructorchaining;

class Machine {
    Machine() { System.out.println("Machine initialized"); }
}

class Computer extends Machine {
    Computer() { this("Default Model"); }
    Computer(String model) {
        super();
        System.out.println("Computer model: " + model);
    }
}

class Server extends Computer {
    Server() {
        super("Server Model");
        System.out.println("Server ready");
    }
}

public class Exercise_11_BestPractices {
    public static void main(String[] args) {
        // TODO: Apply constructor chaining best practices
        new Server();
    }
}
