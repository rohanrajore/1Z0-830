package com.module01.inhierarchy_constructorchaining;

class BaseDevice {
    BaseDevice() { System.out.println("BaseDevice constructed"); }
    @Override
    public String toString() { return "BaseDevice toString()"; }
}

class SmartDevice extends BaseDevice {
    SmartDevice() { System.out.println("SmartDevice constructed"); }
}

public class Exercise_09_ObjectRoot {
    public static void main(String[] args) {
        // TODO: Confirm Object as root class
        SmartDevice device = new SmartDevice();
        System.out.println(device.toString());
    }
}
