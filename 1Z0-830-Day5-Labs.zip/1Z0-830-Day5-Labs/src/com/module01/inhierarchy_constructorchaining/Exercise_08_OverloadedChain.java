package com.module01.inhierarchy_constructorchaining;

class Gadget {
    Gadget(String brand) { System.out.println("Gadget brand: " + brand); }
}

class Laptop extends Gadget {
    Laptop() { this("Lenovo"); }
    Laptop(String brand) {
        super(brand);
        System.out.println("Laptop initialized");
    }
}

public class Exercise_08_OverloadedChain {
    public static void main(String[] args) {
        // TODO: Observe chaining using this() and super()
        new Laptop();
    }
}
