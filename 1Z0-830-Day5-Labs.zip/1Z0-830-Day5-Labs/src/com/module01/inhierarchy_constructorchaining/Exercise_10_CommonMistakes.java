package com.module01.inhierarchy_constructorchaining;

class Appliance {
    Appliance(String name) {
        System.out.println("Appliance: " + name);
    }
}

// Incorrect examples (commented out)
// class Toaster extends Appliance {
//     Toaster() {
//         System.out.println("Before super()"); // invalid
//         super("Toaster");
//     }
// }

class FixedToaster extends Appliance {
    FixedToaster() {
        super("Toaster");
        System.out.println("FixedToaster initialized properly");
    }
}

public class Exercise_10_CommonMistakes {
    public static void main(String[] args) {
        // TODO: Demonstrate invalid chaining fixed with correct syntax
        new FixedToaster();
    }
}
