package com.module01.inhierarchy_constructorchaining;

class Building {
    Building(String type) {
        System.out.println("Building type: " + type);
    }
}

class House extends Building {
    House() {
        super("Residential");
        System.out.println("House created");
    }
}

public class Exercise_04_SuperConstructor {
    public static void main(String[] args) {
        // TODO: Demonstrate super() with parameterized constructor
        new House();
    }
}
