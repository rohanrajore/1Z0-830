package com.module07.interfaces;

interface Payment { void pay(); }

class CardPayment implements Payment {
    public void pay() { System.out.println("Paid by card"); }
}

class UpiPayment implements Payment {
    public void pay() { System.out.println("Paid by UPI"); }
}

public class Exercise_11_InterfacePolymorphism {
    public static void main(String[] args) {
        // TODO: Demonstrate polymorphism via interface
        Payment p1 = new CardPayment();
        Payment p2 = new UpiPayment();
        p1.pay();
        p2.pay();
    }
}
