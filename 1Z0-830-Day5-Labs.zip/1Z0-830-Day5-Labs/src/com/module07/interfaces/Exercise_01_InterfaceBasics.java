package com.module07.interfaces;

interface Shape {
    double area();
}

class Circle implements Shape {
    double radius = 5;
    public double area() { return Math.PI * radius * radius; }
}

class Rectangle implements Shape {
    double width = 4, height = 6;
    public double area() { return width * height; }
}

public class Exercise_01_InterfaceBasics {
    public static void main(String[] args) {
        // TODO: Create objects and print their areas
        Shape s1 = new Circle();
        Shape s2 = new Rectangle();
        System.out.println("Circle area: " + s1.area());
        System.out.println("Rectangle area: " + s2.area());
    }
}
