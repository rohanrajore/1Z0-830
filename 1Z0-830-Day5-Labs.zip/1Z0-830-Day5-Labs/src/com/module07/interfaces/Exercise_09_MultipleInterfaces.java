package com.module07.interfaces;

interface Flyable { void move(); }
interface Swimmable { void move(); }

class Duck implements Flyable, Swimmable {
    public void move() {
        System.out.println("Duck swims and flies");
    }
}

public class Exercise_09_MultipleInterfaces {
    public static void main(String[] args) {
        // TODO: Implement two interfaces with same abstract method
        Duck d = new Duck();
        d.move();
    }
}
