package com.module07.interfaces;

interface Printer {
    default void print() {
        System.out.println("Printing default content...");
    }
}

class CustomPrinter implements Printer {
    @Override
    public void print() {
        System.out.println("Custom printer output");
    }
}

public class Exercise_03_DefaultMethods {
    public static void main(String[] args) {
        // TODO: Demonstrate default and overridden methods
        Printer p = new CustomPrinter();
        p.print();
    }
}
