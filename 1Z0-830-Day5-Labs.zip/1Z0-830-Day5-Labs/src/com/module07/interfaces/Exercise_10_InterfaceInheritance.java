package com.module07.interfaces;

interface Readable {
    void read();
}

interface Writable {
    void write();
}

interface FileHandler extends Readable, Writable {}

class Document implements FileHandler {
    public void read() { System.out.println("Reading document"); }
    public void write() { System.out.println("Writing document"); }
}

public class Exercise_10_InterfaceInheritance {
    public static void main(String[] args) {
        // TODO: Implement inherited interface methods
        FileHandler doc = new Document();
        doc.read();
        doc.write();
    }
}
