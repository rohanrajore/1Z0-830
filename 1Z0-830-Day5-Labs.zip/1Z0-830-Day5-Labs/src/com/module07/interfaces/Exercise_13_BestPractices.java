package com.module07.interfaces;

interface Printers {
    default void print(String msg) {
        log("Printing: " + msg);
    }

    private void log(String msg) {
        System.out.println("LOG: " + msg);
    }
}

interface Scanner {
    default void scan() {
        System.out.println("Scanning document...");
    }
}

class MultiFunctionDevice implements Printers, Scanner {}

public class Exercise_13_BestPractices {
    public static void main(String[] args) {
        // TODO: Refactor large interface into smaller cohesive ones
        MultiFunctionDevice device = new MultiFunctionDevice();
        device.print("Hello Interface");
        device.scan();
    }
}
