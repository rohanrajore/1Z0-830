package com.module07.interfaces;

interface Logger {
    default void logInfo(String msg) { log(msg, "INFO"); }
    default void logError(String msg) { log(msg, "ERROR"); }

    private void log(String msg, String level) {
        System.out.println(level + ": " + msg);
    }
}

class AppLogger implements Logger {}

public class Exercise_06_PrivateMethods {
    public static void main(String[] args) {
        // TODO: Use default methods using private helper logic
        AppLogger logger = new AppLogger();
        logger.logInfo("Application started");
        logger.logError("Something went wrong");
    }
}
