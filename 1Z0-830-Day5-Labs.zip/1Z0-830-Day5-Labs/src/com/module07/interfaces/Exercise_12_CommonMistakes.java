package com.module07.interfaces;

// Incorrect examples (commented out)
// interface Demo {
//     int count; // must be initialized
//     private void helper(); // cannot be private abstract
// }

// Correct version:
interface FixedDemo {
    int COUNT = 10;
    void display();
}

class FixedClass implements FixedDemo {
    public void display() {
        System.out.println("Count: " + COUNT);
    }
}

public class Exercise_12_CommonMistakes {
    public static void main(String[] args) {
        // TODO: Identify and fix invalid interface declarations
        FixedDemo obj = new FixedClass();
        obj.display();
    }
}
