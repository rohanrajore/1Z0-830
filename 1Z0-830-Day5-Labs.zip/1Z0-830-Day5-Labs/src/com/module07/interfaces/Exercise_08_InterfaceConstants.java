package com.module07.interfaces;

interface AppSettings {
    int TIMEOUT = 30;
    String APP_NAME = "InterfaceDemo";
}

public class Exercise_08_InterfaceConstants {
    public static void main(String[] args) {
        // TODO: Print interface constants
        System.out.println("App: " + AppSettings.APP_NAME);
        System.out.println("Timeout: " + AppSettings.TIMEOUT);
    }
}
