package com.module07.interfaces;

interface Converter {
    static String toUpper(String s) {
        return s.toUpperCase();
    }
}

public class Exercise_05_StaticMethod {
    public static void main(String[] args) {
        // TODO: Call static method via interface
        System.out.println(Converter.toUpper("hello java"));
    }
}
