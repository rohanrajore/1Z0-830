package com.module07.interfaces;

interface Playable {
    void start();
    void stop();
}

class MusicPlayer implements Playable {
    public void start() { System.out.println("Music started"); }
    public void stop() { System.out.println("Music stopped"); }
}

public class Exercise_02_AbstractMethods {
    public static void main(String[] args) {
        // TODO: Implement abstract methods via a class
        Playable player = new MusicPlayer();
        player.start();
        player.stop();
    }
}
