package com.module07.interfaces;

interface DemoInterface {
    void abstractMethod(); // abstract

    default void defaultMethod() {
        System.out.println("Default method implementation");
    }

    static void staticMethod() {
        System.out.println("Static method in interface");
    }

    private void helper() {
        System.out.println("Private helper method");
    }

    default void useHelper() {
        helper();
    }
}

class DemoClass implements DemoInterface {
    public void abstractMethod() {
        System.out.println("Implemented abstract method");
    }
}

public class Exercise_07_MethodTypes {
    public static void main(String[] args) {
        // TODO: Identify accessible and overridable methods
        DemoClass obj = new DemoClass();
        obj.abstractMethod();
        obj.defaultMethod();
        obj.useHelper();
        DemoInterface.staticMethod();
    }
}
