package com.module07.interfaces;

interface A {
    default void show() { System.out.println("A"); }
}
interface B {
    default void show() { System.out.println("B"); }
}

class C implements A, B {
    @Override
    public void show() {
        System.out.println("C resolves conflict");
    }
}

public class Exercise_04_DefaultConflict {
    public static void main(String[] args) {
        // TODO: Resolve default method conflict
        new C().show();
    }
}
