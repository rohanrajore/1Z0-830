package com.module05.instance_of;

public class Exercise_06_MultiTypeCheck {
    public static void main(String[] args) {
        // TODO: Write a multi-type handler using pattern matching
        Object data = 42.5;

        if (data instanceof String s) {
            System.out.println("String: " + s);
        } else if (data instanceof Integer i) {
            System.out.println("Integer doubled: " + (i * 2));
        } else if (data instanceof Double d) {
            System.out.println("Double squared: " + (d * d));
        } else {
            System.out.println("Unknown type");
        }
    }
}
