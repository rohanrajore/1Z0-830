package com.module05.instance_of;

public class Exercise_03_FlowScope {
    public static void main(String[] args) {
        // TODO: Demonstrate flow scoping of pattern variable
        Object obj = "Java Flow Scoping";

        if (obj instanceof String s && s.length() > 5) {
            System.out.println("Valid string: " + s);
        }
        // System.out.println(s); // Uncomment to see compiler error (out of scope)
    }
}
