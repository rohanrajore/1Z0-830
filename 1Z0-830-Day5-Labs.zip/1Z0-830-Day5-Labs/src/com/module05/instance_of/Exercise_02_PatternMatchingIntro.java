package com.module05.instance_of;

public class Exercise_02_PatternMatchingIntro {
    public static void main(String[] args) {
        // TODO: Rewrite traditional instanceof using pattern matching
        Object obj = "Pattern Matching Simplified";

        if (obj instanceof String s) {
            System.out.println("Uppercase: " + s.toUpperCase());
        }
    }
}
