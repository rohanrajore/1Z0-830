package com.module05.instance_of;

public class Exercise_01_TraditionalTypeCheck {
    public static void main(String[] args) {
        // TODO: Demonstrate traditional instanceof + casting
        Object obj1 = "Hello";
        Object obj2 = 42;
        Object obj3 = 3.14;

        if (obj1 instanceof String) {
            String s = (String) obj1;
            System.out.println("String: " + s.toUpperCase());
        }
        if (obj2 instanceof Integer) {
            Integer i = (Integer) obj2;
            System.out.println("Integer doubled: " + (i * 2));
        }
        if (obj3 instanceof Double) {
            Double d = (Double) obj3;
            System.out.println("Double halved: " + (d / 2));
        }
    }
}
