package com.module05.instance_of;

sealed interface Shape permits Circle, Square {}

record Circle(double r) implements Shape {}
record Square(double s) implements Shape {}

public class Exercise_10_SealedSwitch {
    static double area(Shape shape) {
        // TODO: Combine sealed interface with pattern matching switch
        return switch (shape) {
            case Circle c -> Math.PI * c.r() * c.r();
            case Square s -> s.s() * s.s();
        };
    }

    public static void main(String[] args) {
        System.out.println("Circle area: " + area(new Circle(5)));
        System.out.println("Square area: " + area(new Square(4)));
    }
}
