package com.module05.instance_of;

public class Exercise_12_BestPractices {
    static String describe(Object obj) {
        // TODO: Refactor legacy type check using modern pattern matching
        return switch (obj) {
            case null -> "Null object";
            case String s -> "String length: " + s.length();
            case Integer i -> "Integer value: " + i;
            case Double d -> "Double value: " + d;
            default -> "Unknown type";
        };
    }

    public static void main(String[] args) {
        System.out.println(describe("Hello"));
        System.out.println(describe(10));
        System.out.println(describe(2.5));
        System.out.println(describe(null));
    }
}
