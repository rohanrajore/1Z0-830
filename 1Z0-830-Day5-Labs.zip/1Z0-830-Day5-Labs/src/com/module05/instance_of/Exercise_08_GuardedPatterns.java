package com.module05.instance_of;

public class Exercise_08_GuardedPatterns {
    static String classify(Object o) {
        // TODO: Use switch with guarded patterns
        return switch (o) {
            case String s when s.length() > 5 -> "Long string";
            case String s -> "Short string";
            case Integer i when i > 100 -> "Large number";
            case Integer i -> "Small number";
            default -> "Other type";
        };
    }

    public static void main(String[] args) {
        System.out.println(classify("Java21"));
        System.out.println(classify(150));
        System.out.println(classify("Hi"));
    }
}
