package com.module05.instance_of;

public class Exercise_11_CommonMistakes {
    public static void main(String[] args) {
        // TODO: Demonstrate invalid scope of pattern variable
        Object obj = "Scope test";

        if (obj instanceof String s) {
            System.out.println("Inside scope: " + s);
        }
        // System.out.println(s); // Uncomment to see scope error
    }
}
