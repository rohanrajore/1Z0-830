package com.module05.instance_of;

public class Exercise_05_LogicalPattern {
    public static void main(String[] args) {
        // TODO: Combine instanceof with logical operators
        Object obj = "Java21";

        if (obj instanceof String s && s.startsWith("J")) {
            System.out.println("Starts with J: " + s);
        } else if (obj instanceof String s && s.length() < 3) {
            System.out.println("Short string: " + s);
        } else {
            System.out.println("Other type");
        }
    }
}
