package com.module05.instance_of;

public class Exercise_04_NegatedCheck {
    public static void main(String[] args) {
        // TODO: Observe pattern variable scope in negated check
        Object obj = "Negation Example";

        if (!(obj instanceof String s)) {
            System.out.println("Not a string");
        } else {
            System.out.println("Uppercase: " + s.toUpperCase());
        }
    }
}
