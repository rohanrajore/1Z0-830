package com.module05.instance_of;

public class Exercise_07_SwitchPattern {
    static String formatData(Object obj) {
        // TODO: Use switch with pattern matching
        return switch (obj) {
            case Integer i -> "Integer squared: " + (i * i);
            case String s -> "Uppercase string: " + s.toUpperCase();
            case Double d -> "Double halved: " + (d / 2);
            case null -> "Null value";
            default -> "Unknown type";
        };
    }

    public static void main(String[] args) {
        System.out.println(formatData(5));
        System.out.println(formatData("hello"));
        System.out.println(formatData(8.0));
        System.out.println(formatData(null));
    }
}
