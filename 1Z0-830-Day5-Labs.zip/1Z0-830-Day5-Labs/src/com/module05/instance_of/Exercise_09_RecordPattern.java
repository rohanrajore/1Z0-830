package com.module05.instance_of;

record Person(String name, int age) {}

public class Exercise_09_RecordPattern {
    public static void main(String[] args) {
        // TODO: Use record pattern matching to print fields
        Object obj = new Person("Alice", 25);

        if (obj instanceof Person(String name, int age)) {
            System.out.println("Name: " + name + ", Age: " + age);
        }
    }
}
