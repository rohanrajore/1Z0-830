package com.module03.absclasses_methods;

abstract class Payment {
    abstract void process();
    void confirm() { System.out.println("Payment confirmed"); }
}

class CreditCardPayment extends Payment {
    void process() { System.out.println("Processing Credit Card payment"); }
}

class UPIPayment extends Payment {
    void process() { System.out.println("Processing UPI payment"); }
}

public class Exercise_13_BestPractices {
    public static void main(String[] args) {
        // TODO: Demonstrate proper subclass responsibility and super method use
        Payment p1 = new CreditCardPayment();
        Payment p2 = new UPIPayment();
        p1.process();
        p1.confirm();
        p2.process();
        p2.confirm();
    }
}
