package com.module03.absclasses_methods;

abstract class Account {
    abstract double calculateInterest(double amount);
    void printHeader() {
        System.out.println("=== Account Summary ===");
    }
}

class SavingsAccount extends Account {
    double calculateInterest(double amount) {
        return amount * 0.05;
    }
}

public class Exercise_08_MixedMethods {
    public static void main(String[] args) {
        // TODO: Use both abstract and concrete methods
        SavingsAccount sa = new SavingsAccount();
        sa.printHeader();
        System.out.println("Interest: " + sa.calculateInterest(10000));
    }
}
