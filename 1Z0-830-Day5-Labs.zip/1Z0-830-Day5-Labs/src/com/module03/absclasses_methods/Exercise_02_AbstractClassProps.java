package com.module03.absclasses_methods;

abstract class Animal {
    String name;
    Animal(String name) {
        this.name = name;
        System.out.println("Animal created: " + name);
    }
    abstract void sound();
}

class Cat extends Animal {
    Cat(String name) {
        super(name);
    }
    void sound() {
        System.out.println(name + " meows");
    }
}

public class Exercise_02_AbstractClassProps {
    public static void main(String[] args) {
        // TODO: Observe constructor behavior and inheritance
        new Cat("Whiskers").sound();
    }
}
