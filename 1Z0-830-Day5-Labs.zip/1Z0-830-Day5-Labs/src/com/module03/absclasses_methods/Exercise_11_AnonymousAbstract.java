package com.module03.absclasses_methods;

abstract class Task {
    abstract void execute();
}

public class Exercise_11_AnonymousAbstract {
    public static void main(String[] args) {
        // TODO: Create an anonymous subclass inline
        Task t = new Task() {
            void execute() {
                System.out.println("Anonymous task executed!");
            }
        };
        t.execute();
    }
}
