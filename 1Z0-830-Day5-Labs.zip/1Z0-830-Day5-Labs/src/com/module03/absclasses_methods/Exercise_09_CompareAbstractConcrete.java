package com.module03.absclasses_methods;

abstract class Report {
    abstract void generate();
}

class FinancialReport extends Report {
    void generate() {
        System.out.println("Generating financial report...");
    }
}

public class Exercise_09_CompareAbstractConcrete {
    public static void main(String[] args) {
        // TODO: Compare abstract vs concrete implementation
        Report r = new FinancialReport();
        r.generate();
    }
}
