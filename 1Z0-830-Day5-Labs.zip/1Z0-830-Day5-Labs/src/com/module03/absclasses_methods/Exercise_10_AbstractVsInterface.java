package com.module03.absclasses_methods;

abstract class Machine {
    abstract void operate();
}

interface Maintainable {
    void service();
}

class Robot extends Machine implements Maintainable {
    void operate() { System.out.println("Robot operating automatically"); }
    public void service() { System.out.println("Robot self-servicing"); }
}

public class Exercise_10_AbstractVsInterface {
    public static void main(String[] args) {
        // TODO: Implement both abstract class and interface
        Robot r = new Robot();
        r.operate();
        r.service();
    }
}
