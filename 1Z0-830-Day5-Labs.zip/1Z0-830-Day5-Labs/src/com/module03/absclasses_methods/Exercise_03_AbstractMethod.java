package com.module03.absclasses_methods;

abstract class Appliance {
    abstract void turnOn();
}

class Fan extends Appliance {
    void turnOn() {
        System.out.println("Fan starts rotating");
    }
}

class Light extends Appliance {
    void turnOn() {
        System.out.println("Light glows");
    }
}

public class Exercise_03_AbstractMethod {
    public static void main(String[] args) {
        // TODO: Implement and call abstract methods
        Appliance f = new Fan();
        Appliance l = new Light();
        f.turnOn();
        l.turnOn();
    }
}
