package com.module03.absclasses_methods;

// Incorrect examples (commented out)
// abstract class Demo {
//     static abstract void display(); // cannot be both static and abstract
// }

abstract class CorrectDemo {
    abstract void display();
}

class ImplementDemo extends CorrectDemo {
    void display() { System.out.println("Proper implementation"); }
}

public class Exercise_12_CommonMistakes {
    public static void main(String[] args) {
        // TODO: Fix invalid abstract declarations and test
        new ImplementDemo().display();
    }
}
