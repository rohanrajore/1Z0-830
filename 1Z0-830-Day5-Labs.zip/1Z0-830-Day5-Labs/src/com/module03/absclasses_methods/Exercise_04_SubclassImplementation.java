package com.module03.absclasses_methods;

abstract class Instrument {
    abstract void play();
}

class Guitar extends Instrument {
    void play() { System.out.println("Strumming the guitar"); }
}

class Drum extends Instrument {
    void play() { System.out.println("Beating the drum"); }
}

public class Exercise_04_SubclassImplementation {
    public static void main(String[] args) {
        // TODO: Create concrete subclasses implementing abstract methods
        Instrument g = new Guitar();
        Instrument d = new Drum();
        g.play();
        d.play();
    }
}
