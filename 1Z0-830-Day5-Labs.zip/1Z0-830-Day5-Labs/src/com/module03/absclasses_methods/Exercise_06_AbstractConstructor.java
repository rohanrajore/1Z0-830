package com.module03.absclasses_methods;

abstract class Device {
    String model;
    Device(String model) {
        this.model = model;
        System.out.println("Device initialized: " + model);
    }
}

class Phone extends Device {
    Phone(String model) {
        super(model);
        System.out.println("Phone ready for use");
    }
}

public class Exercise_06_AbstractConstructor {
    public static void main(String[] args) {
        // TODO: Demonstrate constructor chaining in abstract class
        new Phone("Pixel 9 Pro");
    }
}
