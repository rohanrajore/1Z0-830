package com.module03.absclasses_methods;

abstract class Shape {
    abstract double area();
    void display() {
        System.out.println("Displaying shape details...");
    }
}

class Rectangle extends Shape {
    double width = 5, height = 3;
    double area() { return width * height; }
}

public class Exercise_01_AbstractClassIntro {
    public static void main(String[] args) {
        // TODO: Demonstrate abstract method and concrete method
        Shape s = new Rectangle();
        s.display();
        System.out.println("Area: " + s.area());
    }
}
