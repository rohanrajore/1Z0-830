package com.module03.absclasses_methods;

abstract class Vehicle {
    abstract void start();
}

abstract class LandVehicle extends Vehicle {
    void wheels() {
        System.out.println("Land vehicles have wheels");
    }
}

class Car extends LandVehicle {
    void start() {
        System.out.println("Car engine starts");
    }
}

public class Exercise_07_AbstractHierarchy {
    public static void main(String[] args) {
        // TODO: Demonstrate abstract hierarchy with partial implementation
        Car car = new Car();
        car.wheels();
        car.start();
    }
}
