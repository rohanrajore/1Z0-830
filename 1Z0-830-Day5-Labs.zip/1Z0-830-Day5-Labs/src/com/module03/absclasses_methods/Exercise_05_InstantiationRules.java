package com.module03.absclasses_methods;

abstract class Bird {
    Bird() { System.out.println("Bird constructor called"); }
    abstract void fly();
}

class Eagle extends Bird {
    void fly() { System.out.println("Eagle soars high!"); }
}

public class Exercise_05_InstantiationRules {
    public static void main(String[] args) {
        // TODO: Observe instantiation through subclass
        // Bird b = new Bird(); // invalid
        Bird e = new Eagle();
        e.fly();
    }
}
