package com.module04.sealed_classes;

sealed class Vehicle permits Car, Bike {}

final class Car extends Vehicle {
    void drive() { System.out.println("Car drives smoothly"); }
}

final class Bike extends Vehicle {
    void ride() { System.out.println("Bike zooms fast"); }
}

public class Exercise_01_SealedIntro {
    public static void main(String[] args) {
        // TODO: Demonstrate sealed class with limited permitted subclasses
        Vehicle v1 = new Car();
        Vehicle v2 = new Bike();
        ((Car)v1).drive();
        ((Bike)v2).ride();
    }
}
