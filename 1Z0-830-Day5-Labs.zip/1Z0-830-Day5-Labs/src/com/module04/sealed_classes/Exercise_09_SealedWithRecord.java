package com.module04.sealed_classes;

sealed interface Vehicle2 permits CarRecord, BikeRecord {}

record CarRecord(String model, int year) implements Vehicle2 {}
record BikeRecord(String brand, double engineCapacity) implements Vehicle2 {}

public class Exercise_09_SealedWithRecord {
    public static void main(String[] args) {
        // TODO: Use records as permitted subclasses of sealed interface
        Vehicle2 v1 = new CarRecord("Tesla Model 3", 2024);
        Vehicle2 v2 = new BikeRecord("Yamaha", 250.0);
        System.out.println(v1);
        System.out.println(v2);
    }
}
