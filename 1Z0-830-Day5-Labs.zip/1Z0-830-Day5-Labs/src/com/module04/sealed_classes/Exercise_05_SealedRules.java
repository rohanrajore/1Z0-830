package com.module04.sealed_classes;

// sealed class Tool permits Hammer {} // Uncommenting missing subclasses causes compile error
sealed class Tool permits Hammer, Drill {}

final class Hammer extends Tool {}
non-sealed class Drill extends Tool {}

public class Exercise_05_SealedRules {
    public static void main(String[] args) {
        // TODO: Observe rule enforcement for sealed classes
        Tool t1 = new Hammer();
        Tool t2 = new Drill();
        System.out.println("Tools created: " + t1.getClass().getSimpleName() + ", " + t2.getClass().getSimpleName());
    }
}
