package com.module04.sealed_classes;

sealed class Shape permits Circle, Square, Rectangle {}

final class Circle extends Shape {}
non-sealed class Square extends Shape {}
sealed class Rectangle extends Shape permits FilledRectangle {}
final class FilledRectangle extends Rectangle {}

public class Exercise_03_PermittedSubclasses {
    public static void main(String[] args) {
        // TODO: Show hierarchy of permitted subclasses
        Shape s1 = new Circle();
        Shape s2 = new Square();
        Shape s3 = new FilledRectangle();
        System.out.println("Instances created for: " +
            s1.getClass().getSimpleName() + ", " +
            s2.getClass().getSimpleName() + ", " +
            s3.getClass().getSimpleName());
    }
}
