package com.module04.sealed_classes;

// abstract hierarchy
abstract class Person { abstract void role(); }
class Teacher extends Person { void role() { System.out.println("Teaching students"); } }

// final hierarchy
final class ConstantClass { void info() { System.out.println("Cannot be extended"); } }

// sealed hierarchy
sealed class Transport permits Bus, Train {}
final class Bus extends Transport {}
final class Train extends Transport {}

public class Exercise_10_SealedVsOthers {
    public static void main(String[] args) {
        // TODO: Compare abstract, final, and sealed inheritance control
        new Teacher().role();
        new ConstantClass().info();
        System.out.println("Sealed types: " + new Bus().getClass().getSimpleName() + ", " + new Train().getClass().getSimpleName());
    }
}
