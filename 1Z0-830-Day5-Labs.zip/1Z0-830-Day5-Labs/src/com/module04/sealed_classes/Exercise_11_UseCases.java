package com.module04.sealed_classes;

sealed class Document permits PDF, Word, Text {}

final class PDF extends Document {}
final class Word extends Document {}
final class Text extends Document {}

public class Exercise_11_UseCases {
    public static void main(String[] args) {
        // TODO: Model sealed hierarchy for document types
        Document d = new PDF();
        System.out.println("Document type: " + d.getClass().getSimpleName());
    }
}
