//package com.module04.sealed_classes;
//
//sealed class Appliance permits Fan, Heater, Cooler {}
//
//final class Fan extends Appliance {}
//non-sealed class Heater extends Appliance {}
//// Next line would cause error if uncommented: class Lamp extends Fan {}
//
//class Cooler extends Appliance {}
//
//public class Exercise_04_SealedKeywords {
//    public static void main(String[] args) {
//        // TODO: Test sealed, final, and non-sealed subclass behavior
//        Appliance a1 = new Fan();
//        Appliance a2 = new Heater();
//        Appliance a3 = new Cooler();
//        System.out.println(a1.getClass().getSimpleName() + ", " +
//                           a2.getClass().getSimpleName() + ", " +
//                           a3.getClass().getSimpleName());
//    }
//}
