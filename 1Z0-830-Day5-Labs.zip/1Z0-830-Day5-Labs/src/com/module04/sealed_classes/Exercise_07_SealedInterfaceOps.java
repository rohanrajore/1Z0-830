package com.module04.sealed_classes;

sealed interface PaymentMethod permits UPI, Card, Cash {}

final class UPI implements PaymentMethod {}
final class Card implements PaymentMethod {}
final class Cash implements PaymentMethod {}

public class Exercise_07_SealedInterfaceOps {
    public static void main(String[] args) {
        // TODO: Implement a sealed interface with limited implementations
        PaymentMethod m = new Card();
        System.out.println("Payment method: " + m.getClass().getSimpleName());
    }
}
