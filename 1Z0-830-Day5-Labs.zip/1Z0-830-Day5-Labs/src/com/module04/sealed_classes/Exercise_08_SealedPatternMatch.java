package com.module04.sealed_classes;

sealed interface Shape2 permits Circle2, Rectangle2 {}

record Circle2(double r) implements Shape2 {}
record Rectangle2(double w, double h) implements Shape2 {}

public class Exercise_08_SealedPatternMatch {
    static double area(Shape2 s) {
        // TODO: Use pattern-matching switch with sealed interface
        return switch (s) {
            case Circle2 c -> Math.PI * c.r() * c.r();
            case Rectangle2 r -> r.w() * r.h();
        };
    }

    public static void main(String[] args) {
        System.out.println("Circle area: " + area(new Circle2(5)));
        System.out.println("Rectangle area: " + area(new Rectangle2(4, 6)));
    }
}
