package com.module04.sealed_classes;

// Abstract version
abstract class Animal {}
class Dog extends Animal {}
class Cat extends Animal {}

// Sealed version
sealed class Creature permits Human, Alien {}
final class Human extends Creature {}
final class Alien extends Creature {}

public class Exercise_02_WhySealed {
    public static void main(String[] args) {
        // TODO: Compare normal vs sealed class inheritance control
        Animal a = new Dog();
        Creature c = new Human();
        System.out.println("Animal subclass: " + a.getClass().getSimpleName());
        System.out.println("Creature subclass: " + c.getClass().getSimpleName());
    }
}
