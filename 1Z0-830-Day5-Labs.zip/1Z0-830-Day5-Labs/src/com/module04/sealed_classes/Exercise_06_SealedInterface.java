package com.module04.sealed_classes;

sealed interface Device permits Laptop, Tablet {}

final class Laptop implements Device {}
non-sealed class Tablet implements Device {}

class FoldableTablet extends Tablet {}

public class Exercise_06_SealedInterface {
    public static void main(String[] args) {
        // TODO: Demonstrate sealed interface implementation hierarchy
        Device d1 = new Laptop();
        Device d2 = new FoldableTablet();
        System.out.println("Devices: " + d1.getClass().getSimpleName() + ", " + d2.getClass().getSimpleName());
    }
}
