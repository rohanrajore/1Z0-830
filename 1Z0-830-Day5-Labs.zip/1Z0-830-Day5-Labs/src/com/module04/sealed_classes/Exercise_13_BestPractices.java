package com.module04.sealed_classes;

sealed interface Notification permits EmailNotification, SMSNotification, PushNotification {}

final class EmailNotification implements Notification {}
final class SMSNotification implements Notification {}
non-sealed class PushNotification implements Notification {}

class AppPushNotification extends PushNotification {}

public class Exercise_13_BestPractices {
    public static void main(String[] args) {
        // TODO: Demonstrate sealed hierarchy with non-sealed subclass flexibility
        Notification n1 = new EmailNotification();
        Notification n2 = new AppPushNotification();
        System.out.println("Notifications: " + n1.getClass().getSimpleName() + ", " + n2.getClass().getSimpleName());
    }
}
