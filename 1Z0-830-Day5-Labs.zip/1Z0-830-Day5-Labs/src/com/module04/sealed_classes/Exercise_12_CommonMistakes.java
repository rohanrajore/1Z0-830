package com.module04.sealed_classes;

// Incorrect version (commented out)
// sealed class Shape permits Circle {} // Rectangle not listed causes error
// final class Rectangle extends Shape {}

sealed class Shape1 permits Circle1, Rectangle1 {}
final class Circle1 extends Shape1 {}
final class Rectangle1 extends Shape1 {}

public class Exercise_12_CommonMistakes {
    public static void main(String[] args) {
        // TODO: Fix subclass configuration to make it compile
        Shape1 s = new Rectangle1();
        System.out.println("Valid subclass: " + s.getClass().getSimpleName());
    }
}
