package com.module01.string_immutability;

public class Exercise_04_InternPerformance {
    public static void main(String[] args) {
        System.out.println("=== Exercise 04: Intern() Performance Demo ===");

        // TODO 1: Create repeated strings without intern()
        long start1 = System.nanoTime();
        for (int i = 0; i < 10000; i++) {
            String s = new String("Repeat" + (i % 100));
        }
        long time1 = System.nanoTime() - start1;

        // TODO 2: Create repeated strings with intern()
        long start2 = System.nanoTime();
        for (int i = 0; i < 10000; i++) {
            String s = new String("Repeat" + (i % 100)).intern();
        }
        long time2 = System.nanoTime() - start2;

        System.out.printf("Without intern(): %.3f ms%n", time1 / 1_000_000.0);
        System.out.printf("With intern(): %.3f ms%n", time2 / 1_000_000.0);
        System.out.println("(Interning reduces duplicates but may cost time for lookup)");
    }
}
