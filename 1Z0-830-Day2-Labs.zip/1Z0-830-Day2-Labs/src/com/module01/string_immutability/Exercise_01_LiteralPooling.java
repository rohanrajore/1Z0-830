package com.module01.string_immutability;

public class Exercise_01_LiteralPooling {
    public static void main(String[] args) {
        System.out.println("=== Exercise 01: Literal Pooling ===");

        // TODO 1: Create two literal strings
        String s1 = "Learn";
        String s2 = "Learn";

        // TODO 2: Create a new string object using 'new' keyword
        String s3 = new String("Learn");

        // Print comparisons
        System.out.println("s1 == s2 : " + (s1 == s2));   // true (both from SCP)
        System.out.println("s1 == s3 : " + (s1 == s3));   // false (new heap object)
        System.out.println("s1.equals(s3): " + s1.equals(s3)); // true (content same)
    }
}
