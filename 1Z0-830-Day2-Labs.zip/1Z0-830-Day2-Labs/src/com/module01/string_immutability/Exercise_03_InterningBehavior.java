package com.module01.string_immutability;

public class Exercise_03_InterningBehavior {
    public static void main(String[] args) {
        System.out.println("=== Exercise 03: Interning Behavior ===");

        // TODO 1: Create one literal and one heap string
        String s1 = new String("Hello");
        String s2 = "Hello";

        // TODO 2: Compare before interning
        System.out.println("Before intern -> s1 == s2 : " + (s1 == s2)); // false

        // TODO 3: Compare after interning
        String s3 = s1.intern();
        System.out.println("After intern -> s3 == s2 : " + (s3 == s2)); // true
    }
}
