package com.module01.string_immutability;

public class Exercise_02_StringConcatImmutability {
    public static void main(String[] args) {
        System.out.println("=== Exercise 02: String Immutability with concat() ===");

        // TODO 1: Create a string
        String s = "Java";

        // TODO 2: Try to modify using concat()
        s.concat("21");

        // TODO 3: Print original reference
        System.out.println("After concat(), s = " + s); // "Java" — unchanged

        // TODO 4: Store result of concat() in a new variable
        String s2 = s.concat("21");

        System.out.println("New string: " + s2);
        System.out.println("Same reference? " + (s == s2)); // false
    }
}
