package com.module01.string_immutability;

public class Exercise_05_StringCreation {
    public static void main(String[] args) {
        System.out.println("=== Exercise 05: String Creation Techniques ===");

        // TODO 1: Create strings in different ways
        String a = "Hi";                // literal in SCP
        String b = new String("Hi");    // new heap object
        String c = b.intern();          // refers to SCP entry

        // TODO 2: Compare references
        System.out.println("a == b : " + (a == b)); // false
        System.out.println("a == c : " + (a == c)); // true
        System.out.println("a.equals(b): " + a.equals(b)); // true
    }
}
