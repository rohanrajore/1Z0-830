package com.module01.string_immutability;

public class Exercise_07_MemoryTracing {
    public static void main(String[] args) {
        System.out.println("=== Exercise 07: Memory Tracing ===");

        // TODO 1: Create a heap object and a pool literal
        String heapString = new String("Java");
        String pooledString = "Java";

        // TODO 2: Print reference equality
        System.out.println("heapString == pooledString : " + (heapString == pooledString));

        // TODO 3: Intern heap string
        String interned = heapString.intern();

        // TODO 4: Check equality again
        System.out.println("After intern -> interned == pooledString : " + (interned == pooledString));

        // TODO 5: Visual hint for learners
        System.out.println("\nMemory Diagram:");
        System.out.println("Heap:        new String(\"Java\") → [J][a][v][a]");
        System.out.println("String Pool: \"Java\" → shared literal reference");
    }
}
