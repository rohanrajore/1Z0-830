package com.module01.string_immutability;

public class Exercise_06_EqualsVsDoubleEquals {
    public static void main(String[] args) {
        System.out.println("=== Exercise 06: == vs .equals() ===");

        // TODO 1: Create strings using literal and new
        String x = "Test";
        String y = new String("Test");

        // TODO 2: Compare references and contents
        System.out.println("x == y : " + (x == y));           // false
        System.out.println("x.equals(y): " + x.equals(y));    // true

        // TODO 3: Intern y and recheck
        System.out.println("x == y.intern(): " + (x == y.intern())); // true
    }
}
