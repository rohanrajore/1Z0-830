package com.module11.period_duration_dst;


import java.time.*;

public class Exercise_01_PeriodVsDuration {
    public static void main(String[] args) {
        System.out.println("=== Exercise 01: Period vs Duration ===");

        // TODO 1: Create two LocalDate objects (start and end)
        LocalDate startDate = LocalDate.of(2025, 1, 1);
        LocalDate endDate = LocalDate.of(2025, 10, 21);

        // TODO 2: Compute the Period between them
        Period period = Period.between(startDate, endDate);
        System.out.println("Period between: " + period);

        // TODO 3: Create two LocalTime objects and compute Duration
        LocalTime startTime = LocalTime.of(9, 0);
        LocalTime endTime = LocalTime.of(17, 30);

        Duration duration = Duration.between(startTime, endTime);
        System.out.println("Duration between: " + duration);

        // TODO 4: Print human vs machine time interpretation
        System.out.println("Period (human-readable): " +
                period.getMonths() + " months and " + period.getDays() + " days");
        System.out.println("Duration (machine-readable): " + duration.toHours() + " hours");
    }
}

