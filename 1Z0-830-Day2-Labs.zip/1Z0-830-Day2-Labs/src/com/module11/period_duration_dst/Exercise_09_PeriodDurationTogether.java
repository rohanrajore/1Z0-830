package com.module11.period_duration_dst;


import java.time.*;

public class Exercise_09_PeriodDurationTogether {
    public static void main(String[] args) {
        System.out.println("=== Exercise 09: Combining Period and Duration ===");

        // TODO 1: Use ZonedDateTime for start and now
        ZonedDateTime start = ZonedDateTime.of(2025, 1, 1, 8, 0, 0, 0, ZoneId.of("Asia/Kolkata"));
        ZonedDateTime end = ZonedDateTime.now();

        // TODO 2: Compute both Period and Duration
        Period dateGap = Period.between(start.toLocalDate(), end.toLocalDate());
        Duration timeGap = Duration.between(start.toLocalTime(), end.toLocalTime());

        // TODO 3: Print formatted output
        System.out.println("Elapsed Date Gap: " + dateGap);
        System.out.println("Elapsed Time Gap: " + timeGap.toHours() + " hours");
    }
}

