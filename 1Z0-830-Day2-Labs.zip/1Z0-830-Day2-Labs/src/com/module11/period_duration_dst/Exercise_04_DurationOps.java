package com.module11.period_duration_dst;


import java.time.*;

public class Exercise_04_DurationOps {
    public static void main(String[] args) {
        System.out.println("=== Exercise 04: Duration Operations ===");

        // TODO 1: Create two LocalTime instances
        LocalTime login = LocalTime.of(9, 15);
        LocalTime logout = LocalTime.of(18, 45);

        // TODO 2: Compute Duration between them
        Duration d = Duration.between(login, logout);

        // TODO 3: Print duration details
        System.out.println("Duration: " + d);
        System.out.println("Hours worked: " + d.toHours());
        System.out.println("Minutes worked: " + d.toMinutes());
    }
}

