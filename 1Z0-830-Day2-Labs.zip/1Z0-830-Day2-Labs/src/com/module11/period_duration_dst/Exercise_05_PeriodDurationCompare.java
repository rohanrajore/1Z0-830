package com.module11.period_duration_dst;


import java.time.*;

public class Exercise_05_PeriodDurationCompare {
    public static void main(String[] args) {
        System.out.println("=== Exercise 05: Comparing Period and Duration ===");

        // TODO 1: Use LocalDateTime for start and end
        LocalDateTime start = LocalDateTime.of(2025, 1, 1, 9, 0);
        LocalDateTime end = LocalDateTime.of(2025, 10, 21, 17, 0);

        // TODO 2: Derive Period and Duration
        Period p = Period.between(start.toLocalDate(), end.toLocalDate());
        Duration d = Duration.between(start, end);

        // TODO 3: Compare results
        System.out.println("Period: " + p);
        System.out.println("Duration: " + d.toDays() + " days (" + d.toHours() + " hours)");
    }
}
