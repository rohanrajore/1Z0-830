package com.module11.period_duration_dst;


import java.time.*;

public class Exercise_08_DSTAdjustments {
    public static void main(String[] args) {
        System.out.println("=== Exercise 08: DST Adjustments ===");

        // TODO 1: Create ZonedDateTime during fall-back in London
        ZoneId london = ZoneId.of("Europe/London");
        ZonedDateTime start = ZonedDateTime.of(2025, 10, 26, 1, 0, 0, 0, london);
        ZonedDateTime end = start.plusHours(2);

        // TODO 2: Compute Duration difference
        Duration diff = Duration.between(start, end);
        System.out.println("Start: " + start);
        System.out.println("End: " + end);
        System.out.println("Duration (hours): " + diff.toHours());
    }
}
