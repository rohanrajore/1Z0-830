package com.module11.period_duration_dst;


import java.time.*;

public class Exercise_02_PeriodOps {
    public static void main(String[] args) {
        System.out.println("=== Exercise 02: Period Operations ===");

        // TODO 1: Create LocalDate of end of month
        LocalDate endOfMonth = LocalDate.of(2025, 1, 31);

        // TODO 2: Add and subtract different Periods
        Period addThreeMonths = Period.ofMonths(3);
        Period subtractTwoWeeks = Period.ofWeeks(2);

        LocalDate afterAdding = endOfMonth.plus(addThreeMonths);
        LocalDate afterSubtracting = endOfMonth.minus(subtractTwoWeeks);

        // TODO 3: Print results and note month rollover
        System.out.println("Original date: " + endOfMonth);
        System.out.println("After adding 3 months: " + afterAdding);
        System.out.println("After subtracting 2 weeks: " + afterSubtracting);
    }
}

