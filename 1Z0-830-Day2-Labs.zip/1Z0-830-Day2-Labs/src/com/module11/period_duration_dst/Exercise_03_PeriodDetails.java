package com.module11.period_duration_dst;


import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Exercise_03_PeriodDetails {
    public static void main(String[] args) {
        System.out.println("=== Exercise 03: Period Details and Components ===");
        Scanner sc = new Scanner(System.in);

        // TODO 1: Get two birthdays
        System.out.print("Enter first date (YYYY-MM-DD): ");
        LocalDate d1 = LocalDate.parse(sc.nextLine());

        System.out.print("Enter second date (YYYY-MM-DD): ");
        LocalDate d2 = LocalDate.parse(sc.nextLine());

        // TODO 2: Compute and print Period components
        Period diff = Period.between(d1, d2);
        System.out.printf("Difference: %d years, %d months, %d days%n",
                diff.getYears(), diff.getMonths(), diff.getDays());

        // TODO 3: Print total days using ChronoUnit
        long totalDays = ChronoUnit.DAYS.between(d1, d2);
        System.out.println("Total days: " + totalDays);

        sc.close();
    }
}

