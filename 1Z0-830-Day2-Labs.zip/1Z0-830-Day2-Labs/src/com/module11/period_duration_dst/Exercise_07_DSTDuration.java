package com.module11.period_duration_dst;


import java.time.*;

public class Exercise_07_DSTDuration {
    public static void main(String[] args) {
        System.out.println("=== Exercise 07: Daylight Saving Duration ===");

        // TODO 1: Create ZonedDateTime before and after DST shift
        ZoneId zone = ZoneId.of("America/New_York");
        ZonedDateTime beforeDST = ZonedDateTime.of(2025, 3, 9, 1, 30, 0, 0, zone);
        ZonedDateTime afterDST = beforeDST.plusHours(2);

        // TODO 2: Compute Duration
        Duration diff = Duration.between(beforeDST, afterDST);
        System.out.println("Before DST: " + beforeDST);
        System.out.println("After DST: " + afterDST);
        System.out.println("Duration hours: " + diff.toHours());
    }
}
