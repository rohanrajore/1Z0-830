package com.module11.period_duration_dst;


import java.time.*;
import java.time.temporal.ChronoUnit;

public class Exercise_06_ChronoUnit {
    public static void main(String[] args) {
        System.out.println("=== Exercise 06: Using ChronoUnit ===");

        // TODO 1: Compute between two dates
        LocalDate startDate = LocalDate.of(2025, 1, 1);
        LocalDate endDate = LocalDate.of(2025, 10, 21);

        System.out.println("Days between: " + ChronoUnit.DAYS.between(startDate, endDate));
        System.out.println("Months between: " + ChronoUnit.MONTHS.between(startDate, endDate));
        System.out.println("Years between: " + ChronoUnit.YEARS.between(startDate, endDate));

        // TODO 2: Compute between two times
        LocalTime t1 = LocalTime.of(9, 0);
        LocalTime t2 = LocalTime.of(17, 30);
        System.out.println("Hours between: " + ChronoUnit.HOURS.between(t1, t2));
        System.out.println("Minutes between: " + ChronoUnit.MINUTES.between(t1, t2));
    }
}

