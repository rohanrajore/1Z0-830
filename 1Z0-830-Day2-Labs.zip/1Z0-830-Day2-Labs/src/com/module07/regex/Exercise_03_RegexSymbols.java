package com.module07.regex;


import java.util.regex.*;

public class Exercise_03_RegexSymbols {
    public static void main(String[] args) {
        System.out.println("=== Exercise 03: Common Regex Symbols ===");

        // TODO 1: Use . (dot) to match any character
        Pattern anyChar = Pattern.compile("a.b");
        Matcher m1 = anyChar.matcher("acb a_b a-b a b");
        while (m1.find()) {
            System.out.println("Dot match: " + m1.group());
        }

        // TODO 2: Match digits using \\d
        Pattern digits = Pattern.compile("\\d+");
        Matcher m2 = digits.matcher("My PIN is 4321 and OTP is 9876");
        while (m2.find()) {
            System.out.println("Digit match: " + m2.group());
        }

        // TODO 3: Match words using \\w+
        Pattern words = Pattern.compile("\\w+");
        Matcher m3 = words.matcher("Regex_123 basics!");
        while (m3.find()) {
            System.out.println("Word match: " + m3.group());
        }
    }
}

