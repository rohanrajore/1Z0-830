package com.module07.regex;


import java.util.regex.*;

public class Exercise_08_RegexFlags {
    public static void main(String[] args) {
        System.out.println("=== Exercise 08: Regex Flags ===");

        // TODO 1: Case-insensitive search
        Pattern p = Pattern.compile("java", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher("I love JAVA, JavaScript, and jaVa frameworks!");
        while (m.find()) {
            System.out.println("Matched (ignore case): " + m.group());
        }

        // TODO 2: DOTALL mode to include newline
        String multi = "Line1\nLine2\nJavaHere";
        Pattern dotAll = Pattern.compile("Line1.*JavaHere", Pattern.DOTALL);
        System.out.println("\nDOTALL mode match? " + dotAll.matcher(multi).matches());
    }
}

