package com.module07.regex;


import java.util.regex.*;

public class Exercise_04_Quantifiers {
    public static void main(String[] args) {
        System.out.println("=== Exercise 04: Quantifiers and Character Classes ===");

        // TODO 1: Match varying lengths of digits
        Pattern p = Pattern.compile("\\d{2,4}");
        Matcher m = p.matcher("Years: 21, 2025, 305, 99, 1");

        while (m.find()) {
            System.out.println("Matched digits: " + m.group());
        }

        // TODO 2: Try word patterns
        Pattern wordPattern = Pattern.compile("[A-Z][a-z]+");
        Matcher m2 = wordPattern.matcher("Cities: London Paris newYork Delhi");
        while (m2.find()) {
            System.out.println("Word match: " + m2.group());
        }
    }
}

