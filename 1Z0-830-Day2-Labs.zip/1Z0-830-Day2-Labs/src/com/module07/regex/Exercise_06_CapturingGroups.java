package com.module07.regex;


import java.util.regex.*;

public class Exercise_06_CapturingGroups {
    public static void main(String[] args) {
        System.out.println("=== Exercise 06: Capturing Groups ===");

        // TODO 1: Create pattern for email
        Pattern p = Pattern.compile("(\\w+)@(\\w+\\.\\w+)");
        Matcher m = p.matcher("Contact: support@learnato.com and info@java.org");

        // TODO 2: Extract username and domain
        while (m.find()) {
            System.out.println("Full match: " + m.group(0));
            System.out.println("User: " + m.group(1));
            System.out.println("Domain: " + m.group(2));
            System.out.println("-----");
        }
    }
}

