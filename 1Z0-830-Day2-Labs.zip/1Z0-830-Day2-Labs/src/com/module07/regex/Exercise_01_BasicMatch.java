package com.module07.regex;


import java.util.regex.*;

public class Exercise_01_BasicMatch {
    public static void main(String[] args) {
        System.out.println("=== Exercise 01: Basic Regex Match ===");

        // TODO 1: Create a pattern to search for a specific word
        Pattern p = Pattern.compile("Java");

        // TODO 2: Create a matcher for given sentence
        Matcher m = p.matcher("I love Java programming!");

        // TODO 3: Print if match is found
        System.out.println("Contains 'Java'? " + m.find());
    }
}


