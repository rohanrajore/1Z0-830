package com.module07.regex;


import java.util.regex.*;

public class Exercise_02_PatternMatcherFlow {
    public static void main(String[] args) {
        System.out.println("=== Exercise 02: Pattern and Matcher Workflow ===");

        // TODO 1: Create a pattern to find digits
        Pattern pattern = Pattern.compile("\\d+");

        // TODO 2: Create a matcher with sample input
        Matcher matcher = pattern.matcher("There are 25 students and 3 teachers.");

        // TODO 3: Use find() in a loop to print all matches
        while (matcher.find()) {
            System.out.println("Found number: " + matcher.group());
        }
    }
}

