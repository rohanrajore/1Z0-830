package com.module07.regex;


import java.util.regex.*;

public class Exercise_09_RealWorldPatterns {
    public static void main(String[] args) {
        System.out.println("=== Exercise 09: Real World Patterns ===");

        // TODO 1: Email validation
        Pattern email = Pattern.compile("^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
        System.out.println("Email valid? " + email.matcher("rohan@learnato.com").matches());

        // TODO 2: Phone number validation
        Pattern phone = Pattern.compile("^\\d{10}$");
        System.out.println("Phone valid? " + phone.matcher("9876543210").matches());

        // TODO 3: Date validation (YYYY-MM-DD)
        Pattern date = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");
        System.out.println("Date valid? " + date.matcher("2025-10-21").matches());
    }
}

