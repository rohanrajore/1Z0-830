package com.module07.regex;


import java.util.regex.*;

public class Exercise_07_MatcherMethods {
    public static void main(String[] args) {
        System.out.println("=== Exercise 07: Useful Matcher Methods ===");

        // TODO 1: Create matcher for numeric sequence
        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher("A12B345C6");

        // TODO 2: Print group, start, end positions
        while (m.find()) {
            System.out.println("Found " + m.group() + " at position " + m.start() + "-" + (m.end() - 1));
        }

        // TODO 3: Print group count (if any)
        System.out.println("Group count: " + m.groupCount());
    }
}

