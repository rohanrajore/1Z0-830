package com.module07.regex;


import java.util.regex.*;

public class Exercise_05_FindVsMatches {
    public static void main(String[] args) {
        System.out.println("=== Exercise 05: find() vs matches() ===");

        // TODO 1: Create pattern for digits
        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher("ID: 101, Code: 202, Pin: 303");

        // TODO 2: Using find()
        System.out.println("Using find():");
        while (m.find()) {
            System.out.println("Found: " + m.group());
        }

        // TODO 3: Using matches()
        Matcher m2 = p.matcher("12345");
        System.out.println("\nUsing matches(): " + m2.matches());
    }
}

