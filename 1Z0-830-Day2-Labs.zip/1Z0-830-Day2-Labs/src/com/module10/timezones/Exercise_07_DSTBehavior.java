package com.module10.timezones;

import java.time.*;

public class Exercise_07_DSTBehavior {
    public static void main(String[] args) {
        System.out.println("=== Exercise 07: Daylight Saving Time Behavior ===");

        // TODO 1: Choose a DST-affected zone (e.g., New York)
        ZoneId ny = ZoneId.of("America/New_York");

        // TODO 2: Create times before and after DST
        ZonedDateTime beforeDST = ZonedDateTime.of(2025, 3, 9, 1, 30, 0, 0, ny);
        ZonedDateTime afterDST = beforeDST.plusHours(2);

        System.out.println("Before DST: " + beforeDST);
        System.out.println("After DST (+2h): " + afterDST);
        System.out.println("Actual hour difference (considering DST): " +
                Duration.between(beforeDST, afterDST).toHours() + " hour(s)");
    }
}
