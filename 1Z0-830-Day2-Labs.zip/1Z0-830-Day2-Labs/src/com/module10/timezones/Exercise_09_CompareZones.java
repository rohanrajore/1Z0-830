package com.module10.timezones;

import java.time.*;

public class Exercise_09_CompareZones {
    public static void main(String[] args) {
        System.out.println("=== Exercise 09: Comparing ZonedDateTimes ===");

        // TODO 1: Create same instant in two zones
        ZonedDateTime india = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
        ZonedDateTime london = india.withZoneSameInstant(ZoneId.of("Europe/London"));

        // TODO 2: Compare them
        System.out.println("India Time:  " + india);
        System.out.println("London Time: " + london);
        System.out.println("isEqual()? " + india.isEqual(london)); // true
        System.out.println("isBefore()? " + india.isBefore(london));
        System.out.println("isAfter()? " + india.isAfter(london));
    }
}
