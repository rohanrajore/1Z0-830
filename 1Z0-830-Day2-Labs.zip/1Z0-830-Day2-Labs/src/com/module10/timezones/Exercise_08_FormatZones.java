package com.module10.timezones;

import java.time.*;
import java.time.format.DateTimeFormatter;

public class Exercise_08_FormatZones {
    public static void main(String[] args) {
        System.out.println("=== Exercise 08: Formatting ZonedDateTime ===");

        // TODO 1: Create a ZonedDateTime
        ZonedDateTime zdt = ZonedDateTime.now();

        // TODO 2: Format with different patterns
        DateTimeFormatter fmt1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm z");
        DateTimeFormatter fmt2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm O");
        DateTimeFormatter fmt3 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm VV");

        System.out.println("Format (z): " + zdt.format(fmt1));
        System.out.println("Format (O): " + zdt.format(fmt2));
        System.out.println("Format (VV): " + zdt.format(fmt3));
    }
}
