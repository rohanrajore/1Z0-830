package com.module10.timezones;

import java.time.ZoneId;
import java.util.Set;

public class Exercise_01_WhyTimeZones {
    public static void main(String[] args) {
        System.out.println("=== Exercise 01: Why Time Zones Matter ===");

        // TODO 1: Print system default time zone
        System.out.println("System Default Zone: " + ZoneId.systemDefault());

        // TODO 2: Print sample regions
        ZoneId india = ZoneId.of("Asia/Kolkata");
        ZoneId london = ZoneId.of("Europe/London");
        ZoneId ny = ZoneId.of("America/New_York");

        System.out.println("India Zone: " + india);
        System.out.println("London Zone: " + london);
        System.out.println("New York Zone: " + ny);

        // TODO 3: Display total number of zones available
        Set<String> zones = ZoneId.getAvailableZoneIds();
        System.out.println("Total available zones: " + zones.size());
    }
}
