package com.module10.timezones;

import java.time.*;

public class Exercise_04_TimeZoneConversion {
    public static void main(String[] args) {
        System.out.println("=== Exercise 04: Time Zone Conversion ===");

        // TODO 1: Create ZonedDateTime in India
        ZonedDateTime indiaTime = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
        System.out.println("India: " + indiaTime);

        // TODO 2: Convert to other time zones
        ZonedDateTime londonTime = indiaTime.withZoneSameInstant(ZoneId.of("Europe/London"));
        ZonedDateTime nyTime = indiaTime.withZoneSameInstant(ZoneId.of("America/New_York"));
        ZonedDateTime sydneyTime = indiaTime.withZoneSameInstant(ZoneId.of("Australia/Sydney"));

        System.out.println("London: " + londonTime);
        System.out.println("New York: " + nyTime);
        System.out.println("Sydney: " + sydneyTime);
    }
}
