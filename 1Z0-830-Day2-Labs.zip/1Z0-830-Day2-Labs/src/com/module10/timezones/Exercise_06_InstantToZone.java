package com.module10.timezones;

import java.time.*;
import java.util.List;

public class Exercise_06_InstantToZone {
    public static void main(String[] args) {
        System.out.println("=== Exercise 06: Instant to Zoned Time ===");

        // TODO 1: Capture current UTC Instant
        Instant now = Instant.now();
        System.out.println("UTC Instant: " + now);

        // TODO 2: Convert to multiple city times
        List<String> cities = List.of("Asia/Kolkata", "Europe/London", "America/New_York", "Asia/Tokyo", "Australia/Sydney");

        for (String city : cities) {
            ZonedDateTime zdt = ZonedDateTime.ofInstant(now, ZoneId.of(city));
            System.out.println(city + ": " + zdt);
        }
    }
}
