package com.module10.timezones;

import java.time.*;

public class Exercise_03_CreateZonedDateTime {
    public static void main(String[] args) {
        System.out.println("=== Exercise 03: Creating ZonedDateTime ===");

        // TODO 1: Create a LocalDateTime object
        LocalDateTime local = LocalDateTime.of(2025, 10, 21, 10, 30);

        // TODO 2: Create ZonedDateTime for multiple zones
        ZonedDateTime india = ZonedDateTime.of(local, ZoneId.of("Asia/Kolkata"));
        ZonedDateTime london = ZonedDateTime.of(local, ZoneId.of("Europe/London"));
        ZonedDateTime tokyo = ZonedDateTime.of(local, ZoneId.of("Asia/Tokyo"));

        System.out.println("India:  " + india);
        System.out.println("London: " + london);
        System.out.println("Tokyo:  " + tokyo);
    }
}
