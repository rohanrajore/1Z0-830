package com.module10.timezones;

import java.time.ZoneId;
import java.util.*;

public class Exercise_02_ZoneIdBasics {
    public static void main(String[] args) {
        System.out.println("=== Exercise 02: ZoneId Basics ===");

        // TODO 1: Print current system zone
        System.out.println("Current System Zone: " + ZoneId.systemDefault());

        // TODO 2: List and print a few sample Zone IDs
        List<String> sampleZones = Arrays.asList("Asia/Tokyo", "Europe/Paris", "America/Los_Angeles", "Australia/Sydney");
        for (String z : sampleZones) {
            System.out.println("ZoneId.of(\"" + z + "\") -> " + ZoneId.of(z));
        }

        // TODO 3: Print first 10 available Zone IDs from system
        System.out.println("\nAll available Zone IDs (first 10):");
        ZoneId.getAvailableZoneIds().stream().limit(10).forEach(System.out::println);
    }
}
