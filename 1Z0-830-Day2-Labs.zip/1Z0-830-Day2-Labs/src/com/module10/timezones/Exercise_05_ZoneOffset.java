package com.module10.timezones;

import java.time.*;

public class Exercise_05_ZoneOffset {
    public static void main(String[] args) {
        System.out.println("=== Exercise 05: ZoneOffset Basics ===");

        // TODO 1: Print OffsetDateTime for multiple offsets
        ZoneOffset utc = ZoneOffset.of("+00:00");
        ZoneOffset india = ZoneOffset.of("+05:30");
        ZoneOffset japan = ZoneOffset.of("+09:00");
        ZoneOffset ny = ZoneOffset.of("-04:00");

        System.out.println("UTC:    " + OffsetDateTime.now(utc));
        System.out.println("India:  " + OffsetDateTime.now(india));
        System.out.println("Japan:  " + OffsetDateTime.now(japan));
        System.out.println("New York (EST): " + OffsetDateTime.now(ny));
    }
}
