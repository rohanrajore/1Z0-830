package com.module09.datetime_formatter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class Exercise_07_LocalizedFormats {
    public static void main(String[] args) {
        System.out.println("=== Exercise 07: Predefined Localized Formatters ===");

        LocalDate today = LocalDate.now();
        LocalDateTime now = LocalDateTime.now();

        // TODO 1: Display date in multiple FormatStyle levels
        System.out.println("FULL:   " + today.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL)));
        System.out.println("LONG:   " + today.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG)));
        System.out.println("MEDIUM: " + today.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)));
        System.out.println("SHORT:  " + today.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT)));

        // TODO 2: Display date-time styles
        System.out.println("\nDate-Time (MEDIUM): " +
                now.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)));
    }
}
