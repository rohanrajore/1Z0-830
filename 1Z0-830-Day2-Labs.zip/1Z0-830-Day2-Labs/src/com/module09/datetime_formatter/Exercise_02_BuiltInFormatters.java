package com.module09.datetime_formatter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Exercise_02_BuiltInFormatters {
    public static void main(String[] args) {
        System.out.println("=== Exercise 02: Built-In Formatters ===");

        // TODO 1: Get current date-time
        LocalDateTime now = LocalDateTime.now();

        // TODO 2: Print using various built-in ISO formatters
        System.out.println("ISO_LOCAL_DATE: " + now.format(DateTimeFormatter.ISO_LOCAL_DATE));
        System.out.println("ISO_LOCAL_DATE_TIME: " + now.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        System.out.println("BASIC_ISO_DATE: " + now.format(DateTimeFormatter.BASIC_ISO_DATE));
        System.out.println("ISO_OFFSET_DATE_TIME (default offset ignored): "
                + now.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
    }
}
