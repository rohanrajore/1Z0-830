package com.module09.datetime_formatter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Exercise_01_BasicFormatter {
    public static void main(String[] args) {
        System.out.println("=== Exercise 01: Basic Formatter ===");

        // TODO 1: Get current date
        LocalDate today = LocalDate.now();

        // TODO 2: Format using built-in ISO formatters
        String isoDate = today.format(DateTimeFormatter.ISO_DATE);
        String isoLocal = today.format(DateTimeFormatter.ISO_LOCAL_DATE);

        // Print results
        System.out.println("ISO_DATE: " + isoDate);
        System.out.println("ISO_LOCAL_DATE: " + isoLocal);
    }
}
