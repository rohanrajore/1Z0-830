package com.module09.datetime_formatter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class Exercise_06_LocaleFormats {
    public static void main(String[] args) {
        System.out.println("=== Exercise 06: Locale-Based Formatting ===");

        LocalDate today = LocalDate.now();

        // TODO 1: Format in multiple locales
        DateTimeFormatter us = DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy", Locale.US);
        DateTimeFormatter fr = DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy", Locale.FRANCE);
        DateTimeFormatter jp = DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy", Locale.JAPAN);
        DateTimeFormatter in = DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy", new Locale("hi", "IN"));

        // Print localized outputs
        System.out.println("US: " + today.format(us));
        System.out.println("France: " + today.format(fr));
        System.out.println("Japan: " + today.format(jp));
        System.out.println("India: " + today.format(in));
    }
}
