package com.module09.datetime_formatter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Exercise_04_ParseCustomDate {
    public static void main(String[] args) {
        System.out.println("=== Exercise 04: Parsing Custom Dates ===");

        // TODO 1: Parse "05-11-2025"
        String text1 = "05-11-2025";
        DateTimeFormatter fmt1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date1 = LocalDate.parse(text1, fmt1);
        System.out.println("Parsed (dd-MM-yyyy): " + date1);

        // TODO 2: Parse "2025/11/05"
        String text2 = "2025/11/05";
        DateTimeFormatter fmt2 = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        LocalDate date2 = LocalDate.parse(text2, fmt2);
        System.out.println("Parsed (yyyy/MM/dd): " + date2);
    }
}
