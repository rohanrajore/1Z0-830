package com.module09.datetime_formatter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Exercise_05_ParseLocalDateTime {
    public static void main(String[] args) {
        System.out.println("=== Exercise 05: Parsing and Formatting LocalDateTime ===");

        // TODO 1: Parse input string
        String text = "21-10-2025 14:45";
        DateTimeFormatter inputFmt = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
        LocalDateTime dt = LocalDateTime.parse(text, inputFmt);

        // TODO 2: Reformat with AM/PM style
        DateTimeFormatter outputFmt = DateTimeFormatter.ofPattern("EEE, h:mm a");
        System.out.println("Reformatted: " + dt.format(outputFmt));
    }
}
