package com.module09.datetime_formatter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Exercise_09_ParseExceptionHandling {
    public static void main(String[] args) {
        System.out.println("=== Exercise 09: Handling Parse Exceptions ===");

        String[] testDates = {"2025.10.21", "21-10-2025", "10/21/2025"};

        for (String text : testDates) {
            try {
                // TODO 1: Try parsing each string
                LocalDate d = LocalDate.parse(text, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
                System.out.println("Parsed successfully: " + d);
            } catch (DateTimeParseException e) {
                // TODO 2: Handle invalid input formats gracefully
                System.out.println("Invalid format for '" + text + "' → " + e.getMessage());
            }
        }
    }
}
