package com.module09.datetime_formatter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Exercise_03_CustomPatterns {
    public static void main(String[] args) {
        System.out.println("=== Exercise 03: Custom Format Patterns ===");

        // TODO 1: Get current date-time
        LocalDateTime now = LocalDateTime.now();

        // TODO 2: Define custom patterns
        DateTimeFormatter fmt1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter fmt2 = DateTimeFormatter.ofPattern("EEEE, MMM dd yyyy");
        DateTimeFormatter fmt3 = DateTimeFormatter.ofPattern("hh:mm a");

        // TODO 3: Print in different formats
        System.out.println("Pattern 1: " + now.format(fmt1));
        System.out.println("Pattern 2: " + now.format(fmt2));
        System.out.println("Pattern 3: " + now.format(fmt3));
    }
}
