package com.module09.datetime_formatter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Exercise_08_ConvertFormats {
    public static void main(String[] args) {
        System.out.println("=== Exercise 08: Combining Parsing and Formatting ===");

        // TODO 1: Input date string
        String input = "21-10-2025";

        // TODO 2: Parse using one format
        DateTimeFormatter inputFmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = LocalDate.parse(input, inputFmt);

        // TODO 3: Convert to another format
        DateTimeFormatter outputFmt = DateTimeFormatter.ofPattern("EEEE, MMM dd yyyy");
        System.out.println("Converted Format: " + date.format(outputFmt));
    }
}
