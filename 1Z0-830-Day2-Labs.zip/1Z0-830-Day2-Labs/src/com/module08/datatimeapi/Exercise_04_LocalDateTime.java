package com.module08.datatimeapi;


import java.time.*;

public class Exercise_04_LocalDateTime {
    public static void main(String[] args) {
        System.out.println("=== Exercise 04: LocalDateTime Operations ===");

        // TODO 1: Create meeting schedule
        LocalDateTime meeting = LocalDateTime.of(2025, 10, 21, 10, 30);
        System.out.println("Original meeting: " + meeting);

        // TODO 2: Shift by 5 hours and 1 day
        System.out.println("After 5 hours: " + meeting.plusHours(5));
        System.out.println("Next day same time: " + meeting.plusDays(1));

        // TODO 3: Extract date and time parts
        System.out.println("Date part: " + meeting.toLocalDate());
        System.out.println("Time part: " + meeting.toLocalTime());
    }
}

