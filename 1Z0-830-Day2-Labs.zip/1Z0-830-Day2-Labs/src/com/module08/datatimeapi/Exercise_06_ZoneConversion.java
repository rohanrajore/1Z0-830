package com.module08.datatimeapi;


import java.time.*;

public class Exercise_06_ZoneConversion {
    public static void main(String[] args) {
        System.out.println("=== Exercise 06: Zone Conversion ===");

        // TODO 1: Capture current instant
        Instant instant = Instant.now();

        // TODO 2: Convert to multiple time zones
        ZoneId india = ZoneId.of("Asia/Kolkata");
        ZoneId utc = ZoneId.of("UTC");
        ZoneId usEast = ZoneId.of("America/New_York");

        System.out.println("India: " + LocalDateTime.ofInstant(instant, india));
        System.out.println("UTC: " + LocalDateTime.ofInstant(instant, utc));
        System.out.println("US/Eastern: " + LocalDateTime.ofInstant(instant, usEast));
    }
}

