package com.module08.datatimeapi;



import java.time.*;
import java.util.Date;

public class Exercise_01_NewAPIIntro {
    public static void main(String[] args) {
        System.out.println("=== Exercise 01: New Date-Time API Intro ===");

        // TODO 1: Print current date using old Date class
        Date oldDate = new Date();
        System.out.println("Old Date API output: " + oldDate);

        // TODO 2: Print current date using LocalDate
        LocalDate today = LocalDate.now();
        System.out.println("New Date-Time API (LocalDate): " + today);

        // TODO 3: Compare readability and immutability
        // Discuss: Old Date is mutable, LocalDate is immutable and thread-safe.
    }
}

