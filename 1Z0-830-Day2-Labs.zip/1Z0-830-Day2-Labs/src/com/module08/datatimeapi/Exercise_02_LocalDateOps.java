package com.module08.datatimeapi;


import java.time.*;

public class Exercise_02_LocalDateOps {
    public static void main(String[] args) {
        System.out.println("=== Exercise 02: LocalDate Operations ===");

        // TODO 1: Create specific date and print its details
        LocalDate date = LocalDate.of(2025, 10, 21);
        System.out.println("Date: " + date);
        System.out.println("Day of Week: " + date.getDayOfWeek());

        // TODO 2: Perform addition/subtraction
        LocalDate plus10Days = date.plusDays(10);
        LocalDate minus2Months = date.minusMonths(2);
        System.out.println("After 10 days: " + plus10Days);
        System.out.println("2 months earlier: " + minus2Months);

        // TODO 3: Check for leap year
        System.out.println("Is leap year? " + date.isLeapYear());
    }
}

