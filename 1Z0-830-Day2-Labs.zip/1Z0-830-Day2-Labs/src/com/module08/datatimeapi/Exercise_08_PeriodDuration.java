package com.module08.datatimeapi;


import java.time.*;
import java.time.temporal.ChronoUnit;

public class Exercise_08_PeriodDuration {
    public static void main(String[] args) {
        System.out.println("=== Exercise 08: Period and Duration ===");

        // TODO 1: Compute period between two dates
        LocalDate start = LocalDate.of(2025, 1, 1);
        LocalDate end = LocalDate.of(2025, 10, 21);
        Period period = Period.between(start, end);
        System.out.println("Period: " + period);

        // TODO 2: Compute duration between two times
        LocalTime t1 = LocalTime.of(9, 0);
        LocalTime t2 = LocalTime.of(17, 30);
        Duration duration = Duration.between(t1, t2);
        System.out.println("Duration: " + duration);

        // TODO 3: Quick difference using ChronoUnit
        System.out.println("Days between: " + ChronoUnit.DAYS.between(start, end));
    }
}

