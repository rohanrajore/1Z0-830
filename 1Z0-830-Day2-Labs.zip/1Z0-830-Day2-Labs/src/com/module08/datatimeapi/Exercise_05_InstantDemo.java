package com.module08.datatimeapi;


import java.time.*;

public class Exercise_05_InstantDemo {
    public static void main(String[] args) {
        System.out.println("=== Exercise 05: Instant Demo ===");

        // TODO 1: Capture current instant
        Instant now = Instant.now();
        System.out.println("Current Instant: " + now);

        // TODO 2: Print epoch seconds
        System.out.println("Epoch seconds: " + now.getEpochSecond());

        // TODO 3: Convert Instant to LocalDateTime using system default zone
        LocalDateTime local = LocalDateTime.ofInstant(now, ZoneId.systemDefault());
        System.out.println("LocalDateTime from Instant: " + local);
    }
}

