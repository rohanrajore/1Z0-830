package com.module08.datatimeapi;


import java.time.*;
import java.time.format.*;

public class Exercise_07_ParseFormat {
    public static void main(String[] args) {
        System.out.println("=== Exercise 07: Parsing and Formatting ===");

        // TODO 1: Parse a string date with custom pattern
        DateTimeFormatter inputFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate date = LocalDate.parse("21/10/2025", inputFmt);

        // TODO 2: Format into readable style
        DateTimeFormatter outputFmt = DateTimeFormatter.ofPattern("EEEE, MMM dd yyyy");
        String formatted = date.format(outputFmt);

        System.out.println("Parsed Date: " + date);
        System.out.println("Formatted: " + formatted);
    }
}

