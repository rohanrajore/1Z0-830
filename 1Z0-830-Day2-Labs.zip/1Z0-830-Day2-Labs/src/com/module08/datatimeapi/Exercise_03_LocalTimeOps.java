package com.module08.datatimeapi;


import java.time.*;

public class Exercise_03_LocalTimeOps {
    public static void main(String[] args) {
        System.out.println("=== Exercise 03: LocalTime Operations ===");

        // TODO 1: Capture current time
        LocalTime now = LocalTime.now();
        System.out.println("Current time: " + now);

        // TODO 2: Add/subtract hours and minutes
        System.out.println("After 2 hours: " + now.plusHours(2));
        System.out.println("30 minutes ago: " + now.minusMinutes(30));

        // TODO 3: Compare morning and evening slots
        LocalTime morning = LocalTime.of(9, 0);
        LocalTime evening = LocalTime.of(18, 0);
        System.out.println("Is morning before evening? " + morning.isBefore(evening));
    }
}

