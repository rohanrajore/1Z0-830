package com.module02.string_concat;

public class Exercise_05_ConcatPerformance {
    public static void main(String[] args) {
        System.out.println("=== Exercise 05: Concatenation Performance ===");

        // Using '+'
        long start1 = System.nanoTime();
        String result = "";
        for (int i = 0; i < 5000; i++) {
            result = result + i;
        }
        long time1 = System.nanoTime() - start1;

        // Using StringBuilder
        long start2 = System.nanoTime();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5000; i++) {
            sb.append(i);
        }
        long time2 = System.nanoTime() - start2;

        System.out.printf("Using '+': %.3f ms%n", time1 / 1_000_000.0);
        System.out.printf("Using StringBuilder: %.3f ms%n", time2 / 1_000_000.0);
        System.out.println("Result lengths → String: " + result.length() + ", StringBuilder: " + sb.length());
    }
}
