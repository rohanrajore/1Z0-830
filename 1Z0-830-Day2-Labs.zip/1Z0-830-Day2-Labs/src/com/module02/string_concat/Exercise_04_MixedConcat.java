package com.module02.string_concat;

public class Exercise_04_MixedConcat {
    public static void main(String[] args) {
        System.out.println("=== Exercise 04: Mixing Literals and Variables ===");

        String s1 = "Java";
        String s2 = s1 + "21"; // runtime concatenation → heap
        String s3 = "Java21";  // SCP

        System.out.println("s2 == s3 → " + (s2 == s3)); // false
        System.out.println("s2.intern() == s3 → " + (s2.intern() == s3)); // true

        // Try with final variable
        final String f1 = "Java";
        String s4 = f1 + "21"; // compile-time optimized due to final constant
        System.out.println("With final variable → " + (s4 == s3)); // true
    }
}
