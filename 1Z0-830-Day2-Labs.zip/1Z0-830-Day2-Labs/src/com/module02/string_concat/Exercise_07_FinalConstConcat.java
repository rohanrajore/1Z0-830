package com.module02.string_concat;

public class Exercise_07_FinalConstConcat {
    public static void main(String[] args) {
        System.out.println("=== Exercise 07: Final Constants and Compile-Time Optimization ===");

        final String a = "Hello";
        final String b = "World";
        String c = a + b;  // compile-time concatenation
        String d = "HelloWorld";

        System.out.println("c == d → " + (c == d)); // true

        // Non-final example
        String x = "Hello";
        String y = "World";
        String z = x + y;  // runtime concatenation
        System.out.println("z == d → " + (z == d)); // false
        System.out.println("z.intern() == d → " + (z.intern() == d)); // true
    }
}
