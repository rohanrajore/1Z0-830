package com.module02.string_concat;

public class Exercise_01_CompileTimeConcat {
    public static void main(String[] args) {
        System.out.println("=== Exercise 01: Compile-Time Concatenation ===");

        // Compile-time concatenation (constant folding)
        String s1 = "Hello " + "World";
        System.out.println("Result: " + s1);

        // Check reference equality with literal
        System.out.println("Same object as literal? " + (s1 == "Hello World"));

        // Bytecode analysis hint:
        // Run in terminal:
        // javap -c com.module02.string_concat.Exercise_01_CompileTimeConcat
    }
}
