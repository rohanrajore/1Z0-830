package com.module02.string_concat;

public class Exercise_02_ConstantFolding {
    public static void main(String[] args) {
        System.out.println("=== Exercise 02: Constant Folding ===");

        String s1 = "Java";
        String s2 = "21";
        String s3 = "Java" + "21"; // compile-time folded
        String s4 = s1 + s2;       // runtime concatenation

        System.out.println("s3 == \"Java21\" → " + (s3 == "Java21")); // true
        System.out.println("s4 == \"Java21\" → " + (s4 == "Java21")); // false
        System.out.println("s4.intern() == \"Java21\" → " + (s4.intern() == "Java21")); // true

        // Demonstrate mixed literals and variables
        String mixed = s1 + " " + "Language"; // runtime due to variable
        System.out.println("Mixed result: " + mixed);
    }
}
