package com.module02.string_concat;

public class Exercise_03_RuntimeConcat {
    public static void main(String[] args) {
        System.out.println("=== Exercise 03: Runtime Concatenation ===");

        String s1 = "Hello";
        String s2 = "World";
        String s3 = s1 + s2;

        System.out.println("Concatenated result: " + s3);
        System.out.println("Same reference as literal? " + (s3 == "HelloWorld"));

        // Verify StringBuilder usage behind +
        // Run:
        // javap -c com.module02.string_concat.Exercise_03_RuntimeConcat
    }
}
