package com.module02.string_concat;

public class Exercise_06_StringBuilderUsage {
    public static void main(String[] args) {
        System.out.println("=== Exercise 06: Using StringBuilder Explicitly ===");

        String concat = "Learn" + " " + "Java"; // runtime + compile-time hybrid
        StringBuilder sb = new StringBuilder("Learn");
        sb.append(" ").append("Java");

        System.out.println("Using '+': " + concat);
        System.out.println("Using StringBuilder: " + sb.toString());

        // Compare hashCodes and references
        System.out.println("concat.hashCode(): " + concat.hashCode());
        System.out.println("sb.toString().hashCode(): " + sb.toString().hashCode());
    }
}
