package com.module06.textblocks;


public class Exercise_05_SpecialChars {
    public static void main(String[] args) {
        System.out.println("=== Exercise 05: Special Characters and Escapes ===");

        // TODO 1: Create a text block that includes tabs, slashes, and trailing spaces.
        String info = """
            Path: C:\\Program Files\\Java\\
            Tabs:\tused here
            Trailing space->\s
            """;

        System.out.println(info);
    }
}

