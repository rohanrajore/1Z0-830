package com.module06.textblocks;


public class Exercise_08_CompareOldVsNew {
    public static void main(String[] args) {
        System.out.println("=== Exercise 08: Text Block vs Regular String ===");

        // TODO 1: Create HTML using regular string with escapes
        String htmlOld = "<div>\\n" +
                "    <h2>Welcome</h2>\\n" +
                "    <p>Learning Java Text Blocks!</p>\\n" +
                "</div>";

        // TODO 2: Rewrite as Text Block
        String htmlNew = """
            <div>
                <h2>Welcome</h2>
                <p>Learning Java Text Blocks!</p>
            </div>
            """;

        System.out.println("Old String Literal:");
        System.out.println(htmlOld);

        System.out.println("\nNew Text Block:");
        System.out.println(htmlNew);
    }
}
