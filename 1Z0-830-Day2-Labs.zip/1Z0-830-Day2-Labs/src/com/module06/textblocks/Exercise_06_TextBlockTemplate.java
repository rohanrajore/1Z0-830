package com.module06.textblocks;


public class Exercise_06_TextBlockTemplate {
    public static void main(String[] args) {
        System.out.println("=== Exercise 06: Text Block Template ===");

        // TODO 1: Create a text block with placeholders and use .formatted() to fill values.
        String template = """
                {
                    "name": "%s",
                    "age": %d,
                    "city": "%s"
                }
                """.formatted("Nitya", 14, "Bangalore");

        System.out.println(template);
    }
}

