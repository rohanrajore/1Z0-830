package com.module06.textblocks;


public class Exercise_03_WhitespaceControl {
    public static void main(String[] args) {
        System.out.println("=== Exercise 03: Whitespace Control ===");

        // TODO 1: Create text blocks with varying indentation
        String json1 = """
                {
                    "id": 101,
                    "name": "Rohan"
                }
                """;

        String json2 = """
        {
            "id": 101,
            "name": "Rohan"
        }
        """;

        System.out.println("Indented JSON:");
        System.out.println(json1);

        System.out.println("\nLeft-aligned JSON:");
        System.out.println(json2);
    }
}

