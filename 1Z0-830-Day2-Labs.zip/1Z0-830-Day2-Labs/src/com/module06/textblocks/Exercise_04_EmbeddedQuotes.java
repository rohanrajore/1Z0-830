package com.module06.textblocks;


public class Exercise_04_EmbeddedQuotes {
    public static void main(String[] args) {
        System.out.println("=== Exercise 04: Embedded Quotes ===");

        // TODO 1: Write a text block that contains direct quotes without escapes.
        String dialogue = """
            She said, "Java is elegant."
            He replied, "Indeed it is!"
            """;

        System.out.println(dialogue);
    }
}

