package com.module06.textblocks;


public class Exercise_02_SyntaxRules {
    public static void main(String[] args) {
        System.out.println("=== Exercise 02: Syntax and Rules ===");

        // TODO 1: Create a text block and print to see indentation behavior.
        String poem = """
                Roses are red,
                Violets are blue,
                Code is elegant,
                When written by you.
                """;
        System.out.println(poem);

        // TODO 2: Try adjusting indentation (move closing """ left or right)
        // and note how spaces change in output.
    }
}

