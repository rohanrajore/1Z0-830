package com.module06.textblocks;



public class Exercise_01_TextBlockIntro {
    public static void main(String[] args) {
        System.out.println("=== Exercise 01: Text Block Introduction ===");

        // TODO 1: Convert a traditional multi-line string into a Text Block.
        String htmlOld = "<html>\n"
                + "    <body>\n"
                + "        <h1>Hello, World!</h1>\n"
                + "    </body>\n"
                + "</html>";

        System.out.println("Old Format:");
        System.out.println(htmlOld);

        // TODO 2: Replace above string using Text Block syntax (""")
        String htmlNew = """
            <html>
                <body>
                    <h1>Hello, World!</h1>
                </body>
            </html>
            """;

        System.out.println("\nText Block Format:");
        System.out.println(htmlNew);
    }
}

