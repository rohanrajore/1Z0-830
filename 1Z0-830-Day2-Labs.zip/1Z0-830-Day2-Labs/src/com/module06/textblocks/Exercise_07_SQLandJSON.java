package com.module06.textblocks;


public class Exercise_07_SQLandJSON {
    public static void main(String[] args) {
        System.out.println("=== Exercise 07: SQL and JSON Examples ===");

        // TODO 1: Create a SQL query text block
        String sql = """
            SELECT id, name, salary
            FROM employees
            WHERE department = "Sales"
            ORDER BY salary DESC;
            """;
        System.out.println("SQL Query:");
        System.out.println(sql);

        // TODO 2: Create a JSON text block
        String json = """
            {
                "department": "Sales",
                "region": "Asia",
                "headcount": 45
            }
            """;
        System.out.println("\nJSON Data:");
        System.out.println(json);
    }
}

