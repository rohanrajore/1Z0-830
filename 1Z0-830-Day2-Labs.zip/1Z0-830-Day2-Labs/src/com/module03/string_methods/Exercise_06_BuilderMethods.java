package com.module03.string_methods;

public class Exercise_06_BuilderMethods {
    public static void main(String[] args) {
        System.out.println("=== Exercise 06: Common StringBuilder Methods ===");

        StringBuilder sb = new StringBuilder("World");

        // TODO 1: Apply various methods
        sb.insert(0, "Hello ");
        sb.delete(5, 6);
        sb.reverse();
        sb.replace(0, 5, "Hi");

        System.out.println("Final content: " + sb);
        System.out.println("Object hash: " + System.identityHashCode(sb));
    }
}
