package com.module03.string_methods;

public class Exercise_01_StringBasics {
    public static void main(String[] args) {
        System.out.println("=== Exercise 01: String Basics ===");

        // TODO 1: Create a string and test its basic methods
        String s = "Java Programming";

        System.out.println("Length: " + s.length());
        System.out.println("Uppercase: " + s.toUpperCase());
        System.out.println("Lowercase: " + s.toLowerCase());

        // TODO 2: Check object reference changes
        String upper = s.toUpperCase();
        System.out.println("Same reference? " + (s == upper));
    }
}
