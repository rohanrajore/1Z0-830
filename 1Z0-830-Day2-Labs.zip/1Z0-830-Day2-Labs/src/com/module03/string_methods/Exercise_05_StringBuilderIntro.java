package com.module03.string_methods;

public class Exercise_05_StringBuilderIntro {
    public static void main(String[] args) {
        System.out.println("=== Exercise 05: StringBuilder Intro ===");

        // TODO 1: Use StringBuilder to build a sentence
        StringBuilder sb = new StringBuilder("Hello");
        sb.append(" ").append("World");
        System.out.println("StringBuilder content: " + sb);

        // TODO 2: Compare with String concatenation
        String str = "Hello";
        str = str + " " + "World";
        System.out.println("String result: " + str);
    }
}
