package com.module03.string_methods;

public class Exercise_02_SearchCompare {
    public static void main(String[] args) {
        System.out.println("=== Exercise 02: Searching & Comparing Strings ===");

        String s = "Developer";

        // TODO 1: Find positions of substrings
        System.out.println("charAt(2): " + s.charAt(2));
        System.out.println("indexOf(\"el\"): " + s.indexOf("el"));
        System.out.println("lastIndexOf(\"e\"): " + s.lastIndexOf("e"));

        // TODO 2: Compare text ignoring case
        System.out.println("equals(\"developer\"): " + s.equals("developer"));
        System.out.println("equalsIgnoreCase(\"developer\"): " + s.equalsIgnoreCase("developer"));
    }
}
