package com.module03.string_methods;

public class Exercise_03_SubReplace {
    public static void main(String[] args) {
        System.out.println("=== Exercise 03: Substring and Replacement ===");

        String s = "Java 21 Developer";

        // TODO 1: Extract parts of string
        System.out.println("substring(0,4): " + s.substring(0, 4));
        System.out.println("substring(5): " + s.substring(5));

        // TODO 2: Replace characters and digits
        System.out.println("replace('a','@'): " + s.replace('a', '@'));
        System.out.println("replaceAll(\"\\\\d\", \"XX\"): " + s.replaceAll("\\d", "XX"));
    }
}
