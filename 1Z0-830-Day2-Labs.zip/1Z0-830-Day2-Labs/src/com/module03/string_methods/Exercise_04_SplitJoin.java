package com.module03.string_methods;

import java.util.Arrays;

public class Exercise_04_SplitJoin {
    public static void main(String[] args) {
        System.out.println("=== Exercise 04: Trimming, Splitting, and Joining ===");

        String data = "  Alpha, Beta , Gamma ";

        // TODO 1: Trim and split CSV data
        System.out.println("trim(): " + data.trim());
        String[] parts = data.split(",");

        System.out.println("Split parts: " + Arrays.toString(parts));

        // TODO 2: Join with different delimiter
        String joined = String.join(" | ", parts);
        System.out.println("Joined string: " + joined);
    }
}
