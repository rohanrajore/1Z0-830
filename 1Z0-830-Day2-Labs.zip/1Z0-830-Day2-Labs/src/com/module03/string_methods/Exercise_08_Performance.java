package com.module03.string_methods;

public class Exercise_08_Performance {
    public static void main(String[] args) {
        System.out.println("=== Exercise 08: Performance Comparison ===");

        // TODO 1: Measure String concatenation time
        long startString = System.nanoTime();
        String s = "";
        for (int i = 0; i < 5000; i++) {
            s += i;
        }
        long endString = System.nanoTime();

        // TODO 2: Measure StringBuilder append time
        long startBuilder = System.nanoTime();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5000; i++) {
            sb.append(i);
        }
        long endBuilder = System.nanoTime();

        System.out.println("Time (String): " + (endString - startString) / 1_000_000.0 + " ms");
        System.out.println("Time (StringBuilder): " + (endBuilder - startBuilder) / 1_000_000.0 + " ms");
    }
}
