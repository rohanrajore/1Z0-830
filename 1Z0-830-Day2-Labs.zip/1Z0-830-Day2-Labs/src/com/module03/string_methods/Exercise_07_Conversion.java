package com.module03.string_methods;

public class Exercise_07_Conversion {
    public static void main(String[] args) {
        System.out.println("=== Exercise 07: Converting Between String and StringBuilder ===");

        String s = "Java";
        StringBuilder sb = new StringBuilder(s);
        sb.append("21");

        String result = sb.toString();

        // TODO 1: Verify conversion
        System.out.println("Original String: " + s);
        System.out.println("Modified result: " + result);
        System.out.println("Same reference? " + (s == result));
    }
}
