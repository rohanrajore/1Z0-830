package com.module05.string_formatting;


import java.io.*;
import java.util.*;

public class Exercise_07_FormatterFile {
    public static void main(String[] args) {
        System.out.println("=== Exercise 07: Formatter to File ===");

        // TODO 1: Write formatted data to a file
        try (Formatter f = new Formatter("report.txt")) {
            f.format("Employee: %s | Salary: %.2f%n", "Anita", 98765.43);
            f.format("Employee: %s | Salary: %.2f%n", "Rohan", 105000.78);
            System.out.println("Report written to report.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
