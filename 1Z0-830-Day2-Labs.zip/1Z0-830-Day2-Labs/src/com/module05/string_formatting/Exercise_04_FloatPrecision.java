package com.module05.string_formatting;


public class Exercise_04_FloatPrecision {
    public static void main(String[] args) {
        System.out.println("=== Exercise 04: Floating Point Precision ===");

        double price = 1234.56789;
        double percent = 0.98765;

        // TODO 1: Print with different precisions
        System.out.println(String.format("Price: ₹%.2f", price));
        System.out.println(String.format("Price (3 decimals): %.3f", price));
        System.out.println(String.format("Percentage: %.2f%%", percent * 100));
    }
}

