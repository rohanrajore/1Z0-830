package com.module05.string_formatting;


public class Exercise_05_StringWidth {
    public static void main(String[] args) {
        System.out.println("=== Exercise 05: String Width & Alignment ===");

        // TODO 1: Right-align names and left-align departments
        System.out.println(String.format("%10s | %-15s", "Rohan", "Engineering"));
        System.out.println(String.format("%10s | %-15s", "Nitya", "Design"));
        System.out.println(String.format("%10s | %-15s", "Arjun", "Finance"));
    }
}
