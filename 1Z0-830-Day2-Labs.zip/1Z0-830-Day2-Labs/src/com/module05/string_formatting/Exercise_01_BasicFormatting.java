package com.module05.string_formatting;


public class Exercise_01_BasicFormatting {
    public static void main(String[] args) {
        System.out.println("=== Exercise 01: Basic Formatting ===");

        // TODO 1: Create variables for name, score, and rank
        String name = "Nitya";
        int score = 95;
        int rank = 2;

        // TODO 2: Format them using String.format()
        String message = String.format("%s scored %d marks and secured rank %d", name, score, rank);

        System.out.println(message);
    }
}

