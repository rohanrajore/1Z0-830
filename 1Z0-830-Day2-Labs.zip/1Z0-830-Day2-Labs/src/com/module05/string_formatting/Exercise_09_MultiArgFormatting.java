package com.module05.string_formatting;


public class Exercise_09_MultiArgFormatting {
    public static void main(String[] args) {
        System.out.println("=== Exercise 09: Multi-Argument Formatting ===");

        // TODO 1: Use argument indexes and mixed specifiers
        String result = String.format("Name: %2$s, ID: %1$d, Score: %.2f", 101, "Rohan", 95.75);
        System.out.println(result);

        // TODO 2: Create another example for currency and date
        String summary = String.format("Invoice #%d | Client: %s | Amount: ₹%.2f", 2001, "TechCorp", 54321.90);
        System.out.println(summary);
    }
}
