package com.module05.string_formatting;


import java.util.*;

public class Exercise_06_FormatterIntro {
    public static void main(String[] args) {
        System.out.println("=== Exercise 06: Using Formatter ===");

        // TODO 1: Use Formatter to format and print text
        Formatter f = new Formatter();
        f.format("Name: %s, Marks: %d", "Ravi", 90);
        System.out.println(f);
        f.close();

        // TODO 2: Use Formatter with StringBuilder
        StringBuilder sb = new StringBuilder();
        try (Formatter fb = new Formatter(sb)) {
            fb.format("User: %s | Score: %.1f", "Nitya", 88.5);
        }
        System.out.println(sb);
    }
}

