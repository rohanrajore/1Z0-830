package com.module05.string_formatting;


import java.util.*;

public class Exercise_08_LocaleFormatting {
    public static void main(String[] args) {
        System.out.println("=== Exercise 08: Locale-Specific Formatting ===");

        double amt = 12345.67;

        // TODO 1: Format same number in different locales
        System.out.println("US: " + String.format(Locale.US, "%,.2f", amt));
        System.out.println("France: " + String.format(Locale.FRANCE, "%,.2f", amt));
        System.out.println("India: " + String.format(new Locale("en", "IN"), "%,.2f", amt));
    }
}
