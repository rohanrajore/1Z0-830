package com.module05.string_formatting;


public class Exercise_03_AlignmentPadding {
    public static void main(String[] args) {
        System.out.println("=== Exercise 03: Alignment & Padding ===");

        // TODO 1: Format employee IDs with alignment
        System.out.println(String.format("%5d | %-10s", 101, "Rohan"));
        System.out.println(String.format("%5d | %-10s", 102, "Nitya"));
        System.out.println(String.format("%5d | %-10s", 103, "Arjun"));

        // TODO 2: Experiment with zero-padding
        System.out.println(String.format("Padded ID: %05d", 42));
    }
}

