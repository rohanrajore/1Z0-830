package com.module05.string_formatting;


public class Exercise_02_Specifiers {
    public static void main(String[] args) {
        System.out.println("=== Exercise 02: Common Format Specifiers ===");

        // TODO 1: Practice each specifier
        System.out.println(String.format("Integer: %d", 42));
        System.out.println(String.format("Float: %.2f", 12.3456));
        System.out.println(String.format("String: %s", "Java"));
        System.out.println(String.format("Character: %c", 'A'));
        System.out.println(String.format("Boolean: %b", true));
    }
}

