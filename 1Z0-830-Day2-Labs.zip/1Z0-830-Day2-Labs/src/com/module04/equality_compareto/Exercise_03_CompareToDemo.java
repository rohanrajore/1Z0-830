package com.module04.equality_compareto;

import java.util.Arrays;

public class Exercise_03_CompareToDemo {
    public static void main(String[] args) {
        System.out.println("=== Exercise 03: compareTo() Method ===");

        String[] words = {"Banana", "Apple", "Cat"};

        // TODO 1: Compare manually
        System.out.println("\"Apple\" vs \"Banana\": " + "Apple".compareTo("Banana"));
        System.out.println("\"Banana\" vs \"Apple\": " + "Banana".compareTo("Apple"));
        System.out.println("\"Cat\" vs \"Cat\": " + "Cat".compareTo("Cat"));

        // TODO 2: Sort manually and verify
        Arrays.sort(words);
        System.out.println("Sorted words: " + Arrays.toString(words));
    }
}
