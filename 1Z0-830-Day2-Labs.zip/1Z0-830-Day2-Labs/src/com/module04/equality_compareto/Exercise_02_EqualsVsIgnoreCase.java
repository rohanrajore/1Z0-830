package com.module04.equality_compareto;

public class Exercise_02_EqualsVsIgnoreCase {
    public static void main(String[] args) {
        System.out.println("=== Exercise 02: equals() vs equalsIgnoreCase() ===");

        // TODO 1: Compare with different cases
        String x = "Hello";
        String y = "hello";
        String z = "HELLO";

        System.out.println("x.equals(y): " + x.equals(y));
        System.out.println("x.equalsIgnoreCase(y): " + x.equalsIgnoreCase(y));

        System.out.println("x.equals(z): " + x.equals(z));
        System.out.println("x.equalsIgnoreCase(z): " + x.equalsIgnoreCase(z));
    }
}
