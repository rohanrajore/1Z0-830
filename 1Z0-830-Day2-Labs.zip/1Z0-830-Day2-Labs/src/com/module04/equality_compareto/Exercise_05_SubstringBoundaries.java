package com.module04.equality_compareto;

public class Exercise_05_SubstringBoundaries {
    public static void main(String[] args) {
        System.out.println("=== Exercise 05: Substring Boundaries ===");

        String s = "Developer";

        // TODO 1: Extract prefixes/suffixes
        System.out.println("Substring(0,3): " + s.substring(0, 3));
        System.out.println("Substring(3): " + s.substring(3));

        // TODO 2: Extract last 3 characters safely
        int len = s.length();
        System.out.println("Last 3 chars: " + s.substring(len - 3));
    }
}
