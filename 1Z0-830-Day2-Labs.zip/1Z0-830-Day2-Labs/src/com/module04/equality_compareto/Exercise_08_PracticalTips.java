package com.module04.equality_compareto;

public class Exercise_08_PracticalTips {
    public static void main(String[] args) {
        System.out.println("=== Exercise 08: Practical Tips ===");

        String s = "Java21";

        // TODO 1: Check prefixes/suffixes instead of substring
        if (s.startsWith("Java")) {
            System.out.println("Starts with Java ✅");
        }

        if (s.endsWith("21")) {
            System.out.println("Ends with 21 ✅");
        }

        // TODO 2: Use equalsIgnoreCase for case-insensitive match
        if ("JAVA21".equalsIgnoreCase(s)) {
            System.out.println("Case-insensitive match successful ✅");
        }
    }
}
