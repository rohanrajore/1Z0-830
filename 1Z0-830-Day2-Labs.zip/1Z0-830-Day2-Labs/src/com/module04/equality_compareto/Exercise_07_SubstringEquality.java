package com.module04.equality_compareto;

public class Exercise_07_SubstringEquality {
    public static void main(String[] args) {
        System.out.println("=== Exercise 07: Substring & Equality ===");

        String s1 = "Learning Java";
        String s2 = s1.substring(9); // "Java"

        // TODO 1: Compare substring with literal
        System.out.println("s2 == \"Java\": " + (s2 == "Java"));
        System.out.println("s2.equals(\"Java\"): " + s2.equals("Java"));

        // TODO 2: Confirm they are different objects
        System.out.println("HashCodes: " + System.identityHashCode(s2) + " vs " + System.identityHashCode("Java"));
    }
}
