package com.module04.equality_compareto;

public class Exercise_01_EqualityBasics {
    public static void main(String[] args) {
        System.out.println("=== Exercise 01: Reference vs Content Equality ===");

        // TODO 1: Observe differences between '==' and '.equals()'
        String a = "Java";
        String b = "Java";
        String c = new String("Java");

        System.out.println("a == b  → " + (a == b));      // same literal (SCP)
        System.out.println("a == c  → " + (a == c));      // heap vs SCP
        System.out.println("a.equals(c) → " + a.equals(c)); // content check

        // TODO 2: Try changing string values to see effect
    }
}
