package com.module04.equality_compareto;

import java.util.Arrays;

public class Exercise_04_CompareIgnoreCase {
    public static void main(String[] args) {
        System.out.println("=== Exercise 04: compareToIgnoreCase() ===");

        String[] cities = {"Delhi", "mumbai", "Chennai", "bangalore"};

        // TODO 1: Sort ignoring case
        Arrays.sort(cities, String::compareToIgnoreCase);

        System.out.println("Case-insensitive sorted order:");
        for (String city : cities) {
            System.out.println(city);
        }
    }
}
