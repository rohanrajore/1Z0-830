package com.module04.equality_compareto;

public class Exercise_06_SubstringErrors {
    public static void main(String[] args) {
        System.out.println("=== Exercise 06: Handling Substring Errors ===");

        String s = "Java";

        // TODO 1: Wrap substring in try-catch
        try {
            System.out.println(s.substring(4)); // out of bounds
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println("Error: Invalid substring range! " + e.getMessage());
        }

        // TODO 2: Use validation
        if (s.length() >= 2) {
            System.out.println("Safe substring(0,2): " + s.substring(0, 2));
        }
    }
}
