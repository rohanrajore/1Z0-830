package com.module05.localization;

import java.text.MessageFormat;
import java.util.Locale;

public class Exercise_08_MessageFormatDemo {
    public static void main(String[] args) {
        // TODO: Create a localized message template and format it with user name and count values.
        String pattern = "Hello {0}, you have {1} new notifications.";
        Object[] values = {"Rohan", 3};

        String formatted = MessageFormat.format(pattern, values);
        System.out.println("US Locale: " + formatted);

        MessageFormat mf = new MessageFormat(pattern, Locale.FRANCE);
        System.out.println("FR Locale: " + mf.format(values));
    }
}
