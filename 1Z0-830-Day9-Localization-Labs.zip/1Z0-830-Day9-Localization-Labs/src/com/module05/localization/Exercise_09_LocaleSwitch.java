package com.module05.localization;

import java.util.*;

public class Exercise_09_LocaleSwitch {
    public static void main(String[] args) {
        // TODO: Switch between locales dynamically and verify fallback behavior for missing translations.
        Locale[] locales = {new Locale("es", "ES"), new Locale("fr", "FR"), Locale.ENGLISH};

        for (Locale locale : locales) {
            Locale.setDefault(locale);
            ResourceBundle rb = ResourceBundle.getBundle("labels");
            System.out.println("Locale: " + locale);
            System.out.println("Greeting: " + rb.getString("greeting"));
        }
    }
}
