package com.module01.arrays;

public class Exercise_06_JaggedArray {
    public static void main(String[] args) {
        int[][] jagged = new int[3][];
        jagged[0] = new int[2];
        jagged[1] = new int[3];
        jagged[2] = new int[4];
        int value = 1;
        for (int i = 0; i < jagged.length; i++)
            for (int j = 0; j < jagged[i].length; j++)
                jagged[i][j] = value++;
        for (int[] row : jagged) {
            for (int num : row) System.out.print(num + " ");
            System.out.println();
        }
    }
}
