package com.module01.arrays;

public class Exercise_04_ArrayIteration {
    public static void main(String[] args) {
        double[] values = {12.5, 9.3, 4.7, 8.1};
        double sum = 0;
        for (double v : values) sum += v;
        System.out.println("Sum of all elements: " + sum);
    }
}
