package com.module01.arrays;

import java.util.Arrays;

public class Exercise_08_ArrayUtilities {
    public static void main(String[] args) {
        int[] data = {9, 3, 7, 1, 5};
        System.out.println("Before sorting: " + Arrays.toString(data));
        Arrays.sort(data);
        System.out.println("After sorting:  " + Arrays.toString(data));
    }
}
