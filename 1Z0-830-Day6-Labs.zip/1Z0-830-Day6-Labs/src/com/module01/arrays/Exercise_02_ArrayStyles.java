package com.module01.arrays;

public class Exercise_02_ArrayStyles {
    public static void main(String[] args) {
        String[] cities = new String[3];
        cities[0] = "Mumbai";
        cities[1] = "Chennai";
        cities[2] = "Kolkata";
        for (String city : cities) {
            System.out.println(city);
        }
    }
}
