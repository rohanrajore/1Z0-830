package com.module01.arrays;

public class Exercise_03_ArrayInitialization {
    public static void main(String[] args) {
        int[] marks = {88, 92, 76, 81, 95};
        int total = 0;
        for (int mark : marks) total += mark;
        double average = (double) total / marks.length;
        System.out.println("Average Marks: " + average);
    }
}
