package com.module01.arrays;

class Book {
    String title;
    Book(String title) { this.title = title; }
}

public class Exercise_07_ObjectArray {
    public static void main(String[] args) {
        Book[] books = new Book[3];
        books[0] = new Book("Clean Code");
        books[1] = new Book("Effective Java");
        books[2] = new Book("Java Concurrency in Practice");
        for (Book b : books) System.out.println(b.title);
    }
}
