package com.module08.generics;

import java.util.*;

public class Exercise_05_UpperBound {
    // TODO: Create a method printNumbers(List<? extends Number> list)
    public static void printNumbers(List<? extends Number> list) {
        for (Number n : list) {
            System.out.println("Value: " + n);
        }
    }

    public static void main(String[] args) {
        List<Integer> ints = List.of(10, 20, 30);
        List<Double> doubles = List.of(1.1, 2.2, 3.3);
        printNumbers(ints);
        printNumbers(doubles);
    }
}
