package com.module08.generics;

import java.util.*;

public class Exercise_04_WildcardDemo {
    public static void main(String[] args) {
        // TODO: Create a List<?> and print all elements, then try to add a new one
        List<?> list = List.of("Java", "Python", "C++");
        for (Object o : list) {
            System.out.println("Element: " + o);
        }

        // list.add("New"); // Compile-time error
    }
}
