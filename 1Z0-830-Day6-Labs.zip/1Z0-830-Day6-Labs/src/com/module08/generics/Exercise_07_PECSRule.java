package com.module08.generics;

import java.util.*;

public class Exercise_07_PECSRule {
    // TODO: Write a copy() method using ? extends and ? super
    public static void copy(List<? extends Number> src, List<? super Number> dest) {
        for (Number n : src) {
            dest.add(n);
        }
    }

    public static void main(String[] args) {
        List<Integer> src = List.of(1, 2, 3);
        List<Object> dest = new ArrayList<>();
        copy(src, dest);
        System.out.println("Destination list after copy: " + dest);
    }
}
