package com.module08.generics;

import java.util.*;

public class Exercise_06_LowerBound {
    public static void main(String[] args) {
        // TODO: Create a List<? super Integer> and add integers
        List<? super Integer> list = new ArrayList<Number>();
        list.add(10);
        list.add(20);

        System.out.println("List after additions: " + list);
        Object first = list.get(0);
        System.out.println("Retrieved element type: " + first.getClass().getName());
    }
}
