package com.module08.generics;

import java.util.*;

public class Exercise_08_TypeErasure {
    public static void main(String[] args) {
        // TODO: Demonstrate type erasure by comparing ArrayList<String> and ArrayList<Integer>
        List<String> strList = new ArrayList<>();
        List<Integer> intList = new ArrayList<>();
        System.out.println("Classes are same after type erasure: " + (strList.getClass() == intList.getClass()));
    }
}
