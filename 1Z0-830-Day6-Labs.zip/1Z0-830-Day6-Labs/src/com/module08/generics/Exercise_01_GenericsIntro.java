package com.module08.generics;

import java.util.*;

public class Exercise_01_GenericsIntro {
    public static void main(String[] args) {
        // TODO: Create a generic List<Integer> and add values, try adding a String
        List<Integer> numbers = new ArrayList<>();
        numbers.add(10);
        numbers.add(20);
        numbers.add(30);
        System.out.println("Numbers: " + numbers);

        // Uncommenting below line causes compile-time error
        // numbers.add("Hello");
    }
}
