package com.module08.generics;

public class Exercise_02_GenericBox {
    // TODO: Define a generic class Container<T> with add() and get()
    static class Container<T> {
        private T item;
        public void add(T item) { this.item = item; }
        public T get() { return item; }
    }

    public static void main(String[] args) {
        Container<Integer> intBox = new Container<>();
        intBox.add(100);
        System.out.println("Integer Box: " + intBox.get());

        Container<String> strBox = new Container<>();
        strBox.add("Java Generics");
        System.out.println("String Box: " + strBox.get());
    }
}
