package com.module02.collection_interfaces;

import java.util.*;

public class Exercise_07_CollectionChooser {
    public static void main(String[] args) {
        Set<Integer> employeeIds = new HashSet<>(Arrays.asList(101, 102, 103, 101));
        System.out.println("Unique Employee IDs: " + employeeIds);
        List<String> playlist = new ArrayList<>(Arrays.asList("Song A", "Song B", "Song C"));
        System.out.println("Ordered Playlist: " + playlist);
        Queue<String> taskQueue = new LinkedList<>(Arrays.asList("Login", "Validate", "Process", "Logout"));
        while (!taskQueue.isEmpty()) System.out.println("Task: " + taskQueue.poll());
        Map<String, String> config = new HashMap<>();
        config.put("theme", "dark");
        config.put("language", "English");
        System.out.println("Configurations: " + config);
    }
}
