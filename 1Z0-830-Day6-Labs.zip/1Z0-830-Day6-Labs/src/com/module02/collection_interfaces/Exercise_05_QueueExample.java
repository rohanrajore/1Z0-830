package com.module02.collection_interfaces;

import java.util.*;

public class Exercise_05_QueueExample {
    public static void main(String[] args) {
        Queue<String> tasks = new LinkedList<>();
        tasks.add("Compile Report");
        tasks.add("Send Email");
        tasks.add("Backup Data");
        while (!tasks.isEmpty()) System.out.println("Completed: " + tasks.poll());
    }
}
