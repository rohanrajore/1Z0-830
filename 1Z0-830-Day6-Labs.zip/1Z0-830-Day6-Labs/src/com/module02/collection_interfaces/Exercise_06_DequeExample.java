package com.module02.collection_interfaces;

import java.util.*;

public class Exercise_06_DequeExample {
    public static void main(String[] args) {
        Deque<Integer> stack = new ArrayDeque<>();
        stack.push(5);
        stack.push(10);
        stack.push(15);
        System.out.println("Stack after pushes: " + stack);
        while (!stack.isEmpty()) System.out.println("Popped: " + stack.pop());
    }
}
