package com.module02.collection_interfaces;

import java.util.*;

public class Exercise_01_CollectionIntro {
    public static void main(String[] args) {
        Collection<String> languages = new ArrayList<>();
        languages.add("Java");
        languages.add("Python");
        languages.add("Go");
        for (String lang : languages) System.out.println(lang);
    }
}
