package com.module02.collection_interfaces;

import java.util.*;

public class Exercise_02_ListExample {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>(Arrays.asList(10, 20, 30, 40, 50));
        numbers.remove(Integer.valueOf(30));
        System.out.println("Updated List: " + numbers);
    }
}
