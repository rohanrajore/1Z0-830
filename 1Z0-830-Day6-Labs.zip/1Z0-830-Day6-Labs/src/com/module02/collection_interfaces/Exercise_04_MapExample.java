package com.module02.collection_interfaces;

import java.util.*;

public class Exercise_04_MapExample {
    public static void main(String[] args) {
        Map<String, Integer> courses = new HashMap<>();
        courses.put("Java Fundamentals", 40);
        courses.put("Data Structures", 35);
        courses.put("Cloud Basics", 20);
        for (Map.Entry<String, Integer> entry : courses.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue() + " hours");
        }
    }
}
