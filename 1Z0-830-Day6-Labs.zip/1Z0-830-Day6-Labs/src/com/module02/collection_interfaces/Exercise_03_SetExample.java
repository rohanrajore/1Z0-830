package com.module02.collection_interfaces;

import java.util.*;

public class Exercise_03_SetExample {
    public static void main(String[] args) {
        Set<String> colors = new LinkedHashSet<>();
        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");
        colors.add("Red");
        System.out.println("Colors Set: " + colors);
    }
}
