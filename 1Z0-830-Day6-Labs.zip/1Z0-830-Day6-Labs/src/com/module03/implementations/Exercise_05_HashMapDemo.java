package com.module03.implementations;

import java.util.*;

public class Exercise_05_HashMapDemo {
    public static void main(String[] args) {
        Map<Integer, String> employees = new HashMap<>();
        employees.put(1001, "Ravi Kumar");
        employees.put(1002, "Sneha Patil");
        employees.put(1003, "Aarav Singh");
        for (Map.Entry<Integer, String> entry : employees.entrySet())
            System.out.println("ID: " + entry.getKey() + ", Name: " + entry.getValue());
    }
}
