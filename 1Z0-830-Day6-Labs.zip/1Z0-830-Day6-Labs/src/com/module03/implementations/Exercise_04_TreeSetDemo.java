package com.module03.implementations;

import java.util.*;

public class Exercise_04_TreeSetDemo {
    public static void main(String[] args) {
        Set<String> cities = new TreeSet<>(Arrays.asList("Pune", "Delhi", "Mumbai", "Bangalore"));
        System.out.println("Cities in ascending order: " + cities);
    }
}
