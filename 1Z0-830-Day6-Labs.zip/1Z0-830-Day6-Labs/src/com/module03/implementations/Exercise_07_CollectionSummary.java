package com.module03.implementations;

import java.util.*;

public class Exercise_07_CollectionSummary {
    public static void main(String[] args) {
        Set<Integer> userIds = new HashSet<>(Arrays.asList(501, 502, 503, 501));
        System.out.println("Unique User IDs (HashSet): " + userIds);
        Set<String> departments = new TreeSet<>(Arrays.asList("Finance", "HR", "IT", "Admin"));
        System.out.println("Departments (TreeSet): " + departments);
        List<Character> grades = new ArrayList<>(Arrays.asList('A', 'B', 'A', 'C'));
        System.out.println("Grades (ArrayList): " + grades.get(1));
        Map<String, Double> salaries = new HashMap<>();
        salaries.put("Ravi", 55000.0);
        salaries.put("Neha", 62000.0);
        salaries.put("Arjun", 50000.0);
        System.out.println("Employee Salaries (HashMap): " + salaries);
        Map<Integer, Integer> marks = new TreeMap<>();
        marks.put(3, 89);
        marks.put(1, 95);
        marks.put(2, 76);
        System.out.println("Marks Sorted by Roll No (TreeMap): " + marks);
    }
}
