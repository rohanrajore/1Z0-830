package com.module03.implementations;

import java.util.*;

public class Exercise_06_TreeMapDemo {
    public static void main(String[] args) {
        Map<Integer, String> students = new TreeMap<>();
        students.put(104, "Isha");
        students.put(101, "Rahul");
        students.put(103, "Maya");
        students.put(102, "Karan");
        for (Map.Entry<Integer, String> entry : students.entrySet())
            System.out.println(entry.getKey() + " -> " + entry.getValue());
    }
}
