package com.module03.implementations;

import java.util.*;

public class Exercise_03_HashSetDemo {
    public static void main(String[] args) {
        Set<String> students = new HashSet<>(Arrays.asList("Amit", "Sonal", "Vivek", "Amit"));
        System.out.println("Unique Student Names: " + students);
    }
}
