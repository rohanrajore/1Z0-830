package com.module03.implementations;

import java.util.*;

public class Exercise_01_ArrayListDemo {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>(Arrays.asList(5, 10, 15, 20, 25));
        numbers.remove(Integer.valueOf(15));
        System.out.println("Remaining numbers: " + numbers);
    }
}
