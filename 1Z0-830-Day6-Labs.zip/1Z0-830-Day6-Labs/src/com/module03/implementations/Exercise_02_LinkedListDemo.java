package com.module03.implementations;

import java.util.*;

public class Exercise_02_LinkedListDemo {
    public static void main(String[] args) {
        LinkedList<String> courses = new LinkedList<>(Arrays.asList("Java", "Python", "C++", "SQL", "Kotlin"));
        courses.addFirst("Cloud Fundamentals");
        courses.addLast("DevOps Essentials");
        System.out.println("Courses List: " + courses);
    }
}
