package com.module04.ordering_sorting;

import java.util.*;

class Student {
    String name;
    int marks;

    Student(String name, int marks) {
        this.name = name;
        this.marks = marks;
    }

    @Override
    public String toString() {
        return name + " (" + marks + ")";
    }
}

public class Exercise_03_ComparatorDemo {
    public static void main(String[] args) {
        // TODO: Sort students by marks descending and then by name
        List<Student> students = Arrays.asList(
                new Student("Ravi", 85),
                new Student("Anjali", 92),
                new Student("Meena", 85));

        Comparator<Student> comp = Comparator.comparingInt((Student s) -> s.marks)
                                             .reversed()
                                             .thenComparing(s -> s.name);

        Collections.sort(students, comp);
        System.out.println("Sorted Students: " + students);
    }
}
