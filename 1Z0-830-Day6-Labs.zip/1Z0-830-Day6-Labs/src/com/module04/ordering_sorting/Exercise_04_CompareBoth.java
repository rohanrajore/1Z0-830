package com.module04.ordering_sorting;

import java.util.*;

class Book implements Comparable<Book> {
    String title;
    double price;

    Book(String title, double price) {
        this.title = title;
        this.price = price;
    }

    @Override
    public int compareTo(Book other) {
        return this.title.compareTo(other.title);
    }

    public String toString() {
        return title + " - $" + price;
    }
}

public class Exercise_04_CompareBoth {
    public static void main(String[] args) {
        // TODO: Create a Book class implementing Comparable and Comparator for price
        List<Book> books = Arrays.asList(
                new Book("Java Basics", 300),
                new Book("Python Guide", 250),
                new Book("C++ Primer", 400));

        Collections.sort(books);
        System.out.println("Sorted by Title: " + books);

        books.sort(Comparator.comparingDouble(b -> b.price));
        System.out.println("Sorted by Price: " + books);
    }
}
