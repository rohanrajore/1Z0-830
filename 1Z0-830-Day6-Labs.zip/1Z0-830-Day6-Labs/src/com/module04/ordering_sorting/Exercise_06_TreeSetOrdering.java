package com.module04.ordering_sorting;

import java.util.*;

public class Exercise_06_TreeSetOrdering {
    public static void main(String[] args) {
        // TODO: Create a TreeSet of integers in descending order using Comparator
        Set<Integer> numbers = new TreeSet<>(Comparator.reverseOrder());
        numbers.addAll(Arrays.asList(5, 1, 8, 3, 7));

        System.out.println("TreeSet Descending: " + numbers);
    }
}
