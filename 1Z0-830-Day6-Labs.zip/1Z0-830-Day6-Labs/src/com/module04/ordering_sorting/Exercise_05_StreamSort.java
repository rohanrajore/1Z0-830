package com.module04.ordering_sorting;

import java.util.*;

public class Exercise_05_StreamSort {
    public static void main(String[] args) {
        // TODO: Sort employee names by length descending using streams
        List<String> employees = Arrays.asList("John", "Alexander", "Mia", "Sophia");

        employees.stream()
                 .sorted(Comparator.comparing(String::length).reversed())
                 .forEach(System.out::println);
    }
}
