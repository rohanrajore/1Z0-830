package com.module04.ordering_sorting;

import java.util.*;

class Product implements Comparable<Product> {
    double price;
    String name;

    Product(double price, String name) {
        this.price = price;
        this.name = name;
    }

    @Override
    public int compareTo(Product other) {
        return Double.compare(this.price, other.price); // ascending by price
    }

    public String toString() {
        return name + " - $" + price;
    }
}

public class Exercise_02_ComparableDemo {
    public static void main(String[] args) {
        // TODO: Create a class Product with fields price and name, sort by price
        List<Product> products = Arrays.asList(
                new Product(45.5, "Notebook"),
                new Product(10.0, "Pen"),
                new Product(25.0, "Pencil Box"));

        Collections.sort(products);
        System.out.println("Sorted by Price: " + products);
    }
}
