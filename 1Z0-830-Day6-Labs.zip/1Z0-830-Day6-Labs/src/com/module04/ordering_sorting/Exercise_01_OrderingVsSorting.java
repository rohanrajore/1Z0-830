package com.module04.ordering_sorting;

import java.util.*;

public class Exercise_01_OrderingVsSorting {
    public static void main(String[] args) {
        // TODO: Create a list of integers and sort them in ascending and descending order
        List<Integer> nums = Arrays.asList(5, 2, 8, 1, 9);

        Collections.sort(nums);
        System.out.println("Ascending: " + nums);

        nums.sort(Collections.reverseOrder());
        System.out.println("Descending: " + nums);
    }
}
