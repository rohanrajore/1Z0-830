package com.module07.wrapper_collections;

import java.util.*;

public class Exercise_03_UnmodifiableListDemo {
    public static void main(String[] args) {
        // TODO: Create a modifiable list, wrap it with unmodifiableList, and test behavior
        List<String> list = new ArrayList<>(List.of("One", "Two"));
        List<String> readOnly = Collections.unmodifiableList(list);

        System.out.println("Initial List: " + readOnly);

        try {
            readOnly.add("Three");
        } catch (UnsupportedOperationException e) {
            System.out.println("Cannot modify unmodifiable list: " + e);
        }

        list.add("Four");
        System.out.println("Underlying List Modified: " + readOnly);
    }
}
