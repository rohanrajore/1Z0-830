package com.module07.wrapper_collections;

import java.util.*;

public class Exercise_01_WrapperIntro {
    public static void main(String[] args) {
        // TODO: Create an ArrayList, wrap it with synchronizedList and unmodifiableList
        List<String> data = new ArrayList<>();
        data.add("Alpha");
        data.add("Beta");

        List<String> syncList = Collections.synchronizedList(data);
        List<String> readOnlyList = Collections.unmodifiableList(data);

        System.out.println("Synchronized List: " + syncList);
        System.out.println("Read-Only List: " + readOnlyList);
    }
}
