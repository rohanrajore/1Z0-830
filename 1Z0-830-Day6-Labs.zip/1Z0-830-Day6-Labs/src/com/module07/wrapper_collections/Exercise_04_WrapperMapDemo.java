package com.module07.wrapper_collections;

import java.util.*;

public class Exercise_04_WrapperMapDemo {
    public static void main(String[] args) {
        // TODO: Create a HashMap and wrap it in unmodifiableMap
        Map<Integer, String> map = new HashMap<>();
        map.put(1, "Apple");
        map.put(2, "Banana");

        Map<Integer, String> readOnlyMap = Collections.unmodifiableMap(map);
        System.out.println("Initial Map: " + readOnlyMap);

        map.put(3, "Cherry");
        System.out.println("After modifying base map: " + readOnlyMap);

        try {
            readOnlyMap.put(4, "Date");
        } catch (UnsupportedOperationException e) {
            System.out.println("Cannot modify through wrapper: " + e);
        }
    }
}
