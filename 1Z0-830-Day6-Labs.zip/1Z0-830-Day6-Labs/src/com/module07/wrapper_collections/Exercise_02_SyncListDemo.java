package com.module07.wrapper_collections;

import java.util.*;

public class Exercise_02_SyncListDemo {
    public static void main(String[] args) {
        // TODO: Create a synchronized list, add elements, and iterate safely
        List<String> list = new ArrayList<>();
        List<String> syncList = Collections.synchronizedList(list);

        syncList.add("Red");
        syncList.add("Green");
        syncList.add("Blue");

        synchronized (syncList) {
            for (String color : syncList) {
                System.out.println("Color: " + color);
            }
        }
    }
}
