package com.module07.wrapper_collections;

import java.util.*;

public class Exercise_06_CertificationCheck {
    public static void main(String[] args) {
        // TODO: Summarize difference between synchronized and unmodifiable wrappers
        List<Integer> baseList = new ArrayList<>(List.of(1, 2, 3));
        List<Integer> syncList = Collections.synchronizedList(baseList);
        List<Integer> unmodList = Collections.unmodifiableList(baseList);

        System.out.println("Base List: " + baseList);
        System.out.println("Synchronized Wrapper: " + syncList);
        System.out.println("Unmodifiable Wrapper: " + unmodList);

        baseList.add(4);
        System.out.println("After modifying base: " + unmodList);

        synchronized (syncList) {
            for (Integer i : syncList) {
                System.out.println("Synchronized Iteration: " + i);
            }
        }
    }
}
