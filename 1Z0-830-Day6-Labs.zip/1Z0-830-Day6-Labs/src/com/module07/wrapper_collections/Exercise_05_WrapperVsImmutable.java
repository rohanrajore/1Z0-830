package com.module07.wrapper_collections;

import java.util.*;

public class Exercise_05_WrapperVsImmutable {
    public static void main(String[] args) {
        // TODO: Compare unmodifiableList and List.of() behavior
        List<String> baseList = new ArrayList<>();
        baseList.add("Spring");
        List<String> unmodifiable = Collections.unmodifiableList(baseList);
        List<String> immutable = List.of("Autumn");

        baseList.add("Summer");

        System.out.println("Unmodifiable List (reflects base): " + unmodifiable);
        System.out.println("Immutable List (independent): " + immutable);

        try {
            immutable.add("Winter");
        } catch (UnsupportedOperationException e) {
            System.out.println("Immutable modification not allowed: " + e);
        }
    }
}
