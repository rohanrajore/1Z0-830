package com.module10.generic_methods;

public class Exercise_01_GenericMethodIntro {
    // TODO: Write a generic method display(T value) that prints any type
    public static <T> void display(T value) {
        System.out.println("Value: " + value);
    }

    public static void main(String[] args) {
        display("Java");
        display(42);
    }
}
