package com.module10.generic_methods;

public class Exercise_03_BoundedMethod {
    // TODO: Create a method <T extends Number> that returns the sum of two numbers
    public static <T extends Number> double sum(T a, T b) {
        return a.doubleValue() + b.doubleValue();
    }

    public static void main(String[] args) {
        System.out.println("Sum of Integers: " + sum(10, 20));
        System.out.println("Sum of Doubles: " + sum(2.5, 3.5));
    }
}
