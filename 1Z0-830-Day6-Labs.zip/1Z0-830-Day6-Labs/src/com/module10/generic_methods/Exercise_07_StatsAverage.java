package com.module10.generic_methods;

import java.util.*;

public class Exercise_07_StatsAverage {
    // TODO: Create a method <T extends Number> that calculates average of list
    public static <T extends Number> double average(List<T> list) {
        double sum = 0;
        for (T val : list) sum += val.doubleValue();
        return list.isEmpty() ? 0 : sum / list.size();
    }

    public static void main(String[] args) {
        List<Integer> intList = List.of(10, 20, 30);
        List<Double> dblList = List.of(1.5, 2.5, 3.5);
        System.out.println("Integer Average: " + average(intList));
        System.out.println("Double Average: " + average(dblList));
    }
}
