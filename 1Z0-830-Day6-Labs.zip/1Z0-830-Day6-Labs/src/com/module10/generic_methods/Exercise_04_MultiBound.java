package com.module10.generic_methods;

interface Printable { void print(); }
interface Identifiable { int getId(); }

class Report implements Printable, Identifiable {
    private int id;
    Report(int id) { this.id = id; }
    public void print() { System.out.println("Printing Report ID: " + id); }
    public int getId() { return id; }
}

public class Exercise_04_MultiBound {
    // TODO: Create a generic method with multiple bounds
    public static <T extends Printable & Identifiable> void show(T obj) {
        obj.print();
        System.out.println("Object ID: " + obj.getId());
    }

    public static void main(String[] args) {
        Report r = new Report(101);
        show(r);
    }
}
