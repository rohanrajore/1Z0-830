package com.module10.generic_methods;

public class Exercise_06_GenericComparison {
    // TODO: Create a non-generic class with a generic method
    public <T> void printType(T data) {
        System.out.println("Value: " + data + " | Type: " + data.getClass().getSimpleName());
    }

    public static void main(String[] args) {
        Exercise_06_GenericComparison printer = new Exercise_06_GenericComparison();
        printer.printType(123);
        printer.printType("Java");
        printer.printType(45.67);
    }
}
