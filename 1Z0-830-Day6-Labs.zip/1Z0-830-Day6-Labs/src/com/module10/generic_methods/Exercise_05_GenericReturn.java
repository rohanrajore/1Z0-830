package com.module10.generic_methods;

public class Exercise_05_GenericReturn {
    // TODO: Create a method <T> T echo(T input)
    public static <T> T echo(T input) {
        return input;
    }

    public static void main(String[] args) {
        String text = echo("Hello Generics");
        Double number = echo(99.9);

        System.out.println("Echoed Text: " + text);
        System.out.println("Echoed Number: " + number);
    }
}
