package com.module10.generic_methods;

public class Exercise_08_MinFinder {
    // TODO: Write a method <T extends Comparable<T>> that returns smaller of two elements
    public static <T extends Comparable<T>> T min(T a, T b) {
        return (a.compareTo(b) < 0) ? a : b;
    }

    public static void main(String[] args) {
        System.out.println("Min of Integers: " + min(15, 25));
        System.out.println("Min of Strings: " + min("Apple", "Banana"));
    }
}
