package com.module10.generic_methods;

public class Exercise_02_MultiTypeParams {
    // TODO: Write a generic method with <X, Y> that prints both parameters
    public static <X, Y> void printPair(X first, Y second) {
        System.out.println("First: " + first + ", Second: " + second);
    }

    public static void main(String[] args) {
        printPair("Language", "Java");
        printPair(1, 99.9);
    }
}
