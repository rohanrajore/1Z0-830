package com.module09.typeerasure;

public class Exercise_04_BridgeDemo {
    static class Parent<T> {
        T get() { return null; }
    }

    static class Child extends Parent<String> {
        @Override
        String get() { return "Bridge Method Example"; }
    }

    public static void main(String[] args) {
        // TODO: Compile and decompile to observe the bridge method
        Child c = new Child();
        System.out.println(c.get());
    }
}
