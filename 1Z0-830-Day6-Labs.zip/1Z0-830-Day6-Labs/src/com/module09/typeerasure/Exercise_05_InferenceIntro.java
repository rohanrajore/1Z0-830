package com.module09.typeerasure;

import java.util.*;

public class Exercise_05_InferenceIntro {
    public static void main(String[] args) {
        // TODO: Use diamond operator with collections
        List<String> names = new ArrayList<>();
        Map<Integer, String> map = new HashMap<>();
        Set<Double> numbers = new TreeSet<>();

        names.add("Java");
        map.put(1, "Python");
        numbers.add(2.5);

        System.out.println("Names: " + names);
        System.out.println("Map: " + map);
        System.out.println("Numbers: " + numbers);
    }
}
