package com.module09.typeerasure;

public class Exercise_02_ErasureView {
    // TODO: Write a generic class and manually rewrite it as compiler would after type erasure

    // Generic version
    static class Box<T> {
        T value;
        T get() { return value; }
        void set(T value) { this.value = value; }
    }

    // After erasure (conceptual only)
    static class BoxAfterErasure {
        Object value;
        Object get() { return value; }
        void set(Object value) { this.value = value; }
    }

    public static void main(String[] args) {
        Box<String> box = new Box<>();
        box.set("Hello Generics");
        System.out.println("Box value: " + box.get());
    }
}
