package com.module09.typeerasure;

import java.util.*;

public class Exercise_03_GenericLimitations {
    public static void main(String[] args) {
        // TODO: Attempt to create a generic array and handle compiler error using List instead
        // List<String>[] arr = new List<String>[5]; // not allowed

        List<List<String>> listOfLists = new ArrayList<>();
        listOfLists.add(List.of("A", "B", "C"));

        if (listOfLists instanceof List<?>) {
            System.out.println("It's a list of something!");
        }

        System.out.println("List content: " + listOfLists);
    }
}
