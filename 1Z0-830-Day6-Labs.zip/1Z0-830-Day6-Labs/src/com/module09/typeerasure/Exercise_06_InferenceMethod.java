package com.module09.typeerasure;

import java.util.Comparator;

public class Exercise_06_InferenceMethod {
    // TODO: Write a generic method max(T a, T b, Comparator<T>)
    public static <T> T max(T a, T b, Comparator<T> comp) {
        return comp.compare(a, b) >= 0 ? a : b;
    }

    public static void main(String[] args) {
        System.out.println("Max Integer: " + max(10, 20, Integer::compare));
        System.out.println("Max String: " + max("Apple", "Banana", String::compareTo));
    }
}
