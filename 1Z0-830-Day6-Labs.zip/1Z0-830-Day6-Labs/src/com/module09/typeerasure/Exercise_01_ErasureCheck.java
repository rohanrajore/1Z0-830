package com.module09.typeerasure;

import java.util.*;

public class Exercise_01_ErasureCheck {
    public static void main(String[] args) {
        // TODO: Create a List<String> and List<Double>, compare their getClass() results
        List<String> strList = new ArrayList<>();
        List<Double> dblList = new ArrayList<>();

        System.out.println("List<String> class: " + strList.getClass());
        System.out.println("List<Double> class: " + dblList.getClass());
        System.out.println("Are they same? " + (strList.getClass() == dblList.getClass()));
    }
}
