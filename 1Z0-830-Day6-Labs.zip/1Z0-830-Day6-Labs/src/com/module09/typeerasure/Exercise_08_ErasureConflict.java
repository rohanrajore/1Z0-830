package com.module09.typeerasure;

import java.util.*;

public class Exercise_08_ErasureConflict {
    // TODO: Try overloading methods differing only in generic type parameters

    // void print(List<String> list) {}
    // void print(List<Integer> list) {} // compile-time error after erasure

    public static void main(String[] args) {
        System.out.println("Overloading methods with generics fails due to type erasure.");
    }
}
