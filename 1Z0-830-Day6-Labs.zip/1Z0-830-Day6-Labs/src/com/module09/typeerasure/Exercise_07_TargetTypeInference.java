package com.module09.typeerasure;

import java.util.*;

public class Exercise_07_TargetTypeInference {
    public static void main(String[] args) {
        // TODO: Use lambda expression that sorts list using List.sort() without specifying Comparator type
        List<String> names = new ArrayList<>(List.of("Zoe", "Adam", "Maya"));
        names.sort((a, b) -> a.compareTo(b));
        System.out.println("Sorted Names: " + names);
    }
}
