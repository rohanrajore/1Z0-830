package com.module11.generic_pitfalls;

import java.util.*;

public class Exercise_05_GenericArray {
    public static void main(String[] args) {
        // TODO: Try creating an array of generic lists and observe compiler error
        // List<String>[] arr = new List<String>[5]; // not allowed

        List<?>[] safeArray = new List<?>[3]; // allowed but unsafe
        safeArray[0] = List.of(1, 2, 3); // heap pollution warning

        System.out.println("Array element: " + safeArray[0]);
    }
}
