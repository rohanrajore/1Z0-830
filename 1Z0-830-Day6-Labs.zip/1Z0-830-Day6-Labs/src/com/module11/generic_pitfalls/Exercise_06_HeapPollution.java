package com.module11.generic_pitfalls;

import java.util.*;

public class Exercise_06_HeapPollution {
    public static void main(String[] args) {
        // TODO: Demonstrate heap pollution through raw reference
        List<String> strings = new ArrayList<>();
        List raw = strings; // raw assignment
        raw.add(100); // heap pollution

        try {
            for (String s : strings) {
                System.out.println(s);
            }
        } catch (ClassCastException e) {
            System.out.println("Heap pollution detected: " + e);
        }
    }
}
