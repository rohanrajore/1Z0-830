package com.module11.generic_pitfalls;

import java.util.*;

public class Exercise_02_RawVsGeneric {
    public static void main(String[] args) {
        // TODO: Create raw and generic lists and try assigning one to another
        List rawList = new ArrayList();
        List<String> genericList = new ArrayList<>();

        rawList.add(123);
        genericList.add("Safe");

        // Warning: unchecked assignment
        genericList = rawList;

        System.out.println("Generic List: " + genericList);
    }
}
