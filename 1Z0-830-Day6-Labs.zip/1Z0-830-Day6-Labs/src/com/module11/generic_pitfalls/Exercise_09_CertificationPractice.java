package com.module11.generic_pitfalls;

import java.util.*;

public class Exercise_09_CertificationPractice {
    public static void main(String[] args) {
        // TODO: Demonstrate compile-time warning, runtime exception, and safe usage

        // 1. Compile-time warning
        List rawList = new ArrayList();
        rawList.add("Java");
        rawList.add(100);
        System.out.println("Raw List (warning example): " + rawList);

        // 2. Runtime exception
        List<Integer> unsafeList = new ArrayList<>();
        unsafeList.add(1);
        List unsafeRef = unsafeList;
        unsafeRef.add("Wrong");
        try {
            Integer val = unsafeList.get(1);
        } catch (ClassCastException e) {
            System.out.println("Runtime Exception Example: " + e);
        }

        // 3. Safe usage
        List<?> safeList = List.of("Java", 100, true);
        System.out.println("Safe List: " + safeList);
    }
}
