package com.module11.generic_pitfalls;

import java.util.*;

public class Exercise_04_UncheckedCast {
    public static void main(String[] args) {
        // TODO: Perform unchecked cast from Object to List<Integer>
        Object obj = new ArrayList<String>();
        @SuppressWarnings("unchecked")
        List<Integer> nums = (List<Integer>) obj; // unchecked warning

        try {
            nums.add(10);
            System.out.println("List: " + nums);
        } catch (Exception e) {
            System.out.println("Caught exception: " + e);
        }
    }
}
