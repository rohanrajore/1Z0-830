package com.module11.generic_pitfalls;

import java.util.*;

public class Exercise_01_RawTypeError {
    public static void main(String[] args) {
        // TODO: Create a raw list, mix types, and cast incorrectly
        List list = new ArrayList(); // raw type
        list.add("Java");
        list.add(10); // unsafe

        try {
            String str = (String) list.get(1); // causes ClassCastException
            System.out.println("String: " + str);
        } catch (ClassCastException e) {
            System.out.println("Caught exception: " + e);
        }
    }
}
