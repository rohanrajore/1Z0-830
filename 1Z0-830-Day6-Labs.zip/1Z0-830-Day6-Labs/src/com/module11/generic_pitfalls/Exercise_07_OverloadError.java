package com.module11.generic_pitfalls;

import java.util.*;

public class Exercise_07_OverloadError {
    // TODO: Demonstrate overloading failure due to type erasure

    // void print(List<String> list) {}
    // void print(List<Integer> list) {} // compile-time error after erasure

    public static void main(String[] args) {
        System.out.println("Method overloading with generic parameters is not allowed after type erasure.");
    }
}
