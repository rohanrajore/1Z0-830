package com.module11.generic_pitfalls;

import java.util.*;

public class Exercise_03_MixedTypeDemo {
    public static void main(String[] args) {
        // TODO: Assign generic collection to raw reference and insert invalid data
        List<String> list = new ArrayList<>();
        list.add("Alpha");
        List raw = list; // unchecked conversion
        raw.add(100);    // breaks type safety

        try {
            String s = list.get(1); // runtime ClassCastException
            System.out.println("Value: " + s);
        } catch (ClassCastException e) {
            System.out.println("Error: " + e);
        }
    }
}
