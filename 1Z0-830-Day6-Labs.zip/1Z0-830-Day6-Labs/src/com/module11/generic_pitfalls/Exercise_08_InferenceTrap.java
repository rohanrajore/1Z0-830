package com.module11.generic_pitfalls;

public class Exercise_08_InferenceTrap {
    // TODO: Create a generic method returning one of two arguments of different types
    public static <T> T pick(T a, T b) {
        return a;
    }

    public static void main(String[] args) {
        Object result = pick(10, "Hello"); // inferred as Object
        System.out.println("Inferred Type: " + result.getClass().getSimpleName());
    }
}
