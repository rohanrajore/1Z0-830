package com.module06.failfast_iterators;

import java.util.*;

public class Exercise_01_FailFastDemo {
    public static void main(String[] args) {
        // TODO: Create a list of 5 strings and try removing one element inside enhanced for-loop
        List<String> names = new ArrayList<>(List.of("Alpha", "Bravo", "Charlie", "Delta", "Echo"));

        try {
            for (String n : names) {
                if (n.equals("Charlie")) {
                    names.remove(n); // triggers ConcurrentModificationException
                }
            }
        } catch (ConcurrentModificationException e) {
            System.out.println("Caught Exception: " + e);
        }
    }
}
