package com.module06.failfast_iterators;

import java.util.*;
import java.util.concurrent.*;

public class Exercise_04_FailSafeDemo {
    public static void main(String[] args) {
        // TODO: Demonstrate fail-safe behavior using CopyOnWriteArrayList
        List<String> safeList = new CopyOnWriteArrayList<>(List.of("A", "B", "C"));

        for (String s : safeList) {
            safeList.add("D"); // No ConcurrentModificationException
        }
        System.out.println("CopyOnWriteArrayList after iteration: " + safeList);

        // Compare with ArrayList
        List<String> regularList = new ArrayList<>(List.of("X", "Y", "Z"));
        try {
            for (String s : regularList) {
                regularList.add("W"); // triggers CME
            }
        } catch (ConcurrentModificationException e) {
            System.out.println("ArrayList is fail-fast: " + e);
        }
    }
}
