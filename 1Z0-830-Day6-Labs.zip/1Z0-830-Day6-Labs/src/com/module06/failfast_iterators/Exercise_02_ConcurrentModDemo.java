package com.module06.failfast_iterators;

import java.util.*;

public class Exercise_02_ConcurrentModDemo {
    public static void main(String[] args) {
        // TODO: Create a list and iterate using explicit iterator, modify during iteration
        List<Integer> numbers = new ArrayList<>(List.of(1, 2, 3, 4));

        Iterator<Integer> it = numbers.iterator();
        numbers.add(5); // modifies list after iterator creation

        try {
            while (it.hasNext()) {
                System.out.println(it.next());
            }
        } catch (ConcurrentModificationException e) {
            System.out.println("ConcurrentModificationException occurred: " + e);
        }
    }
}
