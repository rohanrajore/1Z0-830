package com.module06.failfast_iterators;

import java.util.*;

public class Exercise_05_MapFailFast {
    public static void main(String[] args) {
        // TODO: Create a HashMap and modify it during iteration
        Map<Integer, String> studentMap = new HashMap<>();
        studentMap.put(1, "Amit");
        studentMap.put(2, "Neha");
        studentMap.put(3, "Raj");

        try {
            for (Integer key : studentMap.keySet()) {
                if (key == 2) {
                    studentMap.put(4, "Riya"); // triggers CME
                }
            }
        } catch (ConcurrentModificationException e) {
            System.out.println("ConcurrentModificationException caught: " + e);
        }
    }
}
