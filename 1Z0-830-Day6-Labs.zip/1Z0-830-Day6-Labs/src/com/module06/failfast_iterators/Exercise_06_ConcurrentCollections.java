package com.module06.failfast_iterators;

import java.util.concurrent.*;
import java.util.*;

public class Exercise_06_ConcurrentCollections {
    public static void main(String[] args) {
        // TODO: Replace regular collection with concurrent equivalent
        Map<Integer, String> concurrentMap = new ConcurrentHashMap<>();
        concurrentMap.put(1, "Apple");
        concurrentMap.put(2, "Banana");

        for (Integer key : concurrentMap.keySet()) {
            concurrentMap.put(3, "Cherry"); // No exception
        }
        System.out.println("ConcurrentHashMap content: " + concurrentMap);

        // Compare with non-concurrent collection
        Map<Integer, String> normalMap = new HashMap<>(Map.of(1, "Dog", 2, "Cat"));
        try {
            for (Integer key : normalMap.keySet()) {
                normalMap.put(3, "Horse"); // triggers CME
            }
        } catch (ConcurrentModificationException e) {
            System.out.println("Non-concurrent collection failed: " + e);
        }
    }
}
