package com.module06.failfast_iterators;

import java.util.*;

public class Exercise_03_SafeRemoval {
    public static void main(String[] args) {
        // TODO: Safely remove elements using iterator.remove()
        List<String> items = new ArrayList<>(List.of("Pen", "Book", "Pencil", "Eraser"));

        Iterator<String> iterator = items.iterator();
        while (iterator.hasNext()) {
            String item = iterator.next();
            if (item.equals("Book") || item.equals("Eraser")) {
                iterator.remove(); // safe removal
            }
        }

        System.out.println("Final List after safe removal: " + items);
    }
}
