package com.module05.immutable_collections;

import java.util.*;

public class Exercise_07_ImmutablePractice {
    public static void main(String[] args) {
        // TODO: Demonstrate mutable, unmodifiable, and immutable collections

        // Mutable List
        List<String> mutableList = new ArrayList<>(Arrays.asList("Dog", "Cat"));
        mutableList.add("Parrot");
        System.out.println("Mutable List: " + mutableList);

        // Unmodifiable List
        List<String> unmodifiableList = Collections.unmodifiableList(mutableList);
        mutableList.add("Fish");
        System.out.println("Unmodifiable List reflects original: " + unmodifiableList);

        // Immutable Set
        Set<String> immutableSet = Set.of("Red", "Blue", "Green");
        System.out.println("Immutable Set: " + immutableSet);

        // Immutable Map
        Map<Integer, String> immutableMap = Map.of(1, "One", 2, "Two", 3, "Three");
        System.out.println("Immutable Map: " + immutableMap);

        try {
            immutableSet.add("Yellow");
        } catch (UnsupportedOperationException e) {
            System.out.println("Cannot modify immutable set: " + e.getMessage());
        }
    }
}
