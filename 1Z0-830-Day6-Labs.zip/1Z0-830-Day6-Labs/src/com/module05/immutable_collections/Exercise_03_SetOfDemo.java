package com.module05.immutable_collections;

import java.util.*;

public class Exercise_03_SetOfDemo {
    public static void main(String[] args) {
        // TODO: Create a Set of five programming languages using Set.of()
        Set<String> languages = Set.of("Java", "Python", "Go", "Kotlin", "Rust");
        System.out.println("Programming Languages: " + languages);

        // Attempt to create duplicate entries
        try {
            Set<String> duplicate = Set.of("C", "C++", "C");
        } catch (IllegalArgumentException e) {
            System.out.println("Duplicate not allowed: " + e.getMessage());
        }
    }
}
