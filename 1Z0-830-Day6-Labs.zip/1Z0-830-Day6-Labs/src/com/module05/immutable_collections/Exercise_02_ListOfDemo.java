package com.module05.immutable_collections;

import java.util.*;

public class Exercise_02_ListOfDemo {
    public static void main(String[] args) {
        // TODO: Create a list of integers using List.of() and print each value
        List<Integer> numbers = List.of(10, 20, 30, 40, 50);
        for (int n : numbers) {
            System.out.println("Value: " + n);
        }
    }
}
