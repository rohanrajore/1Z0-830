package com.module05.immutable_collections;

import java.util.*;
import static java.util.Map.entry;

public class Exercise_05_MapOfEntriesDemo {
    public static void main(String[] args) {
        // TODO: Create a Map<Integer, String> with more than 10 entries using Map.ofEntries()
        Map<Integer, String> bigMap = Map.ofEntries(
            entry(1, "One"), entry(2, "Two"), entry(3, "Three"), entry(4, "Four"),
            entry(5, "Five"), entry(6, "Six"), entry(7, "Seven"), entry(8, "Eight"),
            entry(9, "Nine"), entry(10, "Ten"), entry(11, "Eleven"), entry(12, "Twelve")
        );
        System.out.println("Map values: " + bigMap.values());
    }
}
