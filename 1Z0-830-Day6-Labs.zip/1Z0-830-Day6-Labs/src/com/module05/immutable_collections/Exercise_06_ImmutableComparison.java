package com.module05.immutable_collections;

import java.util.*;

public class Exercise_06_ImmutableComparison {
    public static void main(String[] args) {
        // TODO: Compare unmodifiable and immutable collections
        List<String> modifiable = new ArrayList<>(Arrays.asList("Alpha", "Beta"));
        List<String> unmodifiable = Collections.unmodifiableList(modifiable);
        List<String> immutable = List.of("X", "Y");

        modifiable.add("Gamma");

        System.out.println("Original List: " + modifiable);
        System.out.println("Unmodifiable View: " + unmodifiable);
        System.out.println("Immutable List: " + immutable);

        try {
            immutable.add("Z");
        } catch (UnsupportedOperationException e) {
            System.out.println("Immutable modification error: " + e.getMessage());
        }
    }
}
