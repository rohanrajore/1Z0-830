package com.module05.immutable_collections;

import java.util.*;

public class Exercise_04_MapOfDemo {
    public static void main(String[] args) {
        // TODO: Create a Map of subject codes and names using Map.of()
        Map<Integer, String> subjects = Map.of(
            101, "Mathematics",
            102, "Science",
            103, "History"
        );
        System.out.println("Subjects: " + subjects);

        try {
            Map<Integer, String> invalid = Map.of(null, "Invalid");
        } catch (NullPointerException e) {
            System.out.println("Null keys not allowed: " + e.getMessage());
        }
    }
}
