package com.module05.immutable_collections;

import java.util.*;

public class Exercise_01_ImmutableIntro {
    public static void main(String[] args) {
        // TODO: Create a List of 3 car brands using List.of() and try to modify it
        List<String> cars = List.of("Tesla", "BMW", "Audi");
        System.out.println("Car Brands: " + cars);

        try {
            cars.add("Mercedes");
        } catch (UnsupportedOperationException e) {
            System.out.println("Exception: " + e);
        }
    }
}
