package com.module08.this_super;

public class Exercise_06_SuperField {
    // TODO: Access hidden parent field using super

    static class Parent {
        int value = 10;
    }

    static class Child extends Parent {
        int value = 20;

        void show() {
            System.out.println("Parent value: " + super.value);
            System.out.println("Child value: " + this.value);
        }
    }

    public static void main(String[] args) {
        new Child().show();
    }
}
