package com.module08.this_super;

public class Exercise_07_SuperMethod {
    // TODO: Use super.method() to call parent version during override

    static class Shape {
        void draw() { System.out.println("Drawing shape"); }
    }

    static class Circle extends Shape {
        @Override
        void draw() {
            super.draw();
            System.out.println("Drawing circle");
        }
    }

    public static void main(String[] args) {
        new Circle().draw();
    }
}
