package com.module08.this_super;

public class Exercise_08_ThisVsSuper {
    // TODO: Use both this and super to show behavior difference

    static class Base {
        Base() { System.out.println("Base constructor"); }
        void greet() { System.out.println("Hello from Base"); }
    }

    static class Derived extends Base {
        Derived() {
            super();
            System.out.println("Derived constructor using super()");
        }

        void greet() {
            super.greet();
            System.out.println("Hello from Derived using this");
        }
    }

    public static void main(String[] args) {
        Derived d = new Derived();
        d.greet();
    }
}
