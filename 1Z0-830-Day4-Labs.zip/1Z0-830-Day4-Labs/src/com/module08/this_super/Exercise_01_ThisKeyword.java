package com.module08.this_super;

public class Exercise_01_ThisKeyword {
    // TODO: Use 'this' to distinguish between field and constructor parameter

    static class City {
        String city;

        City(String city) {
            this.city = city; // this clarifies that field 'city' refers to instance variable
        }

        void show() {
            System.out.println("City: " + this.city);
        }
    }

    public static void main(String[] args) {
        City c = new City("Bangalore");
        c.show();
    }
}
