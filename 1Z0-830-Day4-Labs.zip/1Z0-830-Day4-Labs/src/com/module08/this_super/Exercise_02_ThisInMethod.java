package com.module08.this_super;

public class Exercise_02_ThisInMethod {
    // TODO: Call one method from another using this and print call sequence

    static class Employee {
        void work() {
            System.out.println("Employee is working...");
        }

        void report() {
            this.work(); // explicitly using 'this' to call another method
            System.out.println("Report submitted.");
        }
    }

    public static void main(String[] args) {
        Employee e = new Employee();
        e.report();
    }
}
