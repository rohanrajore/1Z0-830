package com.module08.this_super;

public class Exercise_11_CommonMistakes {
    // TODO: Show incorrect and correct usage of this() and super()

    // ❌ Incorrect Example (commented to prevent compile error)
    /*
    static class DemoWrong {
        DemoWrong() {
            System.out.println("Before this()"); // ❌ cannot appear before this()
            this(10);
        }
        DemoWrong(int x) {}
    }
    */

    // ✅ Correct Example
    static class DemoCorrect {
        DemoCorrect() {
            this(10); // must be the first statement
            System.out.println("DemoCorrect constructor works fine");
        }
        DemoCorrect(int x) {
            System.out.println("Value: " + x);
        }
    }

    public static void main(String[] args) {
        new DemoCorrect();
    }
}
