package com.module08.this_super;

public class Exercise_04_SuperKeyword {
    // TODO: Override a method and call parent version using super

    static class Animal {
        void sound() {
            System.out.println("Animal makes a sound");
        }
    }

    static class Dog extends Animal {
        @Override
        void sound() {
            super.sound(); // calls parent's version
            System.out.println("Dog barks");
        }
    }

    public static void main(String[] args) {
        Dog d = new Dog();
        d.sound();
    }
}
