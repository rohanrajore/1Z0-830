package com.module08.this_super;

public class Exercise_09_ConstructorOrder {
    // TODO: Show constructor execution order in a 3-level hierarchy

    static class A {
        A() { System.out.println("A's constructor"); }
    }

    static class B extends A {
        B() {
            super();
            System.out.println("B's constructor");
        }
    }

    static class C extends B {
        C() {
            super();
            System.out.println("C's constructor");
        }
    }

    public static void main(String[] args) {
        new C();
    }
}
