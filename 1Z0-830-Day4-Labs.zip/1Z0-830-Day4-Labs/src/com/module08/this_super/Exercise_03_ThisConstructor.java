package com.module08.this_super;

public class Exercise_03_ThisConstructor {
    // TODO: Use 'this()' to call another constructor in the same class

    static class Book {
        String title;
        int pages;

        Book() {
            this("Untitled", 100); // calls parameterized constructor
        }

        Book(String title, int pages) {
            this.title = title;
            this.pages = pages;
        }

        void show() {
            System.out.println(title + " - " + pages + " pages");
        }
    }

    public static void main(String[] args) {
        Book b1 = new Book();
        Book b2 = new Book("Java Fundamentals", 400);
        b1.show();
        b2.show();
    }
}
