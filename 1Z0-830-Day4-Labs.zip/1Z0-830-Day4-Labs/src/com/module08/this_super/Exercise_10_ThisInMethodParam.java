package com.module08.this_super;

public class Exercise_10_ThisInMethodParam {
    // TODO: Pass 'this' as parameter to another class method

    static class Printer {
        void print(Employee e) {
            System.out.println("Printing: " + e.name);
        }
    }

    static class Employee {
        String name;
        Employee(String name) { this.name = name; }

        void sendToPrinter(Printer p) {
            p.print(this); // passes current object
        }
    }

    public static void main(String[] args) {
        Employee e = new Employee("John");
        Printer p = new Printer();
        e.sendToPrinter(p);
    }
}
