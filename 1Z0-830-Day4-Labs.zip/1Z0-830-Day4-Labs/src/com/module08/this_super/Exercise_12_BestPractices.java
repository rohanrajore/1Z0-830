package com.module08.this_super;

public class Exercise_12_BestPractices {
    // TODO: Demonstrate constructor chaining and super() usage for clean design

    static class Vehicle {
        String type;
        Vehicle(String type) {
            this.type = type;
            System.out.println("Vehicle created: " + type);
        }
    }

    static class Car extends Vehicle {
        String brand;

        Car(String type, String brand) {
            super(type); // call parent constructor
            this.brand = brand;
            System.out.println("Car created: " + brand);
        }
    }

    static class ElectricCar extends Car {
        int battery;

        ElectricCar(String type, String brand, int battery) {
            super(type, brand); // reuse parent logic
            this.battery = battery;
            System.out.println("ElectricCar with battery: " + battery + " kWh");
        }
    }

    public static void main(String[] args) {
        new ElectricCar("Vehicle", "Tesla", 100);
    }
}
