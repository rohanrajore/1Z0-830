package com.module08.this_super;

public class Exercise_05_SuperConstructor {
    // TODO: Use super() to call parent constructor

    static class Person {
        String name;

        Person(String name) {
            this.name = name;
            System.out.println("Person created: " + name);
        }
    }

    static class Teacher extends Person {
        Teacher(String name) {
            super(name); // calls Person(name)
            System.out.println("Teacher created");
        }
    }

    public static void main(String[] args) {
        new Teacher("Alice");
    }
}
