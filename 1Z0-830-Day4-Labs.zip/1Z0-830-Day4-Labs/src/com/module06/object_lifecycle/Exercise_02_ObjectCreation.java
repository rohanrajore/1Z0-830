package com.module06.object_lifecycle;

public class Exercise_02_ObjectCreation {
    // TODO: Print statements in constructor to visualize object creation

    static class Car {
        String brand;
        Car(String brand) {
            this.brand = brand;
            System.out.println("Car object created on heap with brand: " + brand);
        }
    }

    public static void main(String[] args) {
        Car c = new Car("Tesla");
        System.out.println("Reference stored in stack: c -> " + c);
    }
}
