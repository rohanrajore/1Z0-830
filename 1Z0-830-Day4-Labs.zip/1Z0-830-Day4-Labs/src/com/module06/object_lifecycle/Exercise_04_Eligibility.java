package com.module06.object_lifecycle;

public class Exercise_04_Eligibility {
    // TODO: Demonstrate eligibility vs collection timing using finalize()

    static class Book {
        String title;
        Book(String title) {
            this.title = title;
            System.out.println("Book created: " + title);
        }

        @Override
        protected void finalize() {
            System.out.println("Finalize called for: " + title);
        }
    }

    public static void main(String[] args) {
        Book b = new Book("Java in Action");
        b = null;
        System.out.println("Book reference set to null (eligible for GC)");
        System.gc();
        System.out.println("Requested GC, finalize() may or may not execute immediately.");
    }
}
