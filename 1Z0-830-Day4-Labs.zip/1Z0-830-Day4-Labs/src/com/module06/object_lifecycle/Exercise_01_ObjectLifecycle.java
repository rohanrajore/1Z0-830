package com.module06.object_lifecycle;

public class Exercise_01_ObjectLifecycle {
    // TODO: Track object lifecycle through creation, use, and null assignment

    static class Book {
        String title;
        Book(String title) {
            this.title = title;
            System.out.println("Book created: " + title);
        }
    }

    public static void main(String[] args) {
        System.out.println("Before creation");
        Book b = new Book("Java 21 Developer");
        System.out.println("Using object: " + b.title);
        b = null;
        System.out.println("After setting reference to null (eligible for GC)");
    }
}
