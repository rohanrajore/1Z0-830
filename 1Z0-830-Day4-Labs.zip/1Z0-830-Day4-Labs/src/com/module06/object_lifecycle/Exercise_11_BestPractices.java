package com.module06.object_lifecycle;

public class Exercise_11_BestPractices {
    // TODO: Simulate clearing references to manage memory efficiently

    static class Data {
        int[] payload = new int[100000];
    }

    public static void main(String[] args) {
        System.out.println("Starting simulation without clearing references...");
        for (int i = 0; i < 5; i++) {
            Data d = new Data();
            System.out.println("Iteration " + i + " done.");
        }

        System.out.println("Now simulating with explicit nullification...");
        for (int i = 0; i < 5; i++) {
            Data d = new Data();
            System.out.println("Iteration " + i + " done.");
            d = null;
        }
        System.out.println("Observe heap usage differences via VisualVM.");
    }
}
