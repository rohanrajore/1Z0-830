package com.module06.object_lifecycle;

import java.lang.ref.WeakReference;

public class Exercise_09_WeakReference {
    // TODO: Demonstrate WeakReference behavior

    static class Book {
        String title;
        Book(String title) { this.title = title; }
        @Override
        public String toString() { return "Book{" + title + "}"; }
    }

    public static void main(String[] args) {
        WeakReference<Book> ref = new WeakReference<>(new Book("Garbage Collection Guide"));
        System.out.println("Before GC: " + ref.get());
        System.gc();
        System.out.println("After GC: " + ref.get());
    }
}
