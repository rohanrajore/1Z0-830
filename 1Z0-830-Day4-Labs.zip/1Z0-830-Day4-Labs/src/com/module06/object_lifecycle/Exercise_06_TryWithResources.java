package com.module06.object_lifecycle;

public class Exercise_06_TryWithResources {
    // TODO: Create custom AutoCloseable and use in try-with-resources

    static class MyResource implements AutoCloseable {
        MyResource() {
            System.out.println("Resource opened");
        }

        void use() {
            System.out.println("Using resource...");
        }

        @Override
        public void close() {
            System.out.println("Resource closed automatically");
        }
    }

    public static void main(String[] args) {
        try (MyResource r = new MyResource()) {
            r.use();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
