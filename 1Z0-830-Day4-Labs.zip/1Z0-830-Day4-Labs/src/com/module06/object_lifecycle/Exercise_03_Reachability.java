package com.module06.object_lifecycle;

public class Exercise_03_Reachability {
    // TODO: Create circular references and dereference them

    static class Node {
        Node next;
    }

    public static void main(String[] args) {
        Node a = new Node();
        Node b = new Node();
        a.next = b;
        b.next = a;

        System.out.println("Circular references created");
        a = null;
        b = null;
        System.out.println("Both objects are now unreachable and eligible for GC");
    }
}
