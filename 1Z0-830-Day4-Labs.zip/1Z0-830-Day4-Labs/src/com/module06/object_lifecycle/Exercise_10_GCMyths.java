package com.module06.object_lifecycle;

public class Exercise_10_GCMyths {
    // TODO: Demonstrate common GC misconceptions

    static class Dummy {
        Dummy() { System.out.println("Dummy created"); }
        @Override
        protected void finalize() {
            System.out.println("Finalize called (not guaranteed)");
        }
    }

    public static void main(String[] args) {
        Dummy d = new Dummy();
        d = null;
        System.out.println("Calling System.gc() does NOT guarantee immediate destruction.");
        System.gc();
        System.out.println("Program continues running after GC request.");
    }
}
