package com.module06.object_lifecycle;

public class Exercise_07_GCAlgorithms {
    // TODO: Research GC algorithm via JVM flag and note your results
    public static void main(String[] args) {
        System.out.println("Run this in terminal:");
        System.out.println("java -XX:+PrintCommandLineFlags -version");
        System.out.println("Note the GC algorithm used (e.g., G1GC, ParallelGC, ZGC)");
    }
}
