package com.module06.object_lifecycle;

public class Exercise_05_Finalize {
    // TODO: Observe finalize() execution after System.gc()

    static class Temp {
        @Override
        protected void finalize() {
            System.out.println("Finalize called before GC reclaims memory!");
        }
    }

    public static void main(String[] args) {
        Temp t = new Temp();
        t = null;
        System.out.println("Temp object made eligible for GC.");
        System.gc();
        System.out.println("Waiting to see if finalize() is triggered...");
    }
}
