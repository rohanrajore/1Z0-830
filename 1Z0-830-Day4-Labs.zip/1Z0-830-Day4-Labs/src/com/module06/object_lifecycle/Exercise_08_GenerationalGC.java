package com.module06.object_lifecycle;

public class Exercise_08_GenerationalGC {
    // TODO: Create many short-lived objects and monitor GC activity

    static class Temp {
        Temp() { System.out.println("Temp object created"); }
    }

    public static void main(String[] args) {
        for (int i = 0; i < 1000; i++) {
            new Temp();
        }
        System.out.println("Created 1000 short-lived objects. Observe via VisualVM or JConsole.");
    }
}
