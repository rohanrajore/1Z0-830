package com.module01.class_basics;

public class Exercise_09_ModifierCombinations {
    // TODO: Use private, protected, and public together in a class hierarchy

    static class Base {
        private int privateVal = 1;
        protected int protectedVal = 2;
        public int publicVal = 3;

        protected int getProtectedVal() { return protectedVal; }
    }

    static class Derived extends Base {
        void displayValues() {
            System.out.println("Protected: " + getProtectedVal());
            System.out.println("Public: " + publicVal);
        }
    }

    public static void main(String[] args) {
        Derived d = new Derived();
        d.displayValues();
    }
}
