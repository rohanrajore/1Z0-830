package com.module01.class_basics;

import java.time.LocalDateTime;

public class Exercise_10_NestedClass {
    // TODO: Create nested Logger class inside App that prints timestamped messages

    static class App {
        static class Logger {
            void log(String msg) {
                System.out.println(LocalDateTime.now() + " - " + msg);
            }
        }
    }

    public static void main(String[] args) {
        App.Logger logger = new App.Logger();
        logger.log("Application started");
    }
}
