package com.module01.class_basics;

public class Exercise_07_PrivateEncapsulation {
    // TODO: Make fields private and provide getters/setters

    static class Account {
        private double balance;

        public void deposit(double amount) { balance += amount; }
        public double getBalance() { return balance; }
    }

    public static void main(String[] args) {
        Account acc = new Account();
        acc.deposit(1000);
        System.out.println("Balance: " + acc.getBalance());
    }
}
