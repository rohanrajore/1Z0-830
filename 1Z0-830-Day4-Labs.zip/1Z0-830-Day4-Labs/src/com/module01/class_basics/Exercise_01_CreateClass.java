package com.module01.class_basics;

public class Exercise_01_CreateClass {
    // TODO: Create a class Book with fields title, author, and method displayDetails()

    static class Book {
        String title;
        String author;

        void displayDetails() {
            System.out.println("Title: " + title + ", Author: " + author);
        }
    }

    public static void main(String[] args) {
        Book book = new Book();
        book.title = "Java Fundamentals";
        book.author = "James Gosling";
        book.displayDetails();
    }
}
