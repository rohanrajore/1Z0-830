package com.module01.class_basics;

public class Exercise_08_ProtectedUsage {
    // TODO: Demonstrate protected usage in inheritance

    static class Shape {
        protected String color = "Red";
    }

    static class Circle extends Shape {
        void showColor() {
            System.out.println("Circle color: " + color);
        }
    }

    public static void main(String[] args) {
        Circle c = new Circle();
        c.showColor();
    }
}
