package com.module01.class_basics;

public class Exercise_05_StaticMethods {
    // TODO: Write a static method isEven() that checks if a number is even

    static class MathUtil {
        static boolean isEven(int n) {
            return n % 2 == 0;
        }
    }

    public static void main(String[] args) {
        System.out.println("4 is even? " + MathUtil.isEven(4));
        System.out.println("7 is even? " + MathUtil.isEven(7));
    }
}
