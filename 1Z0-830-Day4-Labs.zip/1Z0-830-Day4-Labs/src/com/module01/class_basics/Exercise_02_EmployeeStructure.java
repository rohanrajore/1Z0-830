package com.module01.class_basics;

public class Exercise_02_EmployeeStructure {
    // TODO: Create a Student class with constructor and showProfile() method

    static class Student {
        private String name;
        private char grade;

        public Student(String name, char grade) {
            this.name = name;
            this.grade = grade;
        }

        public void showProfile() {
            System.out.println("Student: " + name + ", Grade: " + grade);
        }
    }

    public static void main(String[] args) {
        Student s1 = new Student("Amit", 'A');
        s1.showProfile();
    }
}
