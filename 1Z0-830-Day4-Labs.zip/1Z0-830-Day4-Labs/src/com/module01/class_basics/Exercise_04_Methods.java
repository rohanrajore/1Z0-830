package com.module01.class_basics;

public class Exercise_04_Methods {
    // TODO: Create a MathOps class with add, subtract, multiply methods

    static class MathOps {
        int add(int a, int b) { return a + b; }
        int subtract(int a, int b) { return a - b; }
        int multiply(int a, int b) { return a * b; }
    }

    public static void main(String[] args) {
        MathOps ops = new MathOps();
        System.out.println("Add: " + ops.add(10, 5));
        System.out.println("Subtract: " + ops.subtract(10, 5));
        System.out.println("Multiply: " + ops.multiply(10, 5));
    }
}
