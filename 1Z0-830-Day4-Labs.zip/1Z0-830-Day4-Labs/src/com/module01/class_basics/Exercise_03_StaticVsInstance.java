package com.module01.class_basics;

public class Exercise_03_StaticVsInstance {
    // TODO: Create two Student objects and modify static field to observe shared behavior

    static class Student {
        String name;
        static String school = "Green Valley High";
    }

    public static void main(String[] args) {
        Student s1 = new Student();
        s1.name = "Riya";

        Student s2 = new Student();
        s2.name = "Karan";

        System.out.println(s1.name + " studies at " + Student.school);
        System.out.println(s2.name + " studies at " + Student.school);

        // Modify static field
        Student.school = "Blue Ridge Academy";

        System.out.println("After change:");
        System.out.println(s1.name + " studies at " + Student.school);
        System.out.println(s2.name + " studies at " + Student.school);
    }
}
