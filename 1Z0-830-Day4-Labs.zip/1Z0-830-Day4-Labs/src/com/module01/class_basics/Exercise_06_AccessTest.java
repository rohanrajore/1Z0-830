package com.module01.class_basics;

// TODO: Create classes in same and different packages to test access modifiers

public class Exercise_06_AccessTest {
    public static void main(String[] args) {
        SamePackage sp = new SamePackage();
        sp.showAccess();
    }
}

class SamePackage {
    public int pub = 1;
    protected int prot = 2;
    int def = 3;
    private int priv = 4;

    void showAccess() {
        System.out.println("Public: " + pub);
        System.out.println("Protected: " + prot);
        System.out.println("Default: " + def);
        System.out.println("Private: " + priv);
    }
}
