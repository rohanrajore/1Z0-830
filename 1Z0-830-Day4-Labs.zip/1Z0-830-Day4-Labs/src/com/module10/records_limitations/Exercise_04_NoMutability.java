package com.module10.records_limitations;

public class Exercise_04_NoMutability {
    // TODO: Try modifying record fields after creation

    record BankAccount(String name, double balance) {}

    static class MutableAccount {
        String name;
        double balance;
        void setBalance(double balance) { this.balance = balance; }
    }

    public static void main(String[] args) {
        BankAccount acc = new BankAccount("John", 1000);
        System.out.println(acc);

        MutableAccount m = new MutableAccount();
        m.name = "John";
        m.setBalance(2000);
        System.out.println("Mutable Account balance: " + m.balance);
    }
}