package com.module10.records_limitations;

import java.util.*;

public class Exercise_06_DeepCopy {
    // TODO: Implement deep copy constructor

    record Course(String title, List<String> topics) {
        public Course(Course other) {
            this(other.title(), new ArrayList<>(other.topics()));
        }
    }

    public static void main(String[] args) {
        Course c1 = new Course("CS101", List.of("Java", "OOP"));
        Course c2 = new Course(c1);
        System.out.println("c1 == c2: " + (c1 == c2));
        System.out.println("c1.equals(c2): " + c1.equals(c2));
    }
}