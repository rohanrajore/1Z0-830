package com.module10.records_limitations;

public class Exercise_01_RecordLimitations {
    // TODO: Try extending a record and adding mutable field to observe errors

    // Uncommenting below lines will cause compilation errors
    /*
    public record User(String name, int age) {}
    class Admin extends User {} // ❌ Cannot extend a record
    */

    public record User(String name, int age) {}

    public static void main(String[] args) {
        User u = new User("Asha", 30);
        System.out.println(u);
    }
}