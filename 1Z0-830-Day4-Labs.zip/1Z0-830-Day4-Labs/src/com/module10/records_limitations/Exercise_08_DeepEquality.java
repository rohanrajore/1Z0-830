package com.module10.records_limitations;

import java.util.*;

public class Exercise_08_DeepEquality {
    // TODO: Compare two records with identical nested content

    record Person(String name, List<String> hobbies) {}

    public static void main(String[] args) {
        Person p1 = new Person("Ravi", new ArrayList<>(List.of("Cricket")));
        Person p2 = new Person("Ravi", new ArrayList<>(List.of("Cricket")));

        System.out.println("p1.equals(p2): " + p1.equals(p2));
    }
}