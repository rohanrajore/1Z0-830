package com.module10.records_limitations;

public class Exercise_03_RecordInheritance {
    // TODO: Create sealed interface and implement using records

    sealed interface Shape permits Circle, Square {}

    record Circle(double radius) implements Shape {}
    record Square(double side) implements Shape {}

    public static void main(String[] args) {
        Shape s1 = new Circle(4);
        Shape s2 = new Square(5);
        System.out.println(s1);
        System.out.println(s2);
    }
}