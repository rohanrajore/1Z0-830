package com.module10.records_limitations;

public class Exercise_09_RecordVsClass {
    // TODO: Convert record to mutable class and compare

    record ImmutableUser(String name) {}

    static class MutableUser {
        String name;
        void setName(String name) { this.name = name; }
    }

    public static void main(String[] args) {
        ImmutableUser r = new ImmutableUser("Asha");
        MutableUser m = new MutableUser();
        m.setName("Asha");

        System.out.println("Immutable record: " + r);
        System.out.println("Mutable class name: " + m.name);
    }
}