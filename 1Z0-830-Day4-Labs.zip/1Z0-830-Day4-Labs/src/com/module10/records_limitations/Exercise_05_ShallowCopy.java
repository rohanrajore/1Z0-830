package com.module10.records_limitations;

import java.util.*;

public class Exercise_05_ShallowCopy {
    // TODO: Show shallow copy behavior

    record Course(String title, List<String> topics) {}

    public static void main(String[] args) {
        List<String> topics = new ArrayList<>(List.of("OOP", "Java"));
        Course c1 = new Course("CS101", topics);
        Course c2 = new Course(c1.title(), c1.topics());

        c1.topics().add("DSA");
        System.out.println("Original: " + c1.topics());
        System.out.println("Copied: " + c2.topics());
    }
}