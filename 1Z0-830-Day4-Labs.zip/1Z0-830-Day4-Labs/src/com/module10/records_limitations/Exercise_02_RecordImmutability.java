package com.module10.records_limitations;

import java.util.*;

public class Exercise_02_RecordImmutability {
    // TODO: Demonstrate shallow immutability and fix using defensive copy

    record StudentUnsafe(String name, List<String> subjects) {}

    record StudentSafe(String name, List<String> subjects) {
        public StudentSafe {
            subjects = List.copyOf(subjects);
        }
    }

    public static void main(String[] args) {
        List<String> subs = new ArrayList<>(List.of("Math", "CS"));
        StudentUnsafe s1 = new StudentUnsafe("Asha", subs);
        subs.add("Physics");
        System.out.println("Unsafe: " + s1.subjects());

        StudentSafe s2 = new StudentSafe("Asha", new ArrayList<>(List.of("Math", "CS")));
        System.out.println("Safe: " + s2.subjects());
    }
}