package com.module10.records_limitations;

import java.util.*;

public class Exercise_10_BestPractices {
    // TODO: Add defensive copy for immutable design

    record Library(String name, List<String> books) {
        public Library {
            books = List.copyOf(books);
        }
    }

    public static void main(String[] args) {
        List<String> list = new ArrayList<>(List.of("Book A", "Book B"));
        Library lib = new Library("Central", list);
        list.add("Book C");
        System.out.println(lib);
    }
}