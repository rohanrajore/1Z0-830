package com.module10.records_limitations;

public class Exercise_07_RecordEquality {
    // TODO: Compare two identical records using == and equals()

    record Point(int x, int y) {}

    public static void main(String[] args) {
        Point p1 = new Point(1, 2);
        Point p2 = new Point(1, 2);

        System.out.println("p1.equals(p2): " + p1.equals(p2));
        System.out.println("p1 == p2: " + (p1 == p2));
    }
}