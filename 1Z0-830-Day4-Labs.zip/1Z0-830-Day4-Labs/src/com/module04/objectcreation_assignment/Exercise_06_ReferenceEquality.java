package com.module04.objectcreation_assignment;

public class Exercise_06_ReferenceEquality {
    // TODO: Compare references with == and .equals()

    static class Student {
        String name;
        Student(String name) { this.name = name; }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Student)) return false;
            Student other = (Student) o;
            return name.equals(other.name);
        }
    }

    public static void main(String[] args) {
        Student s1 = new Student("Alice");
        Student s2 = new Student("Alice");

        System.out.println("Using == : " + (s1 == s2));
        System.out.println("Using .equals() : " + s1.equals(s2));
    }
}
