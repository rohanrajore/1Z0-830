package com.module04.objectcreation_assignment;

public class Exercise_03_ReferenceSharing {
    // TODO: Create Employee object, share references, and modify fields

    static class Employee {
        String name;
        Employee(String name) { this.name = name; }
    }

    public static void main(String[] args) {
        Employee e1 = new Employee("Alice");
        Employee e2 = e1; // both refer to same object

        e2.name = "Bob"; // change through e2

        System.out.println("e1 name: " + e1.name);
        System.out.println("e2 name: " + e2.name);
    }
}
