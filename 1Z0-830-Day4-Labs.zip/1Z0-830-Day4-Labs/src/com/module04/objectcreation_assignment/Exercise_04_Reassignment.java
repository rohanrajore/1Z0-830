package com.module04.objectcreation_assignment;

public class Exercise_04_Reassignment {
    // TODO: Reassign same reference to multiple objects and observe

    static class Book {
        Book(String title) {
            System.out.println("Book created: " + title);
        }
    }

    public static void main(String[] args) {
        Book b = new Book("Java");
        b = new Book("Python");
        b = new Book("C++");
        System.out.println("Final reference now points to last created object.");
    }
}
