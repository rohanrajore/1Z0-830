package com.module04.objectcreation_assignment;

public class Exercise_02_ObjectLifecycle {
    // TODO: Add print statements to show object lifecycle

    static class Student {
        String name = "Unknown";
        Student() {
            System.out.println("Constructor called");
        }
    }

    public static void main(String[] args) {
        Student s = new Student();
        System.out.println("Student created with name: " + s.name);
    }
}
