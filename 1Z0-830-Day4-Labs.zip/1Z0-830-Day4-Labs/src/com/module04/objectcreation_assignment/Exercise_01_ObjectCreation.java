package com.module04.objectcreation_assignment;

public class Exercise_01_ObjectCreation {
    // TODO: Create Book class and make two references point to same object

    static class Book {
        String title;
        Book(String title) { this.title = title; }
    }

    public static void main(String[] args) {
        Book b1 = new Book("Java in Depth");
        Book b2 = b1; // same reference
        System.out.println("Are b1 and b2 same? " + (b1 == b2));
    }
}
