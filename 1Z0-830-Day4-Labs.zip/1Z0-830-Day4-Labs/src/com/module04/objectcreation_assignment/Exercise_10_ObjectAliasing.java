package com.module04.objectcreation_assignment;

public class Exercise_10_ObjectAliasing {
    // TODO: Demonstrate aliasing and cloning/copy fix

    static class Person implements Cloneable {
        String name;
        Person(String name) { this.name = name; }

        @Override
        protected Object clone() throws CloneNotSupportedException {
            return super.clone();
        }
    }

    public static void main(String[] args) throws CloneNotSupportedException {
        Person p1 = new Person("Alice");
        Person p2 = p1; // aliasing
        p2.name = "Bob";

        System.out.println("p1.name: " + p1.name);
        System.out.println("p2.name: " + p2.name);

        // Fix with clone
        Person p3 = (Person) p1.clone();
        p3.name = "Charlie";
        System.out.println("After clone - p1: " + p1.name + ", p3: " + p3.name);
    }
}
