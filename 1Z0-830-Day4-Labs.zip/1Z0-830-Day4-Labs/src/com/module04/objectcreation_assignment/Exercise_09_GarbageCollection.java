package com.module04.objectcreation_assignment;

public class Exercise_09_GarbageCollection {
    // TODO: Demonstrate garbage collection and finalize()

    static class Book {
        String title;
        Book(String title) { this.title = title; }

        @Override
        protected void finalize() {
            System.out.println("Book destroyed: " + title);
        }
    }

    public static void main(String[] args) {
        for (int i = 1; i <= 3; i++) {
            Book b = new Book("Book" + i);
            b = null;
        }
        System.gc(); // suggest GC
    }
}
