package com.module04.objectcreation_assignment;

public class Exercise_11_BestPractices {
    // TODO: Demonstrate bad and corrected reference handling practices

    static class User {
        String name;
        User(String name) { this.name = name; }
    }

    public static void main(String[] args) {
        // ❌ Bad: Using null reference without check
        User u = null;
        // System.out.println(u.name); // would cause NullPointerException

        // ✅ Corrected
        if (u != null) {
            System.out.println(u.name);
        } else {
            System.out.println("User reference not initialized.");
        }

        // ✅ Example of equals() instead of == for content
        String s1 = new String("Java");
        String s2 = new String("Java");
        System.out.println("== comparison: " + (s1 == s2));
        System.out.println(".equals() comparison: " + s1.equals(s2));
    }
}
