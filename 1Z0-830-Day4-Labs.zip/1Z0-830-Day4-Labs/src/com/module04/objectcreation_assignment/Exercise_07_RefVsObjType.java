package com.module04.objectcreation_assignment;

public class Exercise_07_RefVsObjType {
    // TODO: Demonstrate difference between reference type and object type

    static class Shape {
        void draw() { System.out.println("Drawing shape"); }
    }

    static class Circle extends Shape {
        @Override
        void draw() { System.out.println("Drawing circle"); }
    }

    public static void main(String[] args) {
        Shape s = new Circle();
        s.draw(); // runtime polymorphism
    }
}
