package com.module04.objectcreation_assignment;

public class Exercise_08_AnonymousObject {
    // TODO: Create anonymous object

    static class Temp {
        Temp() {
            System.out.println("Temporary object used!");
        }
    }

    public static void main(String[] args) {
        new Temp(); // anonymous object
    }
}
