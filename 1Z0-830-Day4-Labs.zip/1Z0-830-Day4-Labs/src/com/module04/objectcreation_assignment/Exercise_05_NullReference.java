package com.module04.objectcreation_assignment;

public class Exercise_05_NullReference {
    // TODO: Demonstrate null reference and safe access

    static class Car {
        String brand = "Tesla";
    }

    public static void main(String[] args) {
        Car c = null;

        if (c != null) {
            System.out.println(c.brand);
        } else {
            System.out.println("Car reference is null, skipping access.");
        }
    }
}
