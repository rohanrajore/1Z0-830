package com.module05.variable_scope;

class A {
    static int x = 5;
    void show() { System.out.println("A's show"); }
}

class B extends A {
    static int x = 10; // hiding
    @Override
    void show() { System.out.println("B's show"); } // overriding
}

public class Exercise_10_CompareShadowHideOverride {
    // TODO: Compare shadowing, hiding, and overriding
    public static void main(String[] args) {
        int x = 15; // shadowing
        System.out.println("Local x = " + x);
        System.out.println("Static hiding: A.x=" + A.x + ", B.x=" + B.x);
        A ref = new B();
        ref.show(); // overridden version from B
    }
}
