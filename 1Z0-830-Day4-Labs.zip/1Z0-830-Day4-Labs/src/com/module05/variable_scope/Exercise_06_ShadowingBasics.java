package com.module05.variable_scope;

public class Exercise_06_ShadowingBasics {
    // TODO: Demonstrate local variable shadowing instance variable
    int x = 10;

    void show() {
        int x = 20; // shadows instance variable
        System.out.println("Local x = " + x);
        System.out.println("Instance x = " + this.x);
    }

    public static void main(String[] args) {
        new Exercise_06_ShadowingBasics().show();
    }
}
