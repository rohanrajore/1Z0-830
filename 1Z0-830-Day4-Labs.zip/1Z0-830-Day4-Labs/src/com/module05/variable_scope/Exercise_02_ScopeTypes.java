package com.module05.variable_scope;

public class Exercise_02_ScopeTypes {
    // TODO: Create a class with static, instance, and local variables
    static int globalCount = 0; // static variable
    int id;                     // instance variable
    
    void increment() {
        int temp = 1; // local variable
        id += temp;
        globalCount++;
        System.out.println("ID: " + id + ", GlobalCount: " + globalCount);
    }

    public static void main(String[] args) {
        Exercise_02_ScopeTypes obj1 = new Exercise_02_ScopeTypes();
        Exercise_02_ScopeTypes obj2 = new Exercise_02_ScopeTypes();
        obj1.increment();
        obj2.increment();
    }
}
