package com.module05.variable_scope;

public class Exercise_04_InstanceStaticScope {
    // TODO: Show difference between static and instance fields
    static int totalAccounts;
    double balance;

    Exercise_04_InstanceStaticScope(double balance) {
        this.balance = balance;
        totalAccounts++;
    }

    void display() {
        System.out.println("Balance: " + balance + ", TotalAccounts: " + totalAccounts);
    }

    public static void main(String[] args) {
        Exercise_04_InstanceStaticScope a1 = new Exercise_04_InstanceStaticScope(5000);
        Exercise_04_InstanceStaticScope a2 = new Exercise_04_InstanceStaticScope(8000);
        a1.display();
        a2.display();
    }
}
