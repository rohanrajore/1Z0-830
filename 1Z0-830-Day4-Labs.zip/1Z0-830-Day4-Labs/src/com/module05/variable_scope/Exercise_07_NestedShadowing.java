package com.module05.variable_scope;

public class Exercise_07_NestedShadowing {
    // TODO: Demonstrate shadowing in nested blocks
    public static void main(String[] args) {
        int num = 5;
        System.out.println("Outer num = " + num);
        {
            int numInner = 10; // shadow outer 'num' manually
            System.out.println("Inner num = " + numInner);
        }
        System.out.println("Outer num again = " + num);
    }
}
