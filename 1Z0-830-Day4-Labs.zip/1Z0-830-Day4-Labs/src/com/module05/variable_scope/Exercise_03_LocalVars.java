package com.module05.variable_scope;

public class Exercise_03_LocalVars {
    // TODO: Print local variable before initialization and observe compiler error
    void test() {
        int a;
        // System.out.println(a); // ❌ Uncomment to see compiler error: variable a might not have been initialized
        a = 5;
        System.out.println("Initialized local variable a = " + a);
    }

    public static void main(String[] args) {
        new Exercise_03_LocalVars().test();
    }
}
