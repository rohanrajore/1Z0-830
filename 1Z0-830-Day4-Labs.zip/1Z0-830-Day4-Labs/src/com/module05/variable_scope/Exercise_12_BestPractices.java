package com.module05.variable_scope;

public class Exercise_12_BestPractices {
    // TODO: Refactor messy variable usage for clarity
    static class Employee {
        private String name;
        private int id;

        Employee(String name, int id) {
            this.name = name;
            this.id = id;
        }

        void display() {
            System.out.println("Employee Name: " + name + ", ID: " + id);
        }
    }

    public static void main(String[] args) {
        Employee e = new Employee("John", 101);
        e.display();
    }
}
