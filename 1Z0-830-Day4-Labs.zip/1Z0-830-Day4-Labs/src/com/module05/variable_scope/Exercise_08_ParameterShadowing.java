package com.module05.variable_scope;

public class Exercise_08_ParameterShadowing {
    // TODO: Demonstrate parameter shadowing in constructor
    String name;

    Exercise_08_ParameterShadowing(String name) {
        // name = name; // ❌ Wrong: shadows field
        this.name = name; // ✅ Correct: assigns parameter to field
    }

    public static void main(String[] args) {
        Exercise_08_ParameterShadowing s = new Exercise_08_ParameterShadowing("Alice");
        System.out.println("Student name: " + s.name);
    }
}
