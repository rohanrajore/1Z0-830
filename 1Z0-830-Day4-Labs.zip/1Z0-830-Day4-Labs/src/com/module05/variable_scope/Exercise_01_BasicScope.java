package com.module05.variable_scope;

public class Exercise_01_BasicScope {
    // TODO: Demonstrate variable visibility in nested blocks
    public static void main(String[] args) {
        int outer = 10;
        System.out.println("Outer variable: " + outer);
        
        if (true) {
            int inner = 20;
            System.out.println("Outer + Inner: " + (outer + inner));
        }
        // Uncommenting below line will cause error: inner not in scope
        // System.out.println(inner);
    }
}
