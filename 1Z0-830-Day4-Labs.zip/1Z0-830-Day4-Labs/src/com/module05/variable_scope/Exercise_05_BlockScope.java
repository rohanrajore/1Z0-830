package com.module05.variable_scope;

public class Exercise_05_BlockScope {
    // TODO: Demonstrate block scope using nested loops
    public static void main(String[] args) {
        for (int i = 1; i <= 2; i++) {
            for (int j = 1; j <= 2; j++) {
                System.out.println("i=" + i + ", j=" + j);
            }
            // System.out.println(j); // ❌ j not in scope here
        }
        // System.out.println(i); // ❌ i not in scope here
    }
}
