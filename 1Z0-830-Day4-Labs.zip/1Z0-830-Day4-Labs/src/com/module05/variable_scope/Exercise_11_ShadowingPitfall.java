package com.module05.variable_scope;

public class Exercise_11_ShadowingPitfall {
    // TODO: Fix shadowing issue in constructor

    static class Account {
        double balance;
        Account(double balance) {
            // balance = balance; // ❌ shadowed, doesn’t assign
            this.balance = balance; // ✅ correct fix
        }
    }

    public static void main(String[] args) {
        Account a = new Account(1000);
        System.out.println("Account balance: " + a.balance);
    }
}
