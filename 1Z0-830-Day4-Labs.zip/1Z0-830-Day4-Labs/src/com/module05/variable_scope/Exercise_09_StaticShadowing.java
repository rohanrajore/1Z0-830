package com.module05.variable_scope;

class Parent {
    static int val = 5;
}
class Child extends Parent {
    static int val = 10;
}

public class Exercise_09_StaticShadowing {
    // TODO: Demonstrate static field shadowing between superclass and subclass
    public static void main(String[] args) {
        Parent p = new Child();
        System.out.println("Access via Parent ref: " + p.val); // 5
        System.out.println("Access via Child class: " + Child.val); // 10
    }
}
