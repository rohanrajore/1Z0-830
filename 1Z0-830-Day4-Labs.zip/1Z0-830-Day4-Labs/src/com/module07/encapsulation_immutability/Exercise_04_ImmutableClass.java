package com.module07.encapsulation_immutability;

public final class Exercise_04_ImmutableClass {
    // TODO: Create immutable Point class with final fields

    private final int x;
    private final int y;

    public Exercise_04_ImmutableClass(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() { return x; }
    public int getY() { return y; }

    public static void main(String[] args) {
        Exercise_04_ImmutableClass p = new Exercise_04_ImmutableClass(10, 20);
        System.out.println("Point: (" + p.getX() + ", " + p.getY() + ")");
    }
}
