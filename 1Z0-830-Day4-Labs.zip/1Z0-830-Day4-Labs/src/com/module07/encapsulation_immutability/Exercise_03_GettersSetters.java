package com.module07.encapsulation_immutability;

public class Exercise_03_GettersSetters {
    // TODO: Add validation for name in setter

    static class Person {
        private String name;

        public void setName(String name) {
            if (name == null || name.isBlank()) {
                throw new IllegalArgumentException("Name cannot be null or blank");
            }
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }

    public static void main(String[] args) {
        Person p = new Person();
        p.setName("John");
        System.out.println("Name: " + p.getName());
    }
}
