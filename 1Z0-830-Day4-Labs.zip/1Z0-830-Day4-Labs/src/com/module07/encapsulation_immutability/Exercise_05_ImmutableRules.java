package com.module07.encapsulation_immutability;

import java.util.Date;

public final class Exercise_05_ImmutableRules {
    // TODO: Implement immutable Employee with defensive copy for Date

    private final String name;
    private final double salary;
    private final Date hireDate;

    public Exercise_05_ImmutableRules(String name, double salary, Date hireDate) {
        this.name = name;
        this.salary = salary;
        this.hireDate = new Date(hireDate.getTime()); // defensive copy
    }

    public String getName() { return name; }
    public double getSalary() { return salary; }

    public Date getHireDate() {
        return new Date(hireDate.getTime()); // defensive copy
    }

    public static void main(String[] args) {
        Date d = new Date();
        Exercise_05_ImmutableRules emp = new Exercise_05_ImmutableRules("Alice", 80000, d);
        System.out.println(emp.getName() + " - " + emp.getHireDate());
    }
}
