package com.module07.encapsulation_immutability;

public class Exercise_01_EncapsulationBasics {
    // TODO: Create a Student class with private fields and public getters/setters

    static class Student {
        private String name;
        private char grade;

        public String getName() { return name; }

        public void setName(String name) {
            if (name != null && !name.isBlank())
                this.name = name;
            else
                System.out.println("Invalid name");
        }

        public char getGrade() { return grade; }

        public void setGrade(char grade) {
            if (grade >= 'A' && grade <= 'F')
                this.grade = grade;
            else
                System.out.println("Invalid grade");
        }
    }

    public static void main(String[] args) {
        Student s = new Student();
        s.setName("Alice");
        s.setGrade('A');
        System.out.println(s.getName() + " has grade " + s.getGrade());
    }
}
