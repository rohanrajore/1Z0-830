package com.module07.encapsulation_immutability;

public class Exercise_09_ImmutableBehavior {
    // TODO: Demonstrate String immutability

    public static void main(String[] args) {
        String s1 = "Java";
        String s2 = s1.concat("21");

        System.out.println("s1: " + s1);
        System.out.println("s2: " + s2);
    }
}
