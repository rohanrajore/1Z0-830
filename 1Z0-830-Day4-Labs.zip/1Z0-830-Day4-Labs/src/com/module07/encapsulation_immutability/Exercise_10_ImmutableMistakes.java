package com.module07.encapsulation_immutability;

import java.util.Date;

public final class Exercise_10_ImmutableMistakes {
    // TODO: Show immutability mistake and fix it

    private final Date joinDate;

    public Exercise_10_ImmutableMistakes(Date joinDate) {
        this.joinDate = new Date(joinDate.getTime());
    }

    public Date getJoinDate() {
        return new Date(joinDate.getTime()); // fixed defensive copy
    }

    public static void main(String[] args) {
        Date d = new Date();
        Exercise_10_ImmutableMistakes e = new Exercise_10_ImmutableMistakes(d);
        System.out.println("Join date: " + e.getJoinDate());
        d.setTime(0);
        System.out.println("After external change: " + e.getJoinDate());
    }
}
