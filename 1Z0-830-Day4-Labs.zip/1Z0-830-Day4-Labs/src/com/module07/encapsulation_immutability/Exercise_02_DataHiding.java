package com.module07.encapsulation_immutability;

public class Exercise_02_DataHiding {
    // TODO: Refactor a class with public fields to private + validation setters

    static class Account {
        private double balance;

        public void setBalance(double amount) {
            if (amount >= 0)
                this.balance = amount;
            else
                System.out.println("Invalid balance amount");
        }

        public double getBalance() { return balance; }
    }

    public static void main(String[] args) {
        Account acc = new Account();
        acc.setBalance(500);
        System.out.println("Balance: " + acc.getBalance());
    }
}
