package com.module07.encapsulation_immutability;

// TODO: Rewrite Coordinate as record and compare simplicity

public record Exercise_11_RecordImmutable(int x, int y) {
    public static void main(String[] args) {
        Exercise_11_RecordImmutable point = new Exercise_11_RecordImmutable(10, 20);
        System.out.println("Record Point: (" + point.x() + ", " + point.y() + ")");
    }
}
