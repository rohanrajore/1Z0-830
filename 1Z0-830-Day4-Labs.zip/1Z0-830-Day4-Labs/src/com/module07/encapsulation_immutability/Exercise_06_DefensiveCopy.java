package com.module07.encapsulation_immutability;

import java.util.Date;

public class Exercise_06_DefensiveCopy {
    // TODO: Show mutation problem and fix with defensive copy

    static class User {
        private Date created;

        User(Date created) {
            this.created = new Date(created.getTime()); // defensive copy
        }

        public Date getCreated() {
            return new Date(created.getTime());
        }
    }

    public static void main(String[] args) {
        Date now = new Date();
        User u = new User(now);

        System.out.println("Before change: " + u.getCreated());
        now.setTime(0); // try to mutate original date
        System.out.println("After external change: " + u.getCreated());
    }
}
