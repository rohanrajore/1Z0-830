package com.module07.encapsulation_immutability;

public class Exercise_08_EncapVsImmutable {
    // TODO: Compare encapsulated vs immutable class

    static class MutablePerson {
        private String name;

        public void setName(String name) { this.name = name; }
        public String getName() { return name; }
    }

    static final class ImmutablePerson {
        private final String name;

        ImmutablePerson(String name) { this.name = name; }
        public String getName() { return name; }
    }

    public static void main(String[] args) {
        MutablePerson m = new MutablePerson();
        m.setName("John");
        m.setName("Doe");
        System.out.println("Mutable: " + m.getName());

        ImmutablePerson i = new ImmutablePerson("Alice");
        System.out.println("Immutable: " + i.getName());
    }
}
