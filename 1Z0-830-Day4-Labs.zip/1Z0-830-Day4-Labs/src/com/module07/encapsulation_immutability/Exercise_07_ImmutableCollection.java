package com.module07.encapsulation_immutability;

import java.util.*;

public class Exercise_07_ImmutableCollection {
    // TODO: Create Team class with unmodifiable list

    static class Team {
        private final List<String> players;

        Team(List<String> players) {
            this.players = List.copyOf(players); // immutable copy
        }

        public List<String> getPlayers() {
            return List.copyOf(players);
        }
    }

    public static void main(String[] args) {
        List<String> p = new ArrayList<>(List.of("Alice", "Bob"));
        Team t = new Team(p);
        System.out.println("Players: " + t.getPlayers());

        // p.add("Charlie"); // external change won't affect Team
        // t.getPlayers().add("Dan"); // throws UnsupportedOperationException
    }
}
