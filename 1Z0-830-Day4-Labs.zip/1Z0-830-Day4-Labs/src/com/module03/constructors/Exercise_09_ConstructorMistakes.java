package com.module03.constructors;

public class Exercise_09_ConstructorMistakes {
    // TODO: Intentionally create constructor with return type and fix it

    static class Demo {
        // ❌ Wrong: Has a return type → becomes a method, not a constructor
        // void Demo() {
        //     System.out.println("This is not a constructor");
        // }

        // ✅ Correct: No return type
        Demo() {
            System.out.println("This is a valid constructor");
        }
    }

    public static void main(String[] args) {
        new Demo();
    }
}
