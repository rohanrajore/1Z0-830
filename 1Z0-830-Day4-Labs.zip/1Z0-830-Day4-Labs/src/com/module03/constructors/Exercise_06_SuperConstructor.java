package com.module03.constructors;

public class Exercise_06_SuperConstructor {
    // TODO: Use super() to call parent class constructor

    static class Person {
        Person() {
            System.out.println("Person created");
        }
    }

    static class Teacher extends Person {
        Teacher() {
            super(); // Calls parent constructor
            System.out.println("Teacher created");
        }
    }

    public static void main(String[] args) {
        new Teacher();
    }
}
