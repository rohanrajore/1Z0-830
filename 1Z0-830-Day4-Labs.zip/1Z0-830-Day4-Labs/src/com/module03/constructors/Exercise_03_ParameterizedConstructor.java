package com.module03.constructors;

public class Exercise_03_ParameterizedConstructor {
    // TODO: Create Car class with parameterized constructor

    static class Car {
        String brand;
        double price;

        Car(String brand, double price) {
            this.brand = brand;
            this.price = price;
        }

        void display() {
            System.out.println("Car brand: " + brand + ", Price: " + price);
        }
    }

    public static void main(String[] args) {
        Car c1 = new Car("Tesla", 55000);
        Car c2 = new Car("Toyota", 25000);
        c1.display();
        c2.display();
    }
}
