package com.module03.constructors;

public class Exercise_07_InitOrderConstructor {
    // TODO: Observe initialization order (static → instance → constructor)

    static class Demo {
        static { System.out.println("Static block"); }
        { System.out.println("Instance block"); }
        Demo() { System.out.println("Constructor"); }
    }

    public static void main(String[] args) {
        new Demo();
        new Demo();
    }
}
