package com.module03.constructors;

public class Exercise_02_DefaultConstructor {
    // TODO: Experiment with default constructor behavior

    static class Student {
        String name;
        int age;
        // Try commenting/uncommenting this constructor to observe behavior
        // Student() {
        //     System.out.println("Custom constructor defined");
        // }
    }

    public static void main(String[] args) {
        Student s = new Student();
        System.out.println("Name: " + s.name); // Default null
        System.out.println("Age: " + s.age);   // Default 0
    }
}
