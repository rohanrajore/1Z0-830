package com.module03.constructors;

public class Exercise_01_SimpleConstructor {
    // TODO: Create a class Book that prints “Book created” when a new object is created

    static class Book {
        Book() {
            System.out.println("Book created");
        }
    }

    public static void main(String[] args) {
        new Book();
        new Book();
    }
}
