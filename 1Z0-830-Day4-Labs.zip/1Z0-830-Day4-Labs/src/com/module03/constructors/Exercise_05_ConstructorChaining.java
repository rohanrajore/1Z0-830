package com.module03.constructors;

public class Exercise_05_ConstructorChaining {
    // TODO: Demonstrate constructor chaining using this()

    static class Laptop {
        String brand;
        double price;

        Laptop() {
            this("Unknown", 0.0);
        }

        Laptop(String brand, double price) {
            this.brand = brand;
            this.price = price;
            System.out.println("Laptop created: " + brand + " - " + price);
        }
    }

    public static void main(String[] args) {
        new Laptop();
        new Laptop("Dell", 75000);
    }
}
