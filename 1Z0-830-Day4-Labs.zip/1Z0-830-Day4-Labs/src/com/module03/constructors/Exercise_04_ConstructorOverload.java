package com.module03.constructors;

public class Exercise_04_ConstructorOverload {
    // TODO: Create Employee class with overloaded constructors

    static class Employee {
        String name;
        double salary;

        Employee() {
            name = "Unknown";
            salary = 0.0;
        }

        Employee(String name) {
            this.name = name;
            salary = 0.0;
        }

        Employee(String name, double salary) {
            this.name = name;
            this.salary = salary;
        }

        void show() {
            System.out.println("Employee: " + name + ", Salary: " + salary);
        }
    }

    public static void main(String[] args) {
        Employee e1 = new Employee();
        Employee e2 = new Employee("Alice");
        Employee e3 = new Employee("Bob", 60000);
        e1.show();
        e2.show();
        e3.show();
    }
}
