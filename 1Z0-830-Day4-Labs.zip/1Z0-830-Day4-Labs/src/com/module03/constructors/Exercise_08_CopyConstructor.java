package com.module03.constructors;

public class Exercise_08_CopyConstructor {
    // TODO: Create Book class with copy constructor

    static class Book {
        String title;
        String author;

        Book(String title, String author) {
            this.title = title;
            this.author = author;
        }

        // Copy constructor
        Book(Book other) {
            this.title = other.title;
            this.author = other.author;
        }

        void display() {
            System.out.println("Book: " + title + " by " + author);
        }
    }

    public static void main(String[] args) {
        Book b1 = new Book("Clean Code", "Robert C. Martin");
        Book b2 = new Book(b1);
        b1.display();
        b2.display();
    }
}
