package com.module03.constructors;

public class Exercise_10_ConstructorBestPractices {
    // TODO: Add validation in constructor and throw exception for invalid input

    static class Person {
        String name;
        int age;

        Person(String name, int age) {
            if (age < 0) {
                throw new IllegalArgumentException("Age cannot be negative");
            }
            this.name = name;
            this.age = age;
            System.out.println("Person created: " + name + ", Age: " + age);
        }
    }

    public static void main(String[] args) {
        try {
            new Person("Alice", 25);
            new Person("Bob", -5); // Will throw exception
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
