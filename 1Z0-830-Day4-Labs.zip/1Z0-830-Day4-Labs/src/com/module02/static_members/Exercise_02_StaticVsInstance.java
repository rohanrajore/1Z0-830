package com.module02.static_members;

public class Exercise_02_StaticVsInstance {
    // TODO: Demonstrate static vs instance fields using Car class

    static class Car {
        static String brand = "Toyota";
        String model;

        Car(String model) {
            this.model = model;
        }

        void show() {
            System.out.println("Brand: " + brand + ", Model: " + model);
        }
    }

    public static void main(String[] args) {
        Car c1 = new Car("Camry");
        Car c2 = new Car("Corolla");

        c1.show();
        c2.show();

        // Change static field via one object (not recommended)
        c1.brand = "Honda";

        System.out.println("After brand change:");
        c1.show();
        c2.show();
    }
}
