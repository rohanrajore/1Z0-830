package com.module02.static_members;

public class Exercise_04_StaticBlock {
    // TODO: Observe when static block executes relative to constructor calls

    static class Config {
        static String ENV;
        static {
            ENV = System.getenv("APP_ENV") != null ? "PROD" : "DEV";
            System.out.println("Static block executed: " + ENV);
        }

        Config() {
            System.out.println("Constructor executed");
        }
    }

    public static void main(String[] args) {
        new Config();
        new Config();
    }
}
