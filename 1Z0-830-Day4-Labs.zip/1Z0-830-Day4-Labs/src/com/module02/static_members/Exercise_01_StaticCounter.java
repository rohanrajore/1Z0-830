package com.module02.static_members;

public class Exercise_01_StaticCounter {
    // TODO: Create a Student class with static totalStudents counter that increments in the constructor

    static class Student {
        static int totalStudents = 0;
        String name;

        Student(String name) {
            this.name = name;
            totalStudents++;
        }
    }

    public static void main(String[] args) {
        new Student("Amit");
        new Student("Riya");
        new Student("Karan");

        System.out.println("Total students: " + Student.totalStudents);
    }
}
