package com.module02.static_members;

public class Exercise_10_StaticMistakes {
    // TODO: Access static variable via object, observe and fix compiler warnings

    static class Counter {
        static int count = 0;
        void increment() { count++; }
    }

    public static void main(String[] args) {
        Counter c1 = new Counter();
        Counter c2 = new Counter();

        // Incorrect way
        c1.count++;
        System.out.println("Count via object (not recommended): " + c1.count);

        // Correct way
        Counter.count++;
        System.out.println("Count via class (recommended): " + Counter.count);
    }
}
