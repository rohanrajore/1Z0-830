package com.module02.static_members;

public class Exercise_07_FieldInitOrder {
    // TODO: Observe order of field initialization

    static class InitOrder {
        int a = 10;
        int b = a + 5;

        InitOrder() {
            System.out.println("a=" + a + ", b=" + b);
        }
    }

    public static void main(String[] args) {
        new InitOrder();
    }
}
