package com.module02.static_members;

public class Exercise_06_InitializationOrder {
    // TODO: Show static, instance, and constructor execution order

    static class Demo {
        static { System.out.println("1. Static block"); }
        { System.out.println("2. Instance block"); }
        Demo() { System.out.println("3. Constructor"); }
    }

    public static void main(String[] args) {
        new Demo();
        new Demo();
    }
}
