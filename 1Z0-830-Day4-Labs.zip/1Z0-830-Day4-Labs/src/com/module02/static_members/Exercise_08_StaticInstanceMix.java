package com.module02.static_members;

public class Exercise_08_StaticInstanceMix {
    // TODO: Demonstrate static, instance, and constructor sequence

    static class Combo {
        static { System.out.println("Static init"); }
        { System.out.println("Instance init"); }
        Combo() { System.out.println("Constructor"); }
    }

    public static void main(String[] args) {
        new Combo();
        new Combo();
    }
}
