package com.module02.static_members;

public class Exercise_05_InstanceBlock {
    // TODO: Create a class with instance block and constructor; print order of execution

    static class User {
        {
            System.out.println("Instance block: setting defaults");
        }

        User() {
            System.out.println("Constructor: setting up user");
        }
    }

    public static void main(String[] args) {
        new User();
        new User();
    }
}
