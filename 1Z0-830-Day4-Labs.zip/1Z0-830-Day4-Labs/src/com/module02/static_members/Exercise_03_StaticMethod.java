package com.module02.static_members;

public class Exercise_03_StaticMethod {
    // TODO: Create Converter class with static methods to convert between miles and km

    static class Converter {
        static double toKm(double miles) {
            return miles * 1.60934;
        }

        static double toMiles(double km) {
            return km / 1.60934;
        }
    }

    public static void main(String[] args) {
        System.out.println("10 miles = " + Converter.toKm(10) + " km");
        System.out.println("16 km = " + Converter.toMiles(16) + " miles");
    }
}
