package com.module02.static_members;

import java.time.LocalDateTime;

public class Exercise_09_StaticNested {
    // TODO: Create static nested Logger class inside App

    static class App {
        static class Logger {
            static void log(String msg) {
                System.out.println(LocalDateTime.now() + " - " + msg);
            }
        }
    }

    public static void main(String[] args) {
        App.Logger.log("Application started");
    }
}
