package com.module09.records_java21;

public class Exercise_04_CompactConstructor {
    // TODO: Create a Student record with compact constructor validation

    public record Student(String name, int marks) {
        public Student {
            if (marks < 0 || marks > 100) {
                throw new IllegalArgumentException("Marks must be between 0 and 100");
            }
        }
    }

    public static void main(String[] args) {
        Student s = new Student("Ravi", 90);
        System.out.println(s);
    }
}
