package com.module09.records_java21;

public class Exercise_07_StaticMembers {
    // TODO: Add static field and static factory method

    public record Country(String name) {
        public static final Country INDIA = new Country("India");

        public static Country of(String name) {
            return new Country(name.toUpperCase());
        }
    }

    public static void main(String[] args) {
        System.out.println(Country.INDIA);
        System.out.println(Country.of("japan"));
    }
}
