package com.module09.records_java21;

public class Exercise_09_SealedRecord {
    // TODO: Create a sealed interface and implement records

    sealed interface Shape permits Square, Circle {}

    record Square(double side) implements Shape {}
    record Circle(double radius) implements Shape {}

    public static void main(String[] args) {
        Shape s1 = new Square(4);
        Shape s2 = new Circle(3);

        System.out.println(s1);
        System.out.println(s2);
    }
}
