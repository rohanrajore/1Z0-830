package com.module09.records_java21;

public class Exercise_06_RecordMethods {
    // TODO: Add custom method to compute area

    public record Circle(double radius) {
        public double area() {
            return Math.PI * radius * radius;
        }
    }

    public static void main(String[] args) {
        Circle c = new Circle(5);
        System.out.println("Area: " + c.area());
    }
}
