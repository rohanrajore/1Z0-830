package com.module09.records_java21;

public class Exercise_01_RecordBasics {
    // TODO: Define a simple Book record and test equals() and toString()

    public record Book(String title, String author, double price) {}

    public static void main(String[] args) {
        Book b1 = new Book("Java 21", "James", 599.0);
        Book b2 = new Book("Java 21", "James", 599.0);

        System.out.println(b1);
        System.out.println("Equal? " + b1.equals(b2));
    }
}
