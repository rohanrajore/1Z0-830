package com.module09.records_java21;

import java.util.*;

public class Exercise_08_RecordInterfaces {
    // TODO: Implement Comparable to sort records based on a field

    public record Vehicle(String type) implements Comparable<Vehicle> {
        @Override
        public int compareTo(Vehicle v) {
            return this.type.compareTo(v.type);
        }
    }

    public static void main(String[] args) {
        List<Vehicle> list = Arrays.asList(new Vehicle("Bus"), new Vehicle("Car"), new Vehicle("Auto"));
        Collections.sort(list);
        System.out.println(list);
    }
}
