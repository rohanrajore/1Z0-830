package com.module09.records_java21;

public class Exercise_02_RecordDeclaration {
    // TODO: Create an Employee record and access fields using accessors

    public record Employee(String name, int id, double salary) {}

    public static void main(String[] args) {
        Employee e = new Employee("Alice", 101, 75000);
        System.out.println("Name: " + e.name());
        System.out.println("ID: " + e.id());
        System.out.println("Salary: " + e.salary());
    }
}
