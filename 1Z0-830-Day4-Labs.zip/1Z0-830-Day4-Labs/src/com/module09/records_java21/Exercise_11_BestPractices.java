package com.module09.records_java21;

public class Exercise_11_BestPractices {
    // TODO: Add compact constructor validation for empty username/password

    public record LoginRequest(String username, String password) {
        public LoginRequest {
            if (username == null || username.isBlank() || password == null || password.isBlank()) {
                throw new IllegalArgumentException("Username and password cannot be empty");
            }
        }
    }

    public static void main(String[] args) {
        LoginRequest req = new LoginRequest("user1", "secret");
        System.out.println(req);
    }
}
