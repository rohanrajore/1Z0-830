package com.module09.records_java21;

public class Exercise_03_RecordMethods {
    // TODO: Compare records using equals() and hashCode(), print toString()

    public record Product(String name, double price) {}

    public static void main(String[] args) {
        Product p1 = new Product("Pen", 10.0);
        Product p2 = new Product("Pen", 10.0);

        System.out.println("p1.equals(p2): " + p1.equals(p2));
        System.out.println("p1.hashCode() == p2.hashCode(): " + (p1.hashCode() == p2.hashCode()));
        System.out.println("toString: " + p1);
    }
}
