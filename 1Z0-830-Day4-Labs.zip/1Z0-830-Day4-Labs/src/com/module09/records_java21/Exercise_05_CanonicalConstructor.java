package com.module09.records_java21;

public class Exercise_05_CanonicalConstructor {
    // TODO: Implement canonical constructor that swaps start and end if reversed

    public record Range(int start, int end) {
        public Range(int start, int end) {
            if (start > end) {
                System.out.println("Swapping start and end");
                int temp = start;
                start = end;
                end = temp;
            }
            this.start = start;
            this.end = end;
        }
    }

    public static void main(String[] args) {
        Range r = new Range(10, 5);
        System.out.println(r);
    }
}
