package com.module09.records_java21;

public class Exercise_10_RecordVsClass {
    // TODO: Compare a regular class vs a record

    static class PersonClass {
        private final String name;
        private final int age;

        public PersonClass(String name, int age) {
            this.name = name;
            this.age = age;
        }

        public String getName() { return name; }
        public int getAge() { return age; }

        @Override
        public String toString() {
            return "PersonClass{name='" + name + "', age=" + age + "}";
        }
    }

    public record PersonRecord(String name, int age) {}

    public static void main(String[] args) {
        PersonClass pc = new PersonClass("Asha", 25);
        PersonRecord pr = new PersonRecord("Asha", 25);

        System.out.println(pc);
        System.out.println(pr);
    }
}
