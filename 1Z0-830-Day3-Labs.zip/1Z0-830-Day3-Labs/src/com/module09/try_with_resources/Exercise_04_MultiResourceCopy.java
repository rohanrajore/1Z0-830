package com.module09.try_with_resources;

import java.io.*;

class CustomFileInputStream extends FileInputStream {
    public CustomFileInputStream(String name) throws FileNotFoundException {
        super(name);
    }
    @Override
    public void close() throws IOException {
        System.out.println("CustomFileInputStream closed");
        super.close();
    }
}

class CustomFileOutputStream extends FileOutputStream {
    public CustomFileOutputStream(String name) throws FileNotFoundException {
        super(name);
    }
    @Override
    public void close() throws IOException {
        System.out.println("CustomFileOutputStream closed");
        super.close();
    }
}

public class Exercise_04_MultiResourceCopy {
    public static void main(String[] args) {
        // TODO: Copy file using multiple resources and verify reverse close order
        try (
            CustomFileInputStream fis = new CustomFileInputStream("input.txt");
            CustomFileOutputStream fos = new CustomFileOutputStream("output.txt")
        ) {
            fos.write(fis.readAllBytes());
            System.out.println("File copied successfully.");
        } catch (IOException e) {
            System.out.println("I/O Error: " + e.getMessage());
        }
    }
}
