package com.module09.try_with_resources;

import java.io.*;

public class Exercise_01_ResourceIntro {
    public static void main(String[] args) {
        // TODO: Read file manually using finally, then refactor to try-with-resources

        // Manual close example
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader("data.txt"));
            System.out.println("Manual Read: " + br.readLine());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null) br.close();
                System.out.println("Manually closed resource.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Refactored version using try-with-resources
        try (BufferedReader br2 = new BufferedReader(new FileReader("data.txt"))) {
            System.out.println("Auto-closed Read: " + br2.readLine());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
