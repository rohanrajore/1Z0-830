package com.module09.try_with_resources;

import java.io.*;

public class Exercise_03_TryWithResourcesDemo {
    public static void main(String[] args) {
        // TODO: Use try-with-resources for auto-closing
        try (BufferedReader br = new BufferedReader(new FileReader("data.txt"))) {
            System.out.println("First line: " + br.readLine());
        } catch (IOException e) {
            System.out.println("Error reading: " + e.getMessage());
        }
    }
}
