package com.module09.try_with_resources;

import java.io.*;

class TempFileHandler implements AutoCloseable {
    private final File tempFile;

    TempFileHandler() throws IOException {
        tempFile = File.createTempFile("demo", ".tmp");
        System.out.println("Temp file created: " + tempFile.getAbsolutePath());
    }

    @Override
    public void close() {
        if (tempFile.exists() && tempFile.delete()) {
            System.out.println("Temp file deleted: " + tempFile.getName());
        } else {
            System.out.println("Failed to delete temp file.");
        }
    }
}

public class Exercise_06_CustomResource {
    public static void main(String[] args) {
        // TODO: Use custom AutoCloseable to handle temp file cleanup
        try (TempFileHandler handler = new TempFileHandler()) {
            System.out.println("Using temp file...");
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
