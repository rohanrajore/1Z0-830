package com.module09.try_with_resources;

class MyResource implements AutoCloseable {
    public void use() { System.out.println("Using resource..."); }
    @Override
    public void close() { System.out.println("Resource closed automatically."); }
}

public class Exercise_05_AutoCloseableDemo {
    public static void main(String[] args) {
        // TODO: Create custom AutoCloseable and verify cleanup
        try (MyResource r = new MyResource()) {
            r.use();
        }
    }
}
