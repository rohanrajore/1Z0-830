package com.module09.try_with_resources;

import java.io.*;

public class Exercise_10_ComparisonDemo {
    public static void main(String[] args) {
        // TODO: Compare manual vs try-with-resources handling

        // Manual close
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader("data.txt"));
            System.out.println("Manual: " + br.readLine());
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            try {
                if (br != null) br.close();
                System.out.println("Manual close completed.");
            } catch (IOException e) {
                System.out.println("Close error: " + e.getMessage());
            }
        }

        // Try-with-resources
        try (BufferedReader br2 = new BufferedReader(new FileReader("data.txt"))) {
            System.out.println("Auto: " + br2.readLine());
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
