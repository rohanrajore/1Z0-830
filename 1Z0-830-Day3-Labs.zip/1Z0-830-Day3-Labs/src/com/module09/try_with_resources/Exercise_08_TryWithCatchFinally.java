package com.module09.try_with_resources;

import java.io.*;

public class Exercise_08_TryWithCatchFinally {
    public static void main(String[] args) {
        // TODO: Verify closure before catch/finally
        try (BufferedReader br = new BufferedReader(new FileReader("data.txt"))) {
            System.out.println("Reading: " + br.readLine());
            throw new IOException("Simulated read failure");
        } catch (IOException e) {
            System.out.println("Caught exception: " + e.getMessage());
        } finally {
            System.out.println("Finally executed after resource close.");
        }
    }
}
