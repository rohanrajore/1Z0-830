package com.module09.try_with_resources;

import java.io.*;

public class Exercise_02_ManualResourceClose {
    public static void main(String[] args) {
        // TODO: Demonstrate failure before closing resource manually
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader("data.txt"));
            System.out.println("Reading file...");
            if (true) throw new IOException("Intentional failure before closing");
        } catch (IOException e) {
            System.out.println("Caught: " + e.getMessage());
        } finally {
            try {
                if (br != null) br.close();
                System.out.println("Closed manually in finally.");
            } catch (IOException e) {
                System.out.println("Error closing: " + e.getMessage());
            }
        }
    }
}
