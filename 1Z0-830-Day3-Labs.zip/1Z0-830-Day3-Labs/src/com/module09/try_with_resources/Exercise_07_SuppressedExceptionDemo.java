package com.module09.try_with_resources;

class FaultyResource implements AutoCloseable {
    @Override
    public void close() throws Exception {
        throw new Exception("Error closing resource");
    }
}

public class Exercise_07_SuppressedExceptionDemo {
    public static void main(String[] args) {
        // TODO: Demonstrate suppressed exceptions
        try (FaultyResource fr = new FaultyResource()) {
            throw new Exception("Error in try block");
        } catch (Exception e) {
            System.out.println("Caught: " + e.getMessage());
            for (Throwable t : e.getSuppressed()) {
                System.out.println("Suppressed: " + t);
            }
        }
    }
}
