package com.module09.try_with_resources;

import java.io.*;

public class Exercise_09_Java9ResourceReuse {
    public static void main(String[] args) throws IOException {
        // TODO: Demonstrate Java 9 feature - reuse existing resource
        BufferedReader br = new BufferedReader(new FileReader("data.txt"));
        try (br) {
            System.out.println("Read using reused resource: " + br.readLine());
        } catch (IOException e) {
            System.out.println("Error reading: " + e.getMessage());
        }
    }
}
