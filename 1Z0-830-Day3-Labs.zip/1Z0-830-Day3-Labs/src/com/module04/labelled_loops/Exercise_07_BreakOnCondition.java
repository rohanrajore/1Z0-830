package com.module04.labelled_loops;

public class Exercise_07_BreakOnCondition {
    public static void main(String[] args) {
        // TODO: Break outer loop when product equals 9 and print coordinates
        outer:
        for (int row = 1; row <= 3; row++) {
            for (int col = 1; col <= 3; col++) {
                if (row * col == 9) {
                    System.out.println("Condition met at (" + row + "," + col + ")");
                    break outer;
                }
            }
        }
        System.out.println("Exited after meeting the condition.");
    }
}
