package com.module04.labelled_loops;

import java.util.Scanner;

public class Exercise_08_MatrixSearch {
    public static void main(String[] args) {
        // TODO: Search a 2D matrix for a given number using labelled loop
        int[][] matrix = {
            {10, 20, 30},
            {40, 50, 60},
            {70, 80, 90}
        };

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number to search: ");
        int num = sc.nextInt();
        boolean found = false;

        find:
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] == num) {
                    System.out.println("Found at (" + i + "," + j + ")");
                    found = true;
                    break find;
                }
            }
        }

        if (!found) System.out.println("Number not found.");
        sc.close();
    }
}
