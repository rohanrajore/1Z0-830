package com.module04.labelled_loops;

public class Exercise_04_LabelledContinue {
    public static void main(String[] args) {
        // TODO: Skip a student entirely if any subject has "Fail"
        String[][] results = {
            {"Pass", "Pass", "Pass"},
            {"Pass", "Fail", "Pass"},
            {"Pass", "Pass", "Pass"}
        };

        outer:
        for (int student = 0; student < results.length; student++) {
            for (int subject = 0; subject < results[student].length; subject++) {
                if (results[student][subject].equals("Fail")) {
                    System.out.println("Skipping student " + (student + 1) + " due to failure.");
                    continue outer;
                }
            }
            System.out.println("Student " + (student + 1) + " cleared all subjects.");
        }
    }
}
