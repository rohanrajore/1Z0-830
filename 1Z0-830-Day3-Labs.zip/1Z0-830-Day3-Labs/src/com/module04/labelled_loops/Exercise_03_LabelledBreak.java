package com.module04.labelled_loops;

public class Exercise_03_LabelledBreak {
    public static void main(String[] args) {
        // TODO: Search for a specific value in 2D array using labelled break
        int[][] matrix = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };
        int searchValue = 5;
        boolean found = false;

        search:
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] == searchValue) {
                    System.out.println("Found " + searchValue + " at (" + i + "," + j + ")");
                    found = true;
                    break search;
                }
            }
        }
        if (!found) System.out.println(searchValue + " not found.");
    }
}
