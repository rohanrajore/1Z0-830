package com.module04.labelled_loops;

public class Exercise_05_LabelScope {
    public static void main(String[] args) {
        // TODO: Demonstrate invalid label on code block, then fix with a loop

        // ❌ Invalid (uncomment to test compilation error)
        // myBlock: {
        //     System.out.println("This is not a loop!");
        //     break myBlock;
        // }

        // ✅ Correct version
        myLoop:
        for (int i = 1; i <= 3; i++) {
            if (i == 2) {
                System.out.println("Breaking out at i=" + i);
                break myLoop;
            }
            System.out.println("i=" + i);
        }
    }
}
