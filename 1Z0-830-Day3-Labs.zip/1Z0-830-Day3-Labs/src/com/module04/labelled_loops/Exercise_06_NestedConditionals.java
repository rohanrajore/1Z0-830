package com.module04.labelled_loops;

public class Exercise_06_NestedConditionals {
    public static void main(String[] args) {
        // TODO: Print even outer numbers and their inner multiplications, skip product > 4
        for (int i = 1; i <= 4; i++) {
            if (i % 2 == 0) {
                for (int j = 1; j <= 3; j++) {
                    int product = i * j;
                    if (product > 4) continue;
                    System.out.println("Even outer: " + i + ", inner: " + j + ", product: " + product);
                }
            }
        }
    }
}
