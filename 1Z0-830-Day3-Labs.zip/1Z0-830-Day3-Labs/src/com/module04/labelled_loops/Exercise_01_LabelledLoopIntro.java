package com.module04.labelled_loops;

public class Exercise_01_LabelledLoopIntro {
    public static void main(String[] args) {
        // TODO: Create nested loops labelled outer and inner, break when i * j == 6
        outer:
        for (int i = 1; i <= 3; i++) {
            inner:
            for (int j = 1; j <= 5; j++) {
                System.out.println("i=" + i + ", j=" + j);
                if (i * j == 6) {
                    System.out.println("Breaking out at i * j = 6 (" + i + "," + j + ")");
                    break outer;
                }
            }
        }
        System.out.println("Exited outer loop.");
    }
}
