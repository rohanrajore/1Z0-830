package com.module04.labelled_loops;

public class Exercise_02_LabelPurpose {
    public static void main(String[] args) {
        // TODO: Demonstrate difference between normal break and labelled break
        System.out.println("=== Normal break ===");
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                if (j == 2) break;
                System.out.println("i=" + i + ", j=" + j);
            }
        }

        System.out.println("\n=== Labelled break ===");
        outer:
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                if (j == 2) break outer;
                System.out.println("i=" + i + ", j=" + j);
            }
        }
        System.out.println("Exited labelled loop early.");
    }
}
