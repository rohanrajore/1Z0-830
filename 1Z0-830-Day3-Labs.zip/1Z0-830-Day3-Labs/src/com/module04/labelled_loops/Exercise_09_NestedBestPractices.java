package com.module04.labelled_loops;

public class Exercise_09_NestedBestPractices {

    // TODO: Split nested logic into methods for clarity
    static boolean searchValue(int[][] data, int target) {
        search:
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                if (data[i][j] == target) {
                    System.out.println("Found " + target + " at (" + i + "," + j + ")");
                    return true;
                }
            }
        }
        return false;
    }

    public static void main(String[] args) {
        int[][] matrix = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };
        int target = 5;

        // Call search method
        boolean result = searchValue(matrix, target);
        if (!result) System.out.println("Value not found.");
        System.out.println("Program completed cleanly.");
    }
}
