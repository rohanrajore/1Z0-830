package com.module11.best_practices;

public class Exercise_06_ExceptionSwallowing {
    static void swallow() {
        // TODO: Show bad practice
        try { int x = 5 / 0; } catch (Exception e) { }
        System.out.println("Swallowed exception.");
    }
    static void properHandle() {
        // TODO: Show good practice
        try { int x = 5 / 0; }
        catch (Exception e) { System.err.println("Logged: " + e.getMessage()); throw e; }
    }
    public static void main(String[] args) {
        swallow();
        try { properHandle(); } catch (Exception e) { System.err.println("Handled properly: " + e.getMessage()); }
    }
}
