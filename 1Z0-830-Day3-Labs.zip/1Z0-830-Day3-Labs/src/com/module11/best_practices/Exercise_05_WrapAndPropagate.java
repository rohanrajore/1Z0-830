package com.module11.best_practices;

import java.io.*;

class DataAccessException2 extends Exception {
    DataAccessException2(String msg, Throwable cause) { super(msg, cause); }
}

public class Exercise_05_WrapAndPropagate {
    static void readFile() throws DataAccessException2 {
        // TODO: Wrap IOException into custom exception
        try (BufferedReader br = new BufferedReader(new FileReader("missing.txt"))) {
            System.out.println(br.readLine());
        } catch (IOException e) {
            throw new DataAccessException2("Failed to read file", e);
        }
    }

    public static void main(String[] args) {
        try { readFile(); } catch (DataAccessException2 e) { e.printStackTrace(); }
    }
}
