package com.module11.best_practices;

public class Exercise_02_PropagationDemo {
    static void methodA() { methodB(); }
    static void methodB() { methodC(); }
    static void methodC() { throw new RuntimeException("Error in methodC"); }

    public static void main(String[] args) {
        // TODO: Observe how exception propagates up the stack
        try {
            methodA();
        } catch (RuntimeException e) {
            e.printStackTrace();
        }
    }
}
