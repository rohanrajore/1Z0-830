package com.module11.best_practices;

import java.sql.SQLException;

class DataAccessException extends Exception {
    DataAccessException(String msg, Throwable cause) { super(msg, cause); }
}
class ServiceException extends Exception {
    ServiceException(String msg, Throwable cause) { super(msg, cause); }
}

public class Exercise_03_LayeredHandling {
    static void dataLayer() throws SQLException { throw new SQLException("DB failure"); }
    static void serviceLayer() throws DataAccessException {
        try { dataLayer(); } catch (SQLException e) { throw new DataAccessException("Data layer failed", e); }
    }
    static void controllerLayer() throws ServiceException {
        try { serviceLayer(); } catch (DataAccessException e) { throw new ServiceException("Service layer error", e); }
    }

    public static void main(String[] args) {
        // TODO: Observe exception chaining in layered structure
        try { controllerLayer(); } catch (ServiceException e) { e.printStackTrace(); }
    }
}
