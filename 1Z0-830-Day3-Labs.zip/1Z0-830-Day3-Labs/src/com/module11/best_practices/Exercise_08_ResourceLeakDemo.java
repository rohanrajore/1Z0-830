package com.module11.best_practices;

import java.io.*;

public class Exercise_08_ResourceLeakDemo {
    public static void main(String[] args) throws IOException {
        // TODO: Demonstrate resource leak
        FileReader fr = new FileReader("data.txt");
        System.out.println("File opened but not closed.");
    }
}
