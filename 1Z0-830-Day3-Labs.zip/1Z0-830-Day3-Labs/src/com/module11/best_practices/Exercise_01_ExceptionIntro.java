package com.module11.best_practices;

public class Exercise_01_ExceptionIntro {
    public static void main(String[] args) {
        // TODO: Throw and catch an exception to observe stack trace
        try {
            throw new Exception("Demonstration of exception flow");
        } catch (Exception e) {
            System.out.println("Caught exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
