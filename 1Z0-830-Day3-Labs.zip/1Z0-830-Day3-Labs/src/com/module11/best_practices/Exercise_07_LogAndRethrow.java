package com.module11.best_practices;

import java.io.*;

class ReportSaveException extends Exception {
    ReportSaveException(String msg, Throwable cause) { super(msg, cause); }
}

public class Exercise_07_LogAndRethrow {
    static void saveReport(String filename) throws ReportSaveException {
        // TODO: Log and rethrow wrapped exception
        try { throw new IOException("Disk write error"); }
        catch (IOException e) {
            System.err.println("Failed to save: " + filename);
            throw new ReportSaveException("Report save failed", e);
        }
    }

    public static void main(String[] args) {
        try { saveReport("output.txt"); } catch (ReportSaveException e) { e.printStackTrace(); }
    }
}
