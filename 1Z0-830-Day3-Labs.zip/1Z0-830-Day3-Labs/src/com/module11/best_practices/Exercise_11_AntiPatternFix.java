package com.module11.best_practices;

public class Exercise_11_AntiPatternFix {
    static void badPractice() {
        try { int x = 5 / 0; } catch (Exception e) { } // Empty catch
    }
    static void goodPractice() {
        try { int x = 5 / 0; }
        catch (ArithmeticException e) {
            System.err.println("Handled: " + e.getMessage());
            throw e;
        }
    }
    public static void main(String[] args) {
        badPractice();
        try { goodPractice(); } catch (Exception e) { System.err.println("Handled at top level: " + e.getMessage()); }
    }
}
