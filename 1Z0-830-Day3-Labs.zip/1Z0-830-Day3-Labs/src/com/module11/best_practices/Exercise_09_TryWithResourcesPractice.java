package com.module11.best_practices;

import java.io.*;

public class Exercise_09_TryWithResourcesPractice {
    public static void main(String[] args) {
        // TODO: Replace manual close with try-with-resources
        try (BufferedReader br = new BufferedReader(new FileReader("data.txt"))) {
            System.out.println("Line: " + br.readLine());
        } catch (IOException e) { System.out.println("Error: " + e.getMessage()); }
    }
}
