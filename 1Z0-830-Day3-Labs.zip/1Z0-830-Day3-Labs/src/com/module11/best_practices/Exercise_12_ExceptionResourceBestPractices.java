package com.module11.best_practices;

import java.io.*;

class SafeFileWriter implements AutoCloseable {
    private BufferedWriter writer;
    SafeFileWriter(String file) throws IOException { writer = new BufferedWriter(new FileWriter(file)); }
    void write(String msg) throws IOException { writer.write(msg); }
    public void close() throws IOException { writer.close(); System.out.println("File closed safely."); }
}

public class Exercise_12_ExceptionResourceBestPractices {
    public static void main(String[] args) {
        // TODO: Implement best practice for resource + exception handling
        try (SafeFileWriter sfw = new SafeFileWriter("output.txt")) {
            sfw.write("Hello from best practices!");
        } catch (IOException e) {
            System.err.println("File operation failed: " + e.getMessage());
        }
    }
}
