package com.module11.best_practices;

public class Exercise_04_CatchOrPropagate {
    static void localHandle() {
        try { int x = 10 / 0; }
        catch (ArithmeticException e) { System.out.println("Handled locally: " + e.getMessage()); }
    }
    static void propagate() { int x = 10 / 0; }

    public static void main(String[] args) {
        // TODO: Observe local vs propagated exception behavior
        localHandle();
        try { propagate(); } catch (ArithmeticException e) { System.out.println("Handled at caller: " + e.getMessage()); }
    }
}
