package com.module11.best_practices;

class FaultyResource implements AutoCloseable {
    @Override public void close() throws Exception { throw new Exception("Error in close()"); }
}

public class Exercise_10_SuppressedInClose {
    public static void main(String[] args) {
        // TODO: Demonstrate suppressed exception in close
        try (FaultyResource r = new FaultyResource()) {
            throw new Exception("Primary failure");
        } catch (Exception e) {
            System.out.println("Caught: " + e.getMessage());
            for (Throwable t : e.getSuppressed()) System.out.println("Suppressed: " + t);
        }
    }
}
