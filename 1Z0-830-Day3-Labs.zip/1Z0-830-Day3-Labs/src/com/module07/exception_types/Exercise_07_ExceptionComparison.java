package com.module07.exception_types;

import java.io.IOException;

public class Exercise_07_ExceptionComparison {

    static void checkedExample() throws IOException {
        throw new IOException("Checked exception must be handled.");
    }

    static void uncheckedExample() {
        throw new NullPointerException("Unchecked exception, no compile-time check.");
    }

    public static void main(String[] args) {
        try {
            checkedExample();
        } catch (IOException e) {
            System.out.println("Handled checked exception: " + e.getMessage());
        }

        uncheckedExample(); // Runtime only
    }
}
