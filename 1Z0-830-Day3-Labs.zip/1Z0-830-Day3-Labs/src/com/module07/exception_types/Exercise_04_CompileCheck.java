package com.module07.exception_types;

public class Exercise_04_CompileCheck {
    public static void main(String[] args) {
        // TODO: Demonstrate compile-time vs runtime enforcement
        try {
            Thread.sleep(1000); // Checked exception
        } catch (InterruptedException e) {
            System.out.println("Caught checked exception: " + e);
        }

        // Unchecked
        int result = 10 / 0; // ArithmeticException, compiler allows
        System.out.println("Result: " + result);
    }
}
