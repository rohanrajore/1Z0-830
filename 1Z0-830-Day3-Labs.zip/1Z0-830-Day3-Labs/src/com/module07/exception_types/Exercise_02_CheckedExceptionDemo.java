package com.module07.exception_types;

import java.io.*;

public class Exercise_02_CheckedExceptionDemo {

    // TODO: Use both throws declaration and try-catch for checked exception
    static void openFileThrows() throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("input.txt"));
        System.out.println(br.readLine());
        br.close();
    }

    static void openFileTryCatch() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("input.txt"));
            System.out.println(br.readLine());
            br.close();
        } catch (IOException e) {
            System.out.println("Handled via try-catch: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        openFileTryCatch();
        try {
            openFileThrows();
        } catch (IOException e) {
            System.out.println("Handled via throws: " + e.getMessage());
        }
    }
}
