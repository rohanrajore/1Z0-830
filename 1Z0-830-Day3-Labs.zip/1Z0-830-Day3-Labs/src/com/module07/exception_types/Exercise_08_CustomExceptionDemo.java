package com.module07.exception_types;

// TODO: Define custom checked and unchecked exceptions
class LowBalanceException extends Exception {
    LowBalanceException(String msg) { super(msg); }
}

class InvalidPinException extends RuntimeException {
    InvalidPinException(String msg) { super(msg); }
}

public class Exercise_08_CustomExceptionDemo {
    static void withdraw(double balance) throws LowBalanceException {
        if (balance < 1000) throw new LowBalanceException("Low balance: " + balance);
        System.out.println("Withdrawal successful!");
    }

    static void validatePin(int pin) {
        if (pin != 1234) throw new InvalidPinException("Invalid PIN!");
        System.out.println("PIN verified successfully.");
    }

    public static void main(String[] args) {
        try {
            validatePin(9999);
        } catch (InvalidPinException e) {
            System.out.println("Caught unchecked exception: " + e.getMessage());
        }

        try {
            withdraw(500);
        } catch (LowBalanceException e) {
            System.out.println("Caught checked exception: " + e.getMessage());
        }
    }
}
