package com.module07.exception_types;

import java.io.IOException;

public class Exercise_01_ExceptionIntro {
    public static void main(String[] args) {
        // TODO: Demonstrate one checked (IOException) and one unchecked (NullPointerException) exception

        try {
            throw new IOException("This is a checked exception");
        } catch (IOException e) {
            System.out.println("Caught checked exception: " + e.getMessage());
        }

        try {
            String s = null;
            s.length(); // Unchecked exception
        } catch (NullPointerException e) {
            System.out.println("Caught unchecked exception: " + e);
        }
    }
}
