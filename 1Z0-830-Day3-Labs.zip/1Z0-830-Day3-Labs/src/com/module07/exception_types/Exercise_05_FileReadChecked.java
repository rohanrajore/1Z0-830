package com.module07.exception_types;

import java.io.*;

public class Exercise_05_FileReadChecked {
    public static void main(String[] args) {
        // TODO: Read a missing file safely
        try {
            BufferedReader br = new BufferedReader(new FileReader("missing.txt"));
            System.out.println(br.readLine());
            br.close();
        } catch (IOException e) {
            System.out.println("Recovery: Could not read file - " + e.getMessage());
        }
        System.out.println("Program continued successfully.");
    }
}
