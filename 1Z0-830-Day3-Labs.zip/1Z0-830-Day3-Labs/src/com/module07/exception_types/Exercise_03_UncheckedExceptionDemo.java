package com.module07.exception_types;

public class Exercise_03_UncheckedExceptionDemo {
    public static void main(String[] args) {
        // TODO: Trigger three unchecked exceptions

        try {
            String s = null;
            s.length();
        } catch (NullPointerException e) {
            System.out.println("Caught NullPointerException: " + e);
        }

        try {
            int x = 10 / 0;
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException: " + e);
        }

        try {
            int[] arr = {1, 2, 3};
            System.out.println(arr[4]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught ArrayIndexOutOfBoundsException: " + e);
        }
    }
}
