package com.module07.exception_types;

public class Exercise_06_DefensiveCoding {
    // TODO: Validate arguments before performing operations
    static void divide(int a, int b) {
        if (b == 0) throw new IllegalArgumentException("Denominator cannot be zero.");
        System.out.println("Result: " + (a / b));
    }

    static void printUpper(String str) {
        if (str == null || str.isEmpty()) throw new IllegalArgumentException("String cannot be null or empty.");
        System.out.println(str.toUpperCase());
    }

    public static void main(String[] args) {
        try {
            divide(10, 2);
            divide(10, 0);
        } catch (IllegalArgumentException e) {
            System.out.println("Caught: " + e.getMessage());
        }

        try {
            printUpper("java");
            printUpper(null);
        } catch (IllegalArgumentException e) {
            System.out.println("Caught: " + e.getMessage());
        }
    }
}
