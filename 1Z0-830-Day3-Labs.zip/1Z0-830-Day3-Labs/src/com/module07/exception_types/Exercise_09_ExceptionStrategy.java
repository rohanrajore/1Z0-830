package com.module07.exception_types;

import java.io.*;

// TODO: Wrap checked exception into custom runtime exception
class DataLoadException extends RuntimeException {
    DataLoadException(String msg) { super(msg); }
}

public class Exercise_09_ExceptionStrategy {
    static void loadData() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("data.txt"));
            System.out.println(br.readLine());
            br.close();
        } catch (IOException e) {
            throw new DataLoadException("Failed to load data: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        try {
            loadData();
        } catch (DataLoadException e) {
            System.out.println("Handled DataLoadException: " + e.getMessage());
        }
    }
}
