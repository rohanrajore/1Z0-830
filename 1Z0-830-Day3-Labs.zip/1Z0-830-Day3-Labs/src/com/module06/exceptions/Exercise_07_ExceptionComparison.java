package com.module06.exceptions;

import java.io.IOException;

public class Exercise_07_ExceptionComparison {
    // TODO: Method that throws checked exception
    static void checkedExceptionMethod() throws IOException {
        throw new IOException("This is a checked exception");
    }

    // TODO: Method that throws unchecked exception
    static void uncheckedExceptionMethod() {
        throw new NullPointerException("This is an unchecked exception");
    }

    public static void main(String[] args) {
        try {
            checkedExceptionMethod();
        } catch (IOException e) {
            System.out.println("Handled checked exception: " + e.getMessage());
        }

        uncheckedExceptionMethod();
    }
}
