package com.module06.exceptions;

public class Exercise_03_ErrorDemo {
    // TODO: Deliberately cause StackOverflowError using recursion
    static void recursive() {
        recursive(); // Infinite recursion
    }

    public static void main(String[] args) {
        try {
            recursive();
        } catch (Error e) {
            System.out.println("Caught severe system error: " + e);
        }
        System.out.println("Execution continues after catching Error.");
    }
}
