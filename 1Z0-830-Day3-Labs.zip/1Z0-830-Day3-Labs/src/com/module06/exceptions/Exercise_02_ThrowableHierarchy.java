package com.module06.exceptions;

public class Exercise_02_ThrowableHierarchy {
    public static void main(String[] args) {
        // TODO: Demonstrate Throwable superclass with both Error and Exception
        try {
            throw new Exception("Sample Exception");
        } catch (Exception e) {
            System.out.println("Caught: " + e.getClass().getName());
        }

        try {
            throw new Error("Sample Error");
        } catch (Error e) {
            System.out.println("Caught: " + e.getClass().getName());
        }
    }
}
