package com.module06.exceptions;

public class Exercise_04_ExceptionCategories {
    public static void main(String[] args) {
        // TODO: List checked and unchecked exceptions
        System.out.println("Checked Exceptions:");
        System.out.println("1. IOException");
        System.out.println("2. SQLException");
        System.out.println("3. ParseException");

        System.out.println("\nUnchecked Exceptions:");
        System.out.println("1. NullPointerException");
        System.out.println("2. ArithmeticException");
        System.out.println("3. ArrayIndexOutOfBoundsException");
    }
}
