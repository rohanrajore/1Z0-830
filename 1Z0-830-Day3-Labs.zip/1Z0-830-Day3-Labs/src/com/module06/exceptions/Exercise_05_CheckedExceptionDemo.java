package com.module06.exceptions;

import java.io.*;

public class Exercise_05_CheckedExceptionDemo {
    // TODO: Read a non-existent file to trigger IOException
    static void readFile() throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("missing.txt"));
        System.out.println(br.readLine());
        br.close();
    }

    public static void main(String[] args) {
        try {
            readFile();
        } catch (IOException e) {
            System.out.println("Caught checked exception: " + e);
        }
    }
}
