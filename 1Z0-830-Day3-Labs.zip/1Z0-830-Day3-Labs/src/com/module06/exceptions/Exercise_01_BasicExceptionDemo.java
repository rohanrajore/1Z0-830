package com.module06.exceptions;

public class Exercise_01_BasicExceptionDemo {
    public static void main(String[] args) {
        // TODO: Divide two integers and trigger ArithmeticException
        int x = 10, y = 0;
        System.out.println("Before division");
        int result = x / y; // Triggers ArithmeticException
        System.out.println("This will not execute: " + result);
    }
}
