package com.module06.exceptions;

// TODO: Create custom exception LowBalanceException
class LowBalanceException extends Exception {
    LowBalanceException(String message) {
        super(message);
    }
}

public class Exercise_08_CustomException {
    static void checkBalance(double balance) throws LowBalanceException {
        if (balance < 1000)
            throw new LowBalanceException("Balance too low: " + balance);
        else
            System.out.println("Balance sufficient: " + balance);
    }

    public static void main(String[] args) {
        try {
            checkBalance(800);
        } catch (LowBalanceException e) {
            System.out.println("Handled custom exception: " + e.getMessage());
        }
    }
}
