package com.module06.exceptions;

public class Exercise_09_ExceptionTreePrint {
    public static void main(String[] args) {
        // TODO: Print simplified version of Java's exception hierarchy
        System.out.println("Throwable");
        System.out.println(" ├── Error");
        System.out.println(" │    ├── OutOfMemoryError");
        System.out.println(" │    └── StackOverflowError");
        System.out.println(" └── Exception");
        System.out.println("      ├── IOException (checked)");
        System.out.println("      │    └── FileNotFoundException");
        System.out.println("      ├── SQLException (checked)");
        System.out.println("      └── RuntimeException (unchecked)");
        System.out.println("           ├── NullPointerException");
        System.out.println("           ├── ArithmeticException");
        System.out.println("           └── IndexOutOfBoundsException");
    }
}
