package com.module05.return_statement;

public class Exercise_05_MultiReturn {
    // TODO: Return grade string based on score range
    static String grade(int score) {
        if (score >= 90) return "Excellent";
        else if (score >= 75) return "Good";
        else if (score >= 50) return "Average";
        else return "Fail";
    }

    public static void main(String[] args) {
        System.out.println("Score 95: " + grade(95));
        System.out.println("Score 80: " + grade(80));
        System.out.println("Score 55: " + grade(55));
        System.out.println("Score 40: " + grade(40));
    }
}
