package com.module05.return_statement;

public class Exercise_03_VoidReturn {
    // TODO: Print error and exit early if n is negative, else print square of n
    static void printSquare(int n) {
        if (n < 0) {
            System.out.println("Error: Negative number not allowed");
            return; // early exit
        }
        System.out.println("Square of " + n + " = " + (n * n));
    }

    public static void main(String[] args) {
        printSquare(5);
        printSquare(-2);
    }
}
