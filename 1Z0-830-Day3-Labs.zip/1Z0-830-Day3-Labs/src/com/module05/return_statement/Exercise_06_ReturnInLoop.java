package com.module05.return_statement;

public class Exercise_06_ReturnInLoop {
    // TODO: Return first even number found in array, else return -1
    static int findFirstEven(int[] arr) {
        for (int num : arr) {
            if (num % 2 == 0) return num; // exits loop and method
        }
        return -1; // no even number found
    }

    public static void main(String[] args) {
        int[] numbers = {1, 3, 5, 8, 9};
        System.out.println("First even number: " + findFirstEven(numbers));

        int[] numbers2 = {1, 3, 5, 7};
        System.out.println("First even number: " + findFirstEven(numbers2));
    }
}
