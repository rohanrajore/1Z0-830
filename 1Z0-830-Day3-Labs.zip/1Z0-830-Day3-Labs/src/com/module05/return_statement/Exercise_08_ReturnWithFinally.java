package com.module05.return_statement;

public class Exercise_08_ReturnWithFinally {
    // TODO: Return integer inside try and print cleanup message in finally
    static int getValue() {
        try {
            System.out.println("Inside try block");
            return 100;
        } finally {
            System.out.println("Cleanup done (finally block executed)");
        }
    }

    public static void main(String[] args) {
        int result = getValue();
        System.out.println("Returned value: " + result);
    }
}
