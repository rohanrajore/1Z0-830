package com.module05.return_statement;

public class Exercise_07_RecursiveReturn {
    // TODO: Implement recursive method that sums numbers from 1 to n
    static int sumToN(int n) {
        if (n == 1) return 1; // base case
        return n + sumToN(n - 1); // recursive call and return
    }

    public static void main(String[] args) {
        int n = 5;
        System.out.println("Sum from 1 to " + n + " = " + sumToN(n));
    }
}
