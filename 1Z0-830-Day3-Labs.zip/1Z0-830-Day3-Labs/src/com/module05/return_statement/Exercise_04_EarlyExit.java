package com.module05.return_statement;

public class Exercise_04_EarlyExit {
    // TODO: Return false if age < 18 or age > 60, true otherwise
    static boolean isEligible(int age) {
        if (age < 18) return false;
        if (age > 60) return false;
        return true;
    }

    public static void main(String[] args) {
        System.out.println("Age 15: " + isEligible(15));
        System.out.println("Age 25: " + isEligible(25));
        System.out.println("Age 65: " + isEligible(65));
    }
}
