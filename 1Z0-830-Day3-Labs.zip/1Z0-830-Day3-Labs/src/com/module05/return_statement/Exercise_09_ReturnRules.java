package com.module05.return_statement;

public class Exercise_09_ReturnRules {

    // ❌ Invalid Example (return in constructor not allowed)
    // Uncomment below lines to observe compile-time error
    /*
    Exercise_09_ReturnRules() {
        return; // invalid in constructor
    }
    */

    // ✅ Correct approach using a guard method
    Exercise_09_ReturnRules(int n) {
        if (!isValid(n)) {
            System.out.println("Invalid parameter, constructor continues safely.");
            return; // this is valid - exits constructor early but not returning a value
        }
        System.out.println("Object created successfully with value: " + n);
    }

    static boolean isValid(int n) {
        return n > 0;
    }

    public static void main(String[] args) {
        new Exercise_09_ReturnRules(-5);
        new Exercise_09_ReturnRules(10);
    }
}
