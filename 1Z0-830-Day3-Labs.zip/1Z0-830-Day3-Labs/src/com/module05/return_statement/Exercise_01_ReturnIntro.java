package com.module05.return_statement;

public class Exercise_01_ReturnIntro {
    // TODO: Create displayMessage() method that prints “Welcome!” and exits using return;
    static void displayMessage() {
        System.out.println("Welcome!");
        return; // exits the method
    }

    public static void main(String[] args) {
        displayMessage();
        displayMessage(); // observe that both calls work independently
    }
}
