package com.module05.return_statement;

public class Exercise_02_ReturnInMethods {
    // TODO: Create a method that returns the greater of two numbers
    static int max(int a, int b) {
        if (a > b) return a;
        else return b;
    }

    public static void main(String[] args) {
        int result = max(10, 20);
        System.out.println("Max is: " + result);
    }
}
