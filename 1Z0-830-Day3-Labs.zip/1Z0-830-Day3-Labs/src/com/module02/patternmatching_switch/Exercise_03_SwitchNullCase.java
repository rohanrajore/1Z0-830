package com.module02.patternmatching_switch;

public class Exercise_03_SwitchNullCase {

    public static void main(String[] args) {
        Object val = null;

        // TODO: Add case null for safe handling
        switch (val) {
            case null -> System.out.println("Null input not allowed");
            default -> System.out.println("Non-null value: " + val);
        }
    }
}
