package com.module02.patternmatching_switch;

public class Exercise_08_MultiLabelPattern {

    // TODO: Identify whether object is text, numeric, or other using switch pattern matching
    static void classify(Object obj) {
        switch (obj) {
            // ✅ Numeric check handled via instanceof in one case
            case Integer i -> System.out.println("Numeric type: " + i);
            case Long l -> System.out.println("Numeric type: " + l);
            case Double d -> System.out.println("Numeric type: " + d);
            case Float f -> System.out.println("Numeric type: " + f);

            // ✅ Single-type pattern with binding
            case String s -> System.out.println("Text type: " + s);

            // ✅ Null-safe handling
            case null -> System.out.println("Null value");

            // ✅ Default fallback
            default -> System.out.println("Other type: " + obj);
        }
    }

    public static void main(String[] args) {
        classify(100);                 // Integer
        classify(25L);                 // Long
        classify(3.14);                // Double
        classify("Pattern Matching");  // String
        classify(true);                // Other type
        classify(null);                // Null case
    }
}
