package com.module02.patternmatching_switch;

public class Exercise_07_SealedShapeSwitch {

    // ✅ Nested sealed interface
    sealed interface Shape permits Circle, Rectangle, Triangle {}

    // ✅ Permitted record types (nested static by default)
    record Circle(double radius) implements Shape {}
    record Rectangle(double length, double width) implements Shape {}
    record Triangle(double base, double height) implements Shape {}

    // ✅ Exhaustive switch using pattern matching (Java 21 preview)
    static String describeShape(Shape shape) {
        return switch (shape) {
            case Circle c    -> "Circle with radius " + c.radius();
            case Rectangle r -> "Rectangle with area " + (r.length() * r.width());
            case Triangle t  -> "Triangle with area " + (0.5 * t.base() * t.height());
        };
    }

    public static void main(String[] args) {
        Shape s1 = new Circle(3.5);
        Shape s2 = new Rectangle(4.0, 6.0);
        Shape s3 = new Triangle(5.0, 2.5);

        System.out.println(describeShape(s1));
        System.out.println(describeShape(s2));
        System.out.println(describeShape(s3));
    }
}

//javac --enable-preview --release 21 com/module02/patternmatching_switch/Exercise_07_SealedShapeSwitch.java
//java  --enable-preview com.module02.patternmatching_switch.Exercise_07_SealedShapeSwitch
//
//Circle with radius 3.5
//Rectangle with area 24.0
//Triangle with area 6.25

