package com.module02.patternmatching_switch;

public class Exercise_01_SwitchPatternIntro {

    // TODO: Implement a method that accepts an Object and identifies its type using pattern matching
    static void identifyObject(Object obj) {
        switch (obj) {
            case Integer i -> System.out.println("Integer: " + i);
            case Double d -> System.out.println("Double: " + d);
            case String s -> System.out.println("String: " + s);
            case null -> System.out.println("Null value");
            default -> System.out.println("Unknown type");
        }
    }

    public static void main(String[] args) {
        identifyObject(42);
        identifyObject(3.14);
        identifyObject("Hello");
        identifyObject(null);
    }
}
