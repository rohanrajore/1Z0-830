package com.module02.patternmatching_switch;

public class Exercise_06_DominanceRules {

    public static void main(String[] args) {
        Object obj = "Java";

        // TODO: Try swapping order and observe compilation error; fix by placing specific case first
        switch (obj) {
            case String s when s.isEmpty() -> System.out.println("Empty string");
            case String s -> System.out.println("Non-empty string: " + s);
            default -> System.out.println("Other type");
        }
    }
}
