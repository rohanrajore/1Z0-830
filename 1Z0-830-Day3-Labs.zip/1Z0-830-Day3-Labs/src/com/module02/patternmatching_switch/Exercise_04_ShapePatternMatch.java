package com.module02.patternmatching_switch;

// Simple shape hierarchy
class Shape {}
class Circle extends Shape {
    double radius;
    Circle(double radius) { this.radius = radius; }
}
class Rectangle extends Shape {
    double length, width;
    Rectangle(double length, double width) { this.length = length; this.width = width; }
}

public class Exercise_04_ShapePatternMatch {

    // TODO: Use pattern matching to print shape info
    static void describeShape(Shape shape) {
        switch (shape) {
            case Circle c -> System.out.println("Circle radius: " + c.radius);
            case Rectangle r -> System.out.println("Rectangle area: " + (r.length * r.width));
            default -> System.out.println("Unknown shape");
        }
    }

    public static void main(String[] args) {
        describeShape(new Circle(4.5));
        describeShape(new Rectangle(3, 6));
        describeShape(null);
    }
}
