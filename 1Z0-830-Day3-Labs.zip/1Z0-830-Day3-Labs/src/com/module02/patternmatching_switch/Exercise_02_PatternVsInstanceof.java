package com.module02.patternmatching_switch;

public class Exercise_02_PatternVsInstanceof {

    // TODO: Method using traditional instanceof
    static void traditional(Object obj) {
        if (obj instanceof String) {
            String s = (String) obj;
            System.out.println("Traditional: " + s.toUpperCase());
        } else if (obj instanceof Integer) {
            Integer i = (Integer) obj;
            System.out.println("Traditional: " + (i + 10));
        } else {
            System.out.println("Traditional: Unsupported type");
        }
    }

    // TODO: Method using pattern matching in switch
    static void patternMatching(Object obj) {
        switch (obj) {
            case String s -> System.out.println("Pattern: " + s.toUpperCase());
            case Integer i -> System.out.println("Pattern: " + (i + 10));
            default -> System.out.println("Pattern: Unsupported type");
        }
    }

    public static void main(String[] args) {
        traditional("java");
        traditional(25);
        patternMatching("pattern");
        patternMatching(50);
    }
}
