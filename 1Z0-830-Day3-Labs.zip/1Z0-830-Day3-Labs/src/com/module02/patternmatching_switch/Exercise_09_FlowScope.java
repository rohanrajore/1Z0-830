package com.module02.patternmatching_switch;

public class Exercise_09_FlowScope {

    public static void main(String[] args) {
        Object obj = "FlowScope Demo";

        // TODO: Use same variable name across patterns to show flow scoping
        switch (obj) {
            case String s -> System.out.println("String length: " + s.length());
            case Integer s -> System.out.println("Integer value: " + s);
            default -> System.out.println("Unknown type");
        }
    }
}
