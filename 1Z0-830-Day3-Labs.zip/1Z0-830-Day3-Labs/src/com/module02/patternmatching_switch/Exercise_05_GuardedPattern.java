package com.module02.patternmatching_switch;

public class Exercise_05_GuardedPattern {

    public static void main(String[] args) {
        Object obj = -15;

        // TODO: Add guarded patterns to classify integer values
        switch (obj) {
            case Integer i when i < 0 -> System.out.println("Negative number");
            case Integer i when i <= 100 -> System.out.println("Small number: " + i);
            case Integer i -> System.out.println("Large number: " + i);
            default -> System.out.println("Not an integer");
        }
    }
}
