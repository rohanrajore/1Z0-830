package com.module03.loops;

public class Exercise_07_BreakExample {

    public static void main(String[] args) {

        for (int i = 1; i <= 100; i++) {
            if (i == 42) {
                System.out.println("Loop stopped at " + i);
                break;
            }
            System.out.println(i);
        }
        System.out.println("Exited loop successfully!");
    }
}
