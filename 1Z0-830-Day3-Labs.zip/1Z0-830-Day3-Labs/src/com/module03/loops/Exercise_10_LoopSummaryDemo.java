package com.module03.loops;

public class Exercise_10_LoopSummaryDemo {

    public static void main(String[] args) {

        System.out.println("=== for loop ===");
        for (int i = 1; i <= 3; i++)
            System.out.println("Iteration: " + i);

        System.out.println("\n=== while loop ===");
        int i = 1;
        while (i <= 3) {
            System.out.println("Count: " + i);
            i++;
        }

        System.out.println("\n=== do–while loop ===");
        int j = 1;
        do {
            System.out.println("Run: " + j);
            j++;
        } while (j <= 3);

        System.out.println("\n=== enhanced for loop ===");
        String[] colors = {"Red", "Green", "Blue"};
        for (String color : colors)
            System.out.println("Color: " + color);
    }
}
