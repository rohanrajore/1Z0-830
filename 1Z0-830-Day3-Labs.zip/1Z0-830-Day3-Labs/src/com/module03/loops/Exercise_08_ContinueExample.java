package com.module03.loops;

public class Exercise_08_ContinueExample {

    public static void main(String[] args) {

        System.out.println("Numbers from 1 to 20 (excluding multiples of 3):");
        for (int i = 1; i <= 20; i++) {
            if (i % 3 == 0) continue;
            System.out.print(i + " ");
        }
    }
}
