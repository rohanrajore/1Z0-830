package com.module03.loops;

public class Exercise_04_ForEachNames {

    public static void main(String[] args) {

        String[] students = {"Alice", "Bob", "Charlie", "Diana"};

        System.out.println("Greeting each student:");
        for (String name : students) {
            System.out.println("Hello, " + name + "!");
        }

        System.out.println("\nPrinting with index using normal for loop:");
        for (int i = 0; i < students.length; i++) {
            System.out.println("Index " + i + ": " + students[i]);
        }
    }
}
