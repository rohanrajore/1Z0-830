package com.module03.loops;

import java.util.Scanner;

public class Exercise_06_DoWhileMenu {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int choice;
        double a, b;

        do {
            System.out.println("\n--- Simple Calculator ---");
            System.out.println("1. Add");
            System.out.println("2. Subtract");
            System.out.println("3. Multiply");
            System.out.println("4. Divide");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            if (choice == 5) {
                System.out.println("Exiting calculator...");
                break;
            }

            System.out.print("Enter first number: ");
            a = sc.nextDouble();
            System.out.print("Enter second number: ");
            b = sc.nextDouble();

            switch (choice) {
                case 1 -> System.out.println("Result = " + (a + b));
                case 2 -> System.out.println("Result = " + (a - b));
                case 3 -> System.out.println("Result = " + (a * b));
                case 4 -> System.out.println("Result = " + ((b != 0) ? (a / b) : "Undefined (divide by zero)"));
                default -> System.out.println("Invalid choice!");
            }

        } while (true);

        sc.close();
    }
}
