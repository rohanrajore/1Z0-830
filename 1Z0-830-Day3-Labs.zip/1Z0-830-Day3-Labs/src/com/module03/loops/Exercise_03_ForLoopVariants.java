package com.module03.loops;

import java.util.Scanner;

public class Exercise_03_ForLoopVariants {

    public static void main(String[] args) {

        for (int x = 1, y = 5; x <= y; x++, y--) {
            System.out.println("x=" + x + ", y=" + y);
        }

        Scanner sc = new Scanner(System.in);
        String input;
        System.out.println("\nType 'exit' to stop the loop:");
        for (;;) {
            System.out.print("Enter text: ");
            input = sc.nextLine();
            if (input.equalsIgnoreCase("exit")) {
                System.out.println("Loop terminated.");
                break;
            } else {
                System.out.println("You entered: " + input);
            }
        }
        sc.close();
    }
}
