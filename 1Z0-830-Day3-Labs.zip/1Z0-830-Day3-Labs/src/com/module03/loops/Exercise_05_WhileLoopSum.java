package com.module03.loops;

import java.util.Scanner;

public class Exercise_05_WhileLoopSum {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a positive number N: ");
        int n = sc.nextInt();

        int i = 1, sum = 0;
        while (i <= n) {
            sum += i;
            i++;
        }

        System.out.println("Sum of numbers from 1 to " + n + " = " + sum);
        sc.close();
    }
}
