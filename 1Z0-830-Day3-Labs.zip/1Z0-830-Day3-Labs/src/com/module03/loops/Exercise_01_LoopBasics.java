package com.module03.loops;

public class Exercise_01_LoopBasics {

    public static void main(String[] args) {

        System.out.println("Numbers from 1 to 10:");
        for (int i = 1; i <= 10; i++) {
            System.out.print(i + " ");
        }

        System.out.println("\n\nNumbers from 10 to 1:");
        for (int i = 10; i >= 1; i--) {
            System.out.print(i + " ");
        }
    }
}
