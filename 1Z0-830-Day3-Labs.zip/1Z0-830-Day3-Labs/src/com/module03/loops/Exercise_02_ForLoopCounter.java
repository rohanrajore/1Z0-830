package com.module03.loops;

public class Exercise_02_ForLoopCounter {

    public static void main(String[] args) {

        int count = 0;
        System.out.println("Even numbers between 1 and 20:");
        for (int i = 1; i <= 20; i++) {
            if (i % 2 == 0) {
                System.out.print(i + " ");
                count++;
            }
        }
        System.out.println("\nTotal even numbers found: " + count);
    }
}
