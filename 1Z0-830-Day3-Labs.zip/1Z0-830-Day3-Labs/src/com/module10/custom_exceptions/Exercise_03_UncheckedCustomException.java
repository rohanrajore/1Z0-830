package com.module10.custom_exceptions;

class NegativeNumberException extends RuntimeException {
    NegativeNumberException(String message) {
        super(message);
    }
}

public class Exercise_03_UncheckedCustomException {
    // TODO: Reject negative numbers in array
    static void processNumbers(int[] nums) {
        for (int n : nums) {
            if (n < 0) throw new NegativeNumberException("Negative number found: " + n);
            System.out.println("Processed: " + n);
        }
    }

    public static void main(String[] args) {
        try {
            int[] numbers = {5, -3, 10};
            processNumbers(numbers);
        } catch (NegativeNumberException e) {
            System.out.println("Caught runtime exception: " + e.getMessage());
        }
    }
}
