package com.module10.custom_exceptions;

class InvalidAgeException extends Exception {
    InvalidAgeException(String message) {
        super(message);
    }
    InvalidAgeException(String message, Throwable cause) {
        super(message, cause);
    }
}

public class Exercise_02_CheckedCustomException {
    // TODO: Validate age and throw InvalidAgeException if below 18
    static void registerUser(int age) throws InvalidAgeException {
        if (age < 18) throw new InvalidAgeException("Age must be 18 or above");
        System.out.println("User registered successfully.");
    }

    public static void main(String[] args) {
        try {
            registerUser(16);
        } catch (InvalidAgeException e) {
            System.out.println("Registration failed: " + e.getMessage());
        }
    }
}
