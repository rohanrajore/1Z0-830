package com.module10.custom_exceptions;

public class Exercise_04_ExceptionChoice {
    public static void main(String[] args) {
        // TODO: List cases for checked vs unchecked exceptions

        /*
         * Checked Exceptions (recoverable situations):
         * 1. FileNotFoundException → When reading a file that might not exist.
         * 2. SQLException → When a database connection fails temporarily.
         * 3. ParseException → When parsing external data that may be malformed.
         *
         * Unchecked Exceptions (programming logic errors):
         * 1. NullPointerException → Accessing methods on null objects.
         * 2. ArrayIndexOutOfBoundsException → Invalid array indexing.
         * 3. IllegalArgumentException → Invalid arguments passed to methods.
         */
    }
}
