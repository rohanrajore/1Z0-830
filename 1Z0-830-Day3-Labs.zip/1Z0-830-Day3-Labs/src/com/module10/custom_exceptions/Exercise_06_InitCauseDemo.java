package com.module10.custom_exceptions;

import java.io.IOException;

class BusinessException extends Exception {
    BusinessException(String message, Throwable cause) {
        super(message, cause);
    }
    BusinessException(String message) {
        super(message);
    }
}

public class Exercise_06_InitCauseDemo {
    public static void main(String[] args) throws BusinessException {
        // TODO: Demonstrate super(msg, cause) and initCause()
        IOException ioEx = new IOException("Low-level I/O issue");

        // Using super(msg, cause)
        try {
            throw new BusinessException("Operation failed", ioEx);
        } catch (BusinessException e) {
            System.out.println("Caught exception using super(msg, cause):");
            e.printStackTrace();
        }

        // Using initCause()
        try {
            BusinessException e2 = new BusinessException("Operation failed (initCause)");
            e2.initCause(ioEx);
            throw e2;
        } catch (BusinessException e) {
            System.out.println("\nCaught exception using initCause():");
            e.printStackTrace();
        }
    }
}
