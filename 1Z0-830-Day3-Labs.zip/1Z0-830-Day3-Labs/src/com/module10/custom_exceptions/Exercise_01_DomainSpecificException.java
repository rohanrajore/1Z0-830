package com.module10.custom_exceptions;

class InvalidOrderStateException extends Exception {
    InvalidOrderStateException(String message) {
        super(message);
    }
}

public class Exercise_01_DomainSpecificException {
    // TODO: Throw custom InvalidOrderStateException for invalid order transitions
    static void changeOrderState(String current, String next) throws InvalidOrderStateException {
        if (current.equals("Delivered") && next.equals("Processing")) {
            throw new InvalidOrderStateException("Invalid transition: Delivered → Processing");
        }
        System.out.println("Transition allowed: " + current + " → " + next);
    }

    public static void main(String[] args) {
        try {
            changeOrderState("Delivered", "Processing");
        } catch (InvalidOrderStateException e) {
            System.out.println("Caught custom exception: " + e.getMessage());
        }
    }
}
