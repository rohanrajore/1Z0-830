package com.module10.custom_exceptions;

import java.io.IOException;

class DataAccessException2 extends Exception {
    DataAccessException2(String msg, Throwable cause) { super(msg, cause); }
}

class ServiceException extends Exception {
    ServiceException(String msg, Throwable cause) { super(msg, cause); }
}

public class Exercise_08_MultiLayerChain {
    // TODO: Build 3-layer exception flow (Data, Service, Controller)

    static void dataLayer() throws IOException {
        throw new IOException("Disk read failure");
    }

    static void serviceLayer() throws DataAccessException2 {
        try {
            dataLayer();
        } catch (IOException e) {
            throw new DataAccessException2("Failed to access data", e);
        }
    }

    static void controllerLayer() throws ServiceException {
        try {
            serviceLayer();
        } catch (DataAccessException2 e) {
            throw new ServiceException("Unable to fetch records", e);
        }
    }

    public static void main(String[] args) {
        try {
            controllerLayer();
        } catch (ServiceException e) {
            System.out.println("Top-level catch:");
            e.printStackTrace();
        }
    }
}
