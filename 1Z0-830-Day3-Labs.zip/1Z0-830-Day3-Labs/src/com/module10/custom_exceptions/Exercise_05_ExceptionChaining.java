package com.module10.custom_exceptions;

import java.io.*;

class ConfigLoadException extends Exception {
    ConfigLoadException(String message, Throwable cause) {
        super(message, cause);
    }
}

public class Exercise_05_ExceptionChaining {
    // TODO: Simulate reading a missing file and wrap IOException into ConfigLoadException
    static void loadConfig() throws ConfigLoadException {
        try {
            BufferedReader br = new BufferedReader(new FileReader("missing_config.txt"));
            System.out.println(br.readLine());
        } catch (IOException e) {
            throw new ConfigLoadException("Failed to load configuration", e);
        }
    }

    public static void main(String[] args) {
        try {
            loadConfig();
        } catch (ConfigLoadException e) {
            System.out.println("Caught: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
