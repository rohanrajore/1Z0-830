package com.module10.custom_exceptions;

import java.io.IOException;

class FileLoadException extends Exception {
    FileLoadException(String msg, Throwable cause) { super(msg, cause); }
}

public class Exercise_09_ExceptionBestPractices {
    // TODO: Replace generic Exception with specific ones and chain causes
    static void loadFile(String filename) throws FileLoadException {
        try {
            throw new IOException("Unable to open file: " + filename);
        } catch (IOException e) {
            throw new FileLoadException("File load failed for: " + filename, e);
        }
    }

    public static void main(String[] args) {
        try {
            loadFile("report.txt");
        } catch (FileLoadException e) {
            System.out.println("Handled meaningful custom exception:");
            e.printStackTrace();
        }
    }
}
