package com.module10.custom_exceptions;

import java.io.*;
import java.nio.file.*;

class DataAccessException extends Exception {
    DataAccessException(String message, Throwable cause) {
        super(message, cause);
    }
}

public class Exercise_07_DataAccessChain {
    // TODO: Simulate database fetch with IOException wrapped in DataAccessException
    static void fetchData() throws DataAccessException {
        try {
            Files.readString(Path.of("data.txt"));
        } catch (IOException e) {
            throw new DataAccessException("Error reading data file", e);
        }
    }

    public static void main(String[] args) {
        try {
            fetchData();
        } catch (DataAccessException e) {
            System.out.println("Caught custom exception:");
            e.printStackTrace();
        }
    }
}
