package com.module01.conditionals;

import java.util.Scanner;

public class Exercise_09_SwitchComparison {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter percentage: ");
        int marks = sc.nextInt();

        // TODO: Compare nested if–else and modern switch expression

        /* 
        // Old if–else version (for reference)
        if (marks >= 90)
            System.out.println("Grade A");
        else if (marks >= 75)
            System.out.println("Grade B");
        else if (marks >= 60)
            System.out.println("Grade C");
        else
            System.out.println("Fail");
        */

        // Modern switch expression version
        String grade = switch (marks / 10) {
            case 10, 9 -> "A";
            case 8, 7 -> "B";
            case 6 -> "C";
            default -> "Fail";
        };

        System.out.println("Grade (Switch): " + grade);
        sc.close();
    }
}
