package com.module01.conditionals;

import java.util.Scanner;

public class Exercise_03_IfElseLadder {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter percentage: ");
        int marks = sc.nextInt();

        // TODO: Implement grading system (A, B, C, D, F)
        if (marks >= 90)
            System.out.println("Grade A");
        else if (marks >= 75)
            System.out.println("Grade B");
        else if (marks >= 60)
            System.out.println("Grade C");
        else if (marks >= 50)
            System.out.println("Grade D");
        else
            System.out.println("Grade F");

        sc.close();
    }
}
