package com.module01.conditionals;

import java.util.Scanner;

public class Exercise_06_EnhancedSwitch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter day (e.g., MONDAY, SUNDAY): ");
        String day = sc.next().toUpperCase();

        // TODO: Convert to enhanced switch with arrow syntax
        switch (day) {
            case "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY" ->
                System.out.println("Weekday");
            case "SATURDAY", "SUNDAY" ->
                System.out.println("Weekend");
            default ->
                System.out.println("Invalid day");
        }

        sc.close();
    }
}
