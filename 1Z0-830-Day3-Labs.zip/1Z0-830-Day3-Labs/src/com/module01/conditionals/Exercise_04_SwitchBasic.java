package com.module01.conditionals;

import java.util.Scanner;

public class Exercise_04_SwitchBasic {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter traffic light color (red/yellow/green): ");
        String color = sc.next().toLowerCase();

        // TODO: Write switch cases for red, yellow, green
        switch (color) {
            case "red":
                System.out.println("Stop");
                break;
            case "yellow":
                System.out.println("Wait");
                break;
            case "green":
                System.out.println("Go");
                break;
            default:
                System.out.println("Invalid color");
        }

        sc.close();
    }
}
