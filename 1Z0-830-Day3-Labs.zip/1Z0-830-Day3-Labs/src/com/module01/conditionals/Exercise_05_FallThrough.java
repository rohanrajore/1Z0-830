package com.module01.conditionals;

import java.util.Scanner;

public class Exercise_05_FallThrough {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter day number (1–7): ");
        int day = sc.nextInt();

        // TODO: Print “Weekend” for 6 or 7 using fall-through
        switch (day) {
            case 6:
            case 7:
                System.out.println("Weekend");
                break;
            default:
                System.out.println("Weekday");
        }

        sc.close();
    }
}
