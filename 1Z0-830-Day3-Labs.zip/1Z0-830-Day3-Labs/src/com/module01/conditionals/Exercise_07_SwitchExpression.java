package com.module01.conditionals;

import java.util.Scanner;

public class Exercise_07_SwitchExpression {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter grade (A/B/C/D/F): ");
        String grade = sc.next().toUpperCase();

        // TODO: Use switch expression to return feedback string
        String feedback = switch (grade) {
            case "A" -> "Excellent";
            case "B" -> "Good";
            case "C" -> "Average";
            case "D" -> "Poor";
            case "F" -> "Fail";
            default -> "Invalid grade";
        };

        System.out.println("Feedback: " + feedback);
        sc.close();
    }
}
