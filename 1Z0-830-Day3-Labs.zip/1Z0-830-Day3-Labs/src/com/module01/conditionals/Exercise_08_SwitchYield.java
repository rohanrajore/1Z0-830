package com.module01.conditionals;

import java.util.Scanner;

public class Exercise_08_SwitchYield {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter marks (0–100): ");
        int marks = sc.nextInt();

        // TODO: Use yield for multi-statement cases
        String result = switch (marks / 10) {
            case 10, 9 -> "A – Outstanding!";
            case 8 -> {
                System.out.println("Good effort! Keep pushing for A.");
                yield "B – Well done!";
            }
            case 7 -> {
                System.out.println("Nice try! Aim higher next time.");
                yield "C – Can improve.";
            }
            case 6 -> "D – Pass";
            default -> "Fail – Needs improvement.";
        };

        System.out.println("Result: " + result);
        sc.close();
    }
}
