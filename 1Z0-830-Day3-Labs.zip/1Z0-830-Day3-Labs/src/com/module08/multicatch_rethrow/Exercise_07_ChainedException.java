package com.module08.multicatch_rethrow;

import java.io.*;
import java.nio.file.*;

// TODO: Custom exception for data loading
class DataLoadException extends Exception {
    DataLoadException(String message, Throwable cause) {
        super(message, cause);
    }
}

public class Exercise_07_ChainedException {

    static void loadData() throws DataLoadException {
        try {
            Files.readString(Path.of("config.txt"));
        } catch (IOException e) {
            throw new DataLoadException("Load failed", e); // chaining original cause
        }
    }

    public static void main(String[] args) {
        try {
            loadData();
        } catch (DataLoadException e) {
            System.out.println("Handled: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
