package com.module08.multicatch_rethrow;

import java.sql.SQLException;

public class Exercise_05_DatabaseMultiCatch {
    public static void main(String[] args) {
        // TODO: Simulate database operations throwing SQLException or NullPointerException
        try {
            if (Math.random() > 0.5) throw new SQLException("Table not found");
            else throw new NullPointerException("Connection is null");
        } catch (SQLException | NullPointerException e) {
            System.out.println("Database operation failed: " + e.getMessage());
        }
    }
}
