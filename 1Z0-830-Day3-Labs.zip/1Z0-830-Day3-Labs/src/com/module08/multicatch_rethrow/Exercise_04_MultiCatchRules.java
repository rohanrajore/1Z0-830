package com.module08.multicatch_rethrow;

import java.io.*;
import java.sql.SQLException;

public class Exercise_04_MultiCatchRules {
    public static void main(String[] args) {
        // TODO: Demonstrate invalid vs valid multi-catch rules

        // ❌ Invalid combination example (commented to compile)
        // catch (IOException | FileNotFoundException e) {}

        // ✅ Valid disjoint exceptions
        try {
            if (Math.random() > 0.5) throw new IOException("IO issue");
            else throw new SQLException("SQL issue");
        } catch (IOException | SQLException e) {
            System.out.println("Handled valid disjoint exceptions: " + e.getMessage());
        }
    }
}
