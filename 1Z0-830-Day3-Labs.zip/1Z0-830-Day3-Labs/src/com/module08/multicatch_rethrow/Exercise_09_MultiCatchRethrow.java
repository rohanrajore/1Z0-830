package com.module08.multicatch_rethrow;

import java.io.*;
import java.sql.SQLException;

public class Exercise_09_MultiCatchRethrow {

    static void performOperation() throws IOException, SQLException {
        try {
            if (Math.random() > 0.5) throw new IOException("File read failed");
            else throw new SQLException("Update failed");
        } catch (IOException | SQLException e) {
            System.out.println("Operation failed, logging: " + e.getMessage());
            throw e; // rethrow
        }
    }

    public static void main(String[] args) {
        try {
            performOperation();
        } catch (IOException | SQLException e) {
            System.out.println("Caught rethrown exception in main: " + e.getMessage());
        }
    }
}
