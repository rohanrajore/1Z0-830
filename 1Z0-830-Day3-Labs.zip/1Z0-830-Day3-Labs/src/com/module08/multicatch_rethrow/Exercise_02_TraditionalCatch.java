package com.module08.multicatch_rethrow;

import java.io.*;

public class Exercise_02_TraditionalCatch {
    public static void main(String[] args) {
        // ✅ Handle IOException as well
        try {
            BufferedReader br = new BufferedReader(new FileReader("data.txt"));
            int num = Integer.parseInt(br.readLine());
            System.out.println("Number read: " + num);
            br.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        } catch (NumberFormatException e) {
            System.out.println("Invalid number format");
        } catch (IOException e) {
            System.out.println("I/O error occurred: " + e.getMessage());
        }
    }
}
