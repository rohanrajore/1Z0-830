package com.module08.multicatch_rethrow;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Random;

public class Exercise_08_SpecificRethrow {

    // TODO: Throw both IOException and SQLException, rethrow with inferred types
    static void process() throws IOException, SQLException {
        try {
            if (new Random().nextBoolean())
                throw new IOException("File error");
            else
                throw new SQLException("Database error");
        } catch (Exception e) {
            System.out.println("Partial handling... rethrowing");
            throw e; // Compiler infers IOException | SQLException
        }
    }

    public static void main(String[] args) {
        try {
            process();
        } catch (IOException | SQLException e) {
            System.out.println("Caught in main: " + e.getMessage());
        }
    }
}
