package com.module08.multicatch_rethrow;

import java.io.IOException;
import java.sql.SQLException;

// TODO: Apply best practices - avoid broad Exception, use multi-catch, rethrow custom
class BusinessException extends RuntimeException {
    BusinessException(String msg) { super(msg); }
}

public class Exercise_10_ExceptionBestPractices {

    static void processTask() throws IOException, SQLException {
        if (Math.random() > 0.5) throw new IOException("Network error");
        else throw new SQLException("Database error");
    }

    static void handleProcess() {
        try {
            processTask();
        } catch (IOException | SQLException e) {
            System.out.println("Logging before rethrow: " + e.getMessage());
            throw new BusinessException("Operation failed, please retry.");
        }
    }

    public static void main(String[] args) {
        try {
            handleProcess();
        } catch (BusinessException e) {
            System.out.println("Caught custom business exception: " + e.getMessage());
        }
    }
}
