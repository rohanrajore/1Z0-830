package com.module08.multicatch_rethrow;

import java.io.*;

public class Exercise_06_RethrowBasic {

    // TODO: Read file, log and rethrow exception
    static void readFile() throws IOException {
        try {
            BufferedReader br = new BufferedReader(new FileReader("sample.txt"));
            System.out.println("First line: " + br.readLine());
            br.close();
        } catch (IOException e) {
            System.out.println("Logging error: " + e.getMessage());
            throw e; // rethrow
        }
    }

    public static void main(String[] args) {
        try {
            readFile();
        } catch (IOException e) {
            System.out.println("Caught in caller: " + e.getMessage());
        }
    }
}
