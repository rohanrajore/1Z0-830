package com.module08.multicatch_rethrow;

import java.io.*;

public class Exercise_01_MultiCatchIntro {
    public static void main(String[] args) {
        // ✅ Traditional multiple catch blocks
        try {
            BufferedReader br = new BufferedReader(new FileReader("numbers.txt"));
            int num = Integer.parseInt(br.readLine());
            System.out.println("Number: " + num);
            br.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number format: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("I/O error: " + e.getMessage());
        }
    }
}
