package com.module08.multicatch_rethrow;

import java.io.*;

public class Exercise_03_MultiCatchExample {
    public static void main(String[] args) {
        // ✅ Handle all possible checked + unchecked exceptions
        try {
            BufferedReader br = new BufferedReader(new FileReader("data.txt"));
            int num = Integer.parseInt(br.readLine());
            System.out.println("Number: " + num);
            br.close();
        } catch (NumberFormatException | IOException e) {
            System.out.println("Error occurred: " + e.getMessage());
        }
    }
}
