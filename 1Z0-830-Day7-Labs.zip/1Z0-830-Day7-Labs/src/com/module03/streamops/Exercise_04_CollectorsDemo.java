package com.module03.streamops;

import java.util.List;
import java.util.stream.Collectors;

public class Exercise_04_CollectorsDemo {
    public static void main(String[] args) {
        // TODO: Collect a list of student names into a single comma-separated string using joining()
        List<String> students = List.of("Ravi", "Anita", "Suresh", "Meena");
        String joined = students.stream()
                                .collect(Collectors.joining(", "));
        System.out.println("Joined names: " + joined);
    }
}
