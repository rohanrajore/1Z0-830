package com.module03.streamops;

import java.util.List;

public class Exercise_02_MapUppercase {
    public static void main(String[] args) {
        // TODO: Convert a list of lowercase city names to uppercase using map()
        List<String> cities = List.of("mumbai", "delhi", "chennai", "kolkata", "pune");
        cities.stream()
              .map(String::toUpperCase)
              .forEach(System.out::println);
    }
}
