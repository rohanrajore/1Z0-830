package com.module03.streamops;

import java.util.stream.IntStream;

public class Exercise_08_LimitSkip {
    public static void main(String[] args) {
        // TODO: Generate numbers from 1–20. Skip the first 5 and print the next 10
        IntStream.rangeClosed(1, 20)
                 .skip(5)
                 .limit(10)
                 .forEach(n -> System.out.print(n + " "));
    }
}
