package com.module03.streamops;

import java.util.*;
import java.util.stream.Collectors;

public class Exercise_10_CertificationPractice {
    public static void main(String[] args) {
        // TODO: Create a Stream pipeline that filters numbers > 5, doubles them, removes duplicates, and collects even numbers into a list
        List<Integer> numbers = List.of(2, 4, 6, 6, 8, 10, 12, 4, 14, 16);

        List<Integer> result = numbers.stream()
                .filter(n -> n > 5)
                .map(n -> n * 2)
                .distinct()
                .filter(n -> n % 2 == 0)
                .collect(Collectors.toList());

        System.out.println("Result list: " + result);
    }
}
