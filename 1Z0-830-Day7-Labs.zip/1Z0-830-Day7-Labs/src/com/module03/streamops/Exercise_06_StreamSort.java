package com.module03.streamops;

import java.util.*;

public class Exercise_06_StreamSort {
    public static void main(String[] args) {
        // TODO: Sort employee names alphabetically, then in reverse order using a comparator
        List<String> employees = List.of("Zara", "Amit", "Kiran", "Priya", "Nikhil");

        System.out.println("Alphabetical order:");
        employees.stream().sorted().forEach(System.out::println);

        System.out.println("\nReverse order:");
        employees.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
    }
}
