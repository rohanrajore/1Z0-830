package com.module03.streamops;

import java.util.List;

public class Exercise_03_ReduceSum {
    public static void main(String[] args) {
        // TODO: Use reduce() to find the product of numbers in a list
        List<Integer> nums = List.of(2, 3, 4, 5);
        int product = nums.stream()
                          .reduce(1, (a, b) -> a * b);
        System.out.println("Product: " + product);
    }
}
