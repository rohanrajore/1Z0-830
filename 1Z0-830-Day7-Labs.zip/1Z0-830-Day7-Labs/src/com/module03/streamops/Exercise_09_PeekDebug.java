package com.module03.streamops;

import java.util.List;

public class Exercise_09_PeekDebug {
    public static void main(String[] args) {
        // TODO: Use peek() to log elements before and after applying a transformation
        List<Integer> nums = List.of(2, 4, 6, 8);

        nums.stream()
            .peek(n -> System.out.println("Before doubling: " + n))
            .map(n -> n * 2)
            .peek(n -> System.out.println("After doubling: " + n))
            .forEach(n -> System.out.println("Final value: " + n));
    }
}
