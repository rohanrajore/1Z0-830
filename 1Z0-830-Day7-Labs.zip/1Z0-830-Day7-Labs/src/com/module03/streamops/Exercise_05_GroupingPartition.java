package com.module03.streamops;

import java.util.*;
import java.util.stream.Collectors;

public class Exercise_05_GroupingPartition {
    public static void main(String[] args) {
        // TODO: Use partitioningBy() to divide numbers into even and odd groups
        List<Integer> nums = List.of(5, 10, 13, 22, 17, 8, 31, 42);

        Map<Boolean, List<Integer>> partitioned = nums.stream()
                .collect(Collectors.partitioningBy(n -> n % 2 == 0));

        System.out.println("Even Numbers: " + partitioned.get(true));
        System.out.println("Odd Numbers: " + partitioned.get(false));
    }
}
