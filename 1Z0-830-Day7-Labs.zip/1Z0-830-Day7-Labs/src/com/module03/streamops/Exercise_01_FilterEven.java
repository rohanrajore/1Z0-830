package com.module03.streamops;

import java.util.List;

public class Exercise_01_FilterEven {
    public static void main(String[] args) {
        // TODO: Filter a list of integers to print only even numbers greater than 10
        List<Integer> numbers = List.of(5, 10, 12, 18, 7, 25, 20, 8);
        numbers.stream()
               .filter(n -> n > 10 && n % 2 == 0)
               .forEach(System.out::println);
    }
}
