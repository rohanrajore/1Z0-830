package com.module03.streamops;

import java.util.List;

public class Exercise_07_DistinctDemo {
    public static void main(String[] args) {
        // TODO: Print unique country names from a list containing duplicates
        List<String> countries = List.of("India", "USA", "India", "Germany", "France", "USA", "Japan");

        countries.stream()
                 .distinct()
                 .forEach(System.out::println);
    }
}
