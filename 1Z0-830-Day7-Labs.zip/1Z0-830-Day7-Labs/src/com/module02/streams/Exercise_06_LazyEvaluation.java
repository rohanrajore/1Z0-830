package com.module02.streams;

import java.util.stream.Stream;

public class Exercise_06_LazyEvaluation {
    public static void main(String[] args) {
        // TODO: Add a print statement inside a filter() and observe how many elements are processed for findFirst() vs count()
        System.out.println("Using findFirst():");
        Stream.of("Ravi", "Rohit", "Ankit")
              .filter(s -> {
                  System.out.println("Checking " + s);
                  return s.startsWith("R");
              })
              .findFirst();

        System.out.println("\nUsing count():");
        Stream.of("Ravi", "Rohit", "Ankit")
              .filter(s -> {
                  System.out.println("Checking " + s);
                  return s.startsWith("R");
              })
              .count();
    }
}
