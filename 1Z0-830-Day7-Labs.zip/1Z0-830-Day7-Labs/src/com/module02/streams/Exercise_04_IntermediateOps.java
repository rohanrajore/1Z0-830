package com.module02.streams;

import java.util.List;

public class Exercise_04_IntermediateOps {
    public static void main(String[] args) {
        // TODO: Create a pipeline using filter(), distinct(), and sorted() to process a list of country names
        List<String> countries = List.of("India", "Japan", "India", "Canada", "France", "Brazil", "Japan");

        List<String> result = countries.stream()
                                       .filter(c -> c.length() > 4)
                                       .distinct()
                                       .sorted()
                                       .toList();

        System.out.println("Processed countries: " + result);
    }
}
