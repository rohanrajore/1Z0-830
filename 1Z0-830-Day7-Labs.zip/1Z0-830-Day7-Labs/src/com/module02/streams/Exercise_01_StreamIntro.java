package com.module02.streams;

import java.util.List;

public class Exercise_01_StreamIntro {
    public static void main(String[] args) {
        // TODO: Create a Stream from a list of numbers and print only even numbers squared
        List<Integer> numbers = List.of(1, 2, 3, 4, 5, 6, 7, 8);
        numbers.stream()
                .filter(n -> n % 2 == 0)
                .map(n -> n * n)
                .forEach(System.out::println);
    }
}
