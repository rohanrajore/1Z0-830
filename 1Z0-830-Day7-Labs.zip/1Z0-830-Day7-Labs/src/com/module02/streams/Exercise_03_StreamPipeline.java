package com.module02.streams;

import java.util.List;

public class Exercise_03_StreamPipeline {
    public static void main(String[] args) {
        // TODO: Build a Stream pipeline to count the number of names starting with ‘R’ after converting them to uppercase
        List<String> names = List.of("Ravi", "Rahul", "Amit", "Ramesh", "Rohan", "Sneha");

        long count = names.stream()
                          .map(String::toUpperCase)
                          .filter(s -> s.startsWith("R"))
                          .count();

        System.out.println("Count of names starting with R: " + count);
    }
}
