package com.module02.streams;

import java.util.stream.Stream;

public class Exercise_08_StreamReuseError {
    public static void main(String[] args) {
        // TODO: Call two terminal operations on the same Stream and observe the runtime exception
        Stream<String> stream = Stream.of("A", "B", "C");

        stream.forEach(System.out::println);

        try {
            // Second terminal operation on the same stream will cause an exception
            stream.count();
        } catch (IllegalStateException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}
