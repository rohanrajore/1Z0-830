package com.module02.streams;

import java.util.*;
import java.util.stream.*;

public class Exercise_05_TerminalOps {
    public static void main(String[] args) {
        // TODO: Create a Stream of integers and find the sum, max, and average using terminal operations
        List<Integer> nums = IntStream.rangeClosed(1, 10).boxed().toList();

        int sum = nums.stream().reduce(0, Integer::sum);
        int max = nums.stream().max(Integer::compareTo).orElse(0);
        double avg = nums.stream().mapToInt(Integer::intValue).average().orElse(0);

        System.out.println("Sum: " + sum);
        System.out.println("Max: " + max);
        System.out.println("Average: " + avg);
    }
}
