package com.module02.streams;

import java.util.*;
import java.util.stream.*;

public class Exercise_02_StreamSources {
    public static void main(String[] args) {
        // TODO: Create three Streams — one from a List, one from an array, and one using Stream.iterate()
        List<String> names = List.of("Alice", "Bob", "Charlie");
        names.stream().forEach(System.out::println);

        int[] arr = {10, 20, 30, 40};
        Arrays.stream(arr).forEach(System.out::println);

        Stream<Integer> seq = Stream.iterate(1, n -> n + 2).limit(5);
        seq.forEach(System.out::println);
    }
}
