package com.module02.streams;

import java.util.stream.*;
import java.time.*;

public class Exercise_07_ParallelDemo {
    public static void main(String[] args) {
        // TODO: Compare the execution time of a normal Stream vs a Parallel Stream for summing 1 to 1,000,000
        int range = 1_000_000;

        Instant start1 = Instant.now();
        long normalSum = IntStream.rangeClosed(1, range).asLongStream().reduce(0, Long::sum);
        Instant end1 = Instant.now();
        System.out.println("Normal stream sum: " + normalSum + " in " + Duration.between(start1, end1).toMillis() + " ms");

        Instant start2 = Instant.now();
        long parallelSum = IntStream.rangeClosed(1, range).parallel().asLongStream().reduce(0, Long::sum);
        Instant end2 = Instant.now();
        System.out.println("Parallel stream sum: " + parallelSum + " in " + Duration.between(start2, end2).toMillis() + " ms");
    }
}
