package com.module06.fi;

import java.util.*;
import java.util.function.Function;
import java.util.function.Consumer;

public class Exercise_10_FinalReview {
    public static void main(String[] args) {
        // TODO: Flatten a list of lists using flatMap() and apply functional interfaces (Function, Consumer) in the same pipeline
        List<List<Integer>> data = List.of(List.of(1, 2), List.of(3, 4, 5), List.of(6, 7));

        Function<List<Integer>, java.util.stream.Stream<Integer>> flattener = List::stream;
        Consumer<Integer> printer = n -> System.out.println("Value: " + n);

        data.stream()
            .flatMap(flattener)
            .filter(n -> n % 2 == 0)
            .map(n -> n * 10)
            .forEach(printer);
    }
}
