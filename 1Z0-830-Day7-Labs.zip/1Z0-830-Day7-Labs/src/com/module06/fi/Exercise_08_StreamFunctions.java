package com.module06.fi;

import java.util.List;

public class Exercise_08_StreamFunctions {
    public static void main(String[] args) {
        // TODO: Match each stream operation with its corresponding functional interface type
        List<Integer> numbers = List.of(1, 2, 3, 4, 5);

        numbers.stream()
               .filter(n -> n > 2)           // Predicate
               .map(n -> n * 10)            // Function
               .forEach(System.out::println); // Consumer
    }
}
