package com.module06.fi;

import java.util.function.Function;

public class Exercise_03_FunctionCompose {
    public static void main(String[] args) {
        // TODO: Create two functions: one doubles and one squares an integer. Chain them with compose() and andThen()
        Function<Integer, Integer> doubleIt = n -> n * 2;
        Function<Integer, Integer> square = n -> n * n;

        System.out.println("Using compose (square first, then double): " + doubleIt.compose(square).apply(3));
        System.out.println("Using andThen (double first, then square): " + doubleIt.andThen(square).apply(3));
    }
}
