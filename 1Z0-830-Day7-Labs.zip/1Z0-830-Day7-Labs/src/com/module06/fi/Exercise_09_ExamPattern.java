package com.module06.fi;

import java.util.stream.Stream;

public class Exercise_09_ExamPattern {
    public static void main(String[] args) {
        // TODO: Trace this stream: filter numbers > 3, square them, and sum the results. Identify how many elements each stage processes
        int result = Stream.of(2, 3, 4, 5)
                           .filter(n -> n > 3)
                           .mapToInt(n -> n * n)
                           .reduce(0, Integer::sum);

        System.out.println("Sum of squares of numbers > 3 = " + result);
    }
}
