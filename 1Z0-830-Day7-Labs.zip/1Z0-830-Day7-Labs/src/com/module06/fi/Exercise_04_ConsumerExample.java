package com.module06.fi;

import java.util.function.BiConsumer;

public class Exercise_04_ConsumerExample {
    public static void main(String[] args) {
        // TODO: Create a BiConsumer<String, Integer> that prints “name = age”
        BiConsumer<String, Integer> personPrinter = (name, age) -> System.out.println(name + " = " + age);

        personPrinter.accept("Ravi", 30);
        personPrinter.accept("Anita", 25);
    }
}
