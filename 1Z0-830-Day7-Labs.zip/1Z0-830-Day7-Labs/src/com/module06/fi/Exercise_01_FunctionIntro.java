package com.module06.fi;

import java.util.List;
import java.util.function.*;

public class Exercise_01_FunctionIntro {
    public static void main(String[] args) {
        // TODO: Create lambdas using Predicate, Function, and Consumer to filter, transform, and print a list of strings
        List<String> names = List.of("Ravi", "Amit", "Neha", "Rajesh", "Nita");

        Predicate<String> startsWithR = s -> s.startsWith("R");
        Function<String, String> toUpper = String::toUpperCase;
        Consumer<String> printer = System.out::println;

        names.stream()
             .filter(startsWithR)
             .map(toUpper)
             .forEach(printer);
    }
}
