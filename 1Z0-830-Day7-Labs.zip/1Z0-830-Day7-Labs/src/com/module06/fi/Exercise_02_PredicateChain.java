package com.module06.fi;

import java.util.List;
import java.util.function.Predicate;

public class Exercise_02_PredicateChain {
    public static void main(String[] args) {
        // TODO: Filter words that start with “A” and have more than 3 letters using a chained predicate
        List<String> words = List.of("Amit", "Arun", "Raj", "Anu", "Amrita", "Dev");

        Predicate<String> startsWithA = s -> s.startsWith("A");
        Predicate<String> longerThan3 = s -> s.length() > 3;

        words.stream()
             .filter(startsWithA.and(longerThan3))
             .forEach(System.out::println);
    }
}
