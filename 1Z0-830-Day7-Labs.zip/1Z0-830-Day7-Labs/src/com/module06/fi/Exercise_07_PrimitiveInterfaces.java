package com.module06.fi;

import java.util.function.*;
import java.util.stream.IntStream;

public class Exercise_07_PrimitiveInterfaces {
    public static void main(String[] args) {
        // TODO: Use an IntSupplier to generate numbers and an IntPredicate to filter even ones before printing
        IntSupplier supplier = new IntSupplier() {
            private int count = 1;
            public int getAsInt() { return count++; }
        };

        IntPredicate isEven = n -> n % 2 == 0;

        IntStream.generate(supplier)
                 .limit(10)
                 .filter(isEven)
                 .forEach(System.out::println);
    }
}
