package com.module06.fi;

import java.util.function.Supplier;
import java.util.stream.Stream;

public class Exercise_05_SupplierRandom {
    public static void main(String[] args) {
        // TODO: Use a supplier to generate 5 random numbers and print them using a stream
        Supplier<Double> randomSupplier = Math::random;

        Stream.generate(randomSupplier)
              .limit(5)
              .forEach(System.out::println);
    }
}
