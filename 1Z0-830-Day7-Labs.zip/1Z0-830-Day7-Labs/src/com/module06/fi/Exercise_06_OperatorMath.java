package com.module06.fi;

import java.util.function.BinaryOperator;

public class Exercise_06_OperatorMath {
    public static void main(String[] args) {
        // TODO: Create a BinaryOperator<Double> that calculates the average of two numbers
        BinaryOperator<Double> average = (a, b) -> (a + b) / 2;

        System.out.println("Average of 4.5 and 7.5 = " + average.apply(4.5, 7.5));
    }
}
