package com.module04.streamops2;

import java.util.List;

public class Exercise_08_OptionalReduce {
    public static void main(String[] args) {
        // TODO: Find the minimum value in a stream using min() and print it only if present
        List<Integer> numbers = List.of(12, 7, 19, 3, 15);

        numbers.stream()
               .min(Integer::compareTo)
               .ifPresent(min -> System.out.println("Minimum value: " + min));
    }
}
