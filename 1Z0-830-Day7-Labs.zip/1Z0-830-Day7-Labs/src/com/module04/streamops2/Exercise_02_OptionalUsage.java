package com.module04.streamops2;

import java.util.Optional;

public class Exercise_02_OptionalUsage {
    public static void main(String[] args) {
        // TODO: Create an Optional<Double> and demonstrate the difference between orElse() and orElseGet()
        Optional<Double> opt = Optional.ofNullable(null);

        System.out.println("Using orElse(): " + opt.orElse(getDefaultValue()));
        System.out.println("Using orElseGet(): " + opt.orElseGet(() -> getDefaultValue()));
    }

    private static Double getDefaultValue() {
        System.out.println("Generating default value...");
        return 99.99;
    }
}
