package com.module04.streamops2;

import java.util.List;
import java.util.stream.Collectors;

public class Exercise_04_BoxedConversion {
    public static void main(String[] args) {
        // TODO: Convert a List<Integer> to an IntStream, calculate the sum, and then convert it back to a List<Integer> using boxed()
        List<Integer> numbers = List.of(3, 6, 9, 12, 15);
        int sum = numbers.stream().mapToInt(Integer::intValue).sum();
        System.out.println("Sum: " + sum);

        List<Integer> boxed = numbers.stream().mapToInt(Integer::intValue).boxed().collect(Collectors.toList());
        System.out.println("Boxed back to List: " + boxed);
    }
}
