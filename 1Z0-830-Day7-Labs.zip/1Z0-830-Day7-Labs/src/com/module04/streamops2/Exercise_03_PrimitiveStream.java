package com.module04.streamops2;

import java.util.stream.IntStream;

public class Exercise_03_PrimitiveStream {
    public static void main(String[] args) {
        // TODO: Generate numbers 1–10 using IntStream.rangeClosed() and print their squares
        IntStream.rangeClosed(1, 10)
                 .map(n -> n * n)
                 .forEach(System.out::println);
    }
}
