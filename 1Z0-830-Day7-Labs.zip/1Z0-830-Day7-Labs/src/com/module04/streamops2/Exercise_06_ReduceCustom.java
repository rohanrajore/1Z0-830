package com.module04.streamops2;

import java.util.List;

public class Exercise_06_ReduceCustom {
    public static void main(String[] args) {
        // TODO: Use reduce() to concatenate all names in a list separated by commas
        List<String> names = List.of("Ravi", "Neha", "Amit", "Priya");

        String result = names.stream()
                             .reduce("", (a, b) -> a.isEmpty() ? b : a + ", " + b);

        System.out.println("Concatenated: " + result);
    }
}
