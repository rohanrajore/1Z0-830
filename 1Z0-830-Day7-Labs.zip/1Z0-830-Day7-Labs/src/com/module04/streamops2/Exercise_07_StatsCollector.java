package com.module04.streamops2;

import java.util.*;
import java.util.stream.Collectors;

public class Exercise_07_StatsCollector {
    public static void main(String[] args) {
        // TODO: Use summarizingDouble() to calculate average, min, and max of product prices
        List<Double> prices = List.of(120.5, 340.75, 89.99, 450.25, 210.0);

        DoubleSummaryStatistics stats = prices.stream()
                                              .collect(Collectors.summarizingDouble(Double::doubleValue));

        System.out.println("Average: " + stats.getAverage());
        System.out.println("Min: " + stats.getMin());
        System.out.println("Max: " + stats.getMax());
    }
}
