package com.module04.streamops2;

import java.util.stream.IntStream;

public class Exercise_05_ReduceNumbers {
    public static void main(String[] args) {
        // TODO: Create a numeric stream and find sum, average, and min using the corresponding methods
        IntStream nums = IntStream.of(12, 45, 67, 23, 89, 34);

        int sum = nums.sum();
        double average = IntStream.of(12, 45, 67, 23, 89, 34).average().orElse(0);
        int min = IntStream.of(12, 45, 67, 23, 89, 34).min().orElse(0);

        System.out.println("Sum: " + sum);
        System.out.println("Average: " + average);
        System.out.println("Min: " + min);
    }
}
