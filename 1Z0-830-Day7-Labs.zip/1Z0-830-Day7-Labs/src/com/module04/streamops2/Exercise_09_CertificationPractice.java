package com.module04.streamops2;

import java.util.stream.IntStream;
import java.util.OptionalDouble;

public class Exercise_09_CertificationPractice {
    public static void main(String[] args) {
        // TODO: Generate random numbers using IntStream.generate(), filter those >50, and print the average using OptionalDouble
        OptionalDouble avg = IntStream.generate(() -> (int) (Math.random() * 100))
                                      .limit(20)
                                      .filter(n -> n > 50)
                                      .average();

        if (avg.isPresent()) {
            System.out.println("Average of numbers > 50: " + avg.getAsDouble());
        } else {
            System.out.println("No numbers greater than 50 found.");
        }
    }
}
