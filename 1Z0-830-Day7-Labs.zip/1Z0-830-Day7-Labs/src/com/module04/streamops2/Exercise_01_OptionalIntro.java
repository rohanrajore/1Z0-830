package com.module04.streamops2;

import java.util.List;
import java.util.Optional;

public class Exercise_01_OptionalIntro {
    public static void main(String[] args) {
        // TODO: Use findFirst() on a Stream of names to get the first name starting with ‘R’. If not found, print “No match found”
        List<String> names = List.of("Amit", "Neha", "Rohit", "Ravi", "Suresh");

        Optional<String> result = names.stream()
                                       .filter(n -> n.startsWith("R"))
                                       .findFirst();

        System.out.println(result.orElse("No match found"));
    }
}
