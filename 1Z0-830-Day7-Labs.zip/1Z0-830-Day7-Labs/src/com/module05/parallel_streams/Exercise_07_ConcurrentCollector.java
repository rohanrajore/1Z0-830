package com.module05.parallel_streams;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Exercise_07_ConcurrentCollector {
    public static void main(String[] args) {
        // TODO: Group a list of words by length using groupingByConcurrent() in a parallel stream
        List<String> words = List.of("apple", "bat", "ball", "cat", "banana", "mango");

        Map<Integer, List<String>> grouped =
            words.parallelStream()
                 .collect(Collectors.groupingByConcurrent(String::length));

        System.out.println("Grouped by length: " + grouped);
    }
}
