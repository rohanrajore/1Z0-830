package com.module05.parallel_streams;

import java.util.stream.IntStream;

public class Exercise_08_SpeedCheck {
    public static void main(String[] args) {
        // TODO: Run equivalent sequential and parallel pipelines and compare timings. Identify threshold where parallelism becomes efficient
        int limit = 1_000_000;

        long startSeq = System.nanoTime();
        long evenCountSeq = IntStream.range(1, limit).filter(n -> n % 2 == 0).count();
        long timeSeq = (System.nanoTime() - startSeq) / 1_000_000;
        System.out.println("Sequential count: " + evenCountSeq + " in " + timeSeq + " ms");

        long startPar = System.nanoTime();
        long evenCountPar = IntStream.range(1, limit).parallel().filter(n -> n % 2 == 0).count();
        long timePar = (System.nanoTime() - startPar) / 1_000_000;
        System.out.println("Parallel count: " + evenCountPar + " in " + timePar + " ms");
    }
}
