package com.module05.parallel_streams;

import java.util.stream.IntStream;

public class Exercise_06_SafeSum {
    static int unsafeSum = 0;

    public static void main(String[] args) {
        // TODO: Implement two versions of sum using parallel streams: one with shared mutable variable (unsafe) and one with reduce() (safe)
        unsafeSum = 0;
        IntStream.rangeClosed(1, 1000).parallel().forEach(n -> unsafeSum += n);
        System.out.println("Unsafe sum (race condition likely): " + unsafeSum);

        int safeSum = IntStream.rangeClosed(1, 1000).parallel().reduce(0, Integer::sum);
        System.out.println("Safe sum using reduce(): " + safeSum);
    }
}
