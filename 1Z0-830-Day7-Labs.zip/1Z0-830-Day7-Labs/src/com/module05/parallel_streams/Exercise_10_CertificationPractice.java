package com.module05.parallel_streams;

import java.util.stream.Stream;

public class Exercise_10_CertificationPractice {
    public static void main(String[] args) {
        // TODO: Create a parallel stream pipeline that maps, filters, and counts elements. Identify whether order of results is preserved or not
        long count = Stream.of("java", "spring", "cloud", "lambda", "stream", "api")
                           .parallel()
                           .map(String::toUpperCase)
                           .filter(s -> s.contains("A"))
                           .peek(s -> System.out.println(Thread.currentThread().getName() + " processing " + s))
                           .count();

        System.out.println("Total matching elements: " + count);
    }
}
