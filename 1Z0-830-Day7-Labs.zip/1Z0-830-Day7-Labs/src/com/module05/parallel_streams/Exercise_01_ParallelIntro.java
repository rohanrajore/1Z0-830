package com.module05.parallel_streams;

import java.util.stream.IntStream;
import java.time.Duration;
import java.time.Instant;

public class Exercise_01_ParallelIntro {
    public static void main(String[] args) {
        // TODO: Create a parallel stream to calculate the sum of 1 to 1,000,000 and compare performance with a sequential stream
        int range = 1_000_000;

        Instant startSeq = Instant.now();
        long sumSeq = IntStream.rangeClosed(1, range).asLongStream().sum();
        Instant endSeq = Instant.now();
        System.out.println("Sequential sum: " + sumSeq + " in " + Duration.between(startSeq, endSeq).toMillis() + " ms");

        Instant startPar = Instant.now();
        long sumPar = IntStream.rangeClosed(1, range).parallel().asLongStream().sum();
        Instant endPar = Instant.now();
        System.out.println("Parallel sum: " + sumPar + " in " + Duration.between(startPar, endPar).toMillis() + " ms");
    }
}
