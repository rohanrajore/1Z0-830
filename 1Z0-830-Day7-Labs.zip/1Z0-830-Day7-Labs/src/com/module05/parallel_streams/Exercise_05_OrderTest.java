package com.module05.parallel_streams;

import java.util.List;

public class Exercise_05_OrderTest {
    public static void main(String[] args) {
        // TODO: Run a parallel stream with both forEach() and forEachOrdered() to observe output differences
        List<String> letters = List.of("A", "B", "C", "D", "E");

        System.out.println("Using forEach():");
        letters.parallelStream().forEach(System.out::print);

        System.out.println("\nUsing forEachOrdered():");
        letters.parallelStream().forEachOrdered(System.out::print);
    }
}
