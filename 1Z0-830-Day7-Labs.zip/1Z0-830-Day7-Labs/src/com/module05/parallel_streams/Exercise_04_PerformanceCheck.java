package com.module05.parallel_streams;

import java.util.List;
import java.util.Random;

public class Exercise_04_PerformanceCheck {
    public static void main(String[] args) {
        // TODO: Compare execution times for processing 1M elements sequentially vs. parallel
        List<Double> data = new Random().doubles(1_000_000).boxed().toList();

        long start1 = System.currentTimeMillis();
        data.stream().map(Math::sqrt).toList();
        long end1 = System.currentTimeMillis();
        System.out.println("Sequential: " + (end1 - start1) + " ms");

        long start2 = System.currentTimeMillis();
        data.parallelStream().map(Math::sqrt).toList();
        long end2 = System.currentTimeMillis();
        System.out.println("Parallel: " + (end2 - start2) + " ms");
    }
}
