package com.module05.parallel_streams;

import java.util.List;
import java.util.stream.Stream;

public class Exercise_02_StreamMode {
    public static void main(String[] args) {
        // TODO: Create one sequential and one parallel stream. Verify both using isParallel()
        Stream<Integer> sequential = List.of(1, 2, 3, 4, 5).stream();
        Stream<Integer> parallel = List.of(6, 7, 8, 9, 10).parallelStream();

        System.out.println("Sequential is parallel? " + sequential.isParallel());
        System.out.println("Parallel is parallel? " + parallel.isParallel());
    }
}
