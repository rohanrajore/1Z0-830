package com.module05.parallel_streams;

import java.util.stream.IntStream;

public class Exercise_03_ThreadPrint {
    public static void main(String[] args) {
        // TODO: Use a parallel stream and print the current thread name for each element to observe concurrent processing
        IntStream.rangeClosed(1, 10)
                 .parallel()
                 .forEach(n -> System.out.println(Thread.currentThread().getName() + " → " + n));
    }
}
