package com.module05.parallel_streams;

import java.util.List;

public class Exercise_09_BestPractice {
    public static void main(String[] args) {
        // TODO: Refactor a parallel stream to remove side effects and make it safe for concurrent execution
        List<String> names = List.of("java", "stream", "parallel", "lambda");

        // Avoid side effects: use map and collect instead of modifying external data
        List<String> result = names.parallelStream()
                                   .map(String::toUpperCase)
                                   .toList();

        System.out.println("Result: " + result);
    }
}
