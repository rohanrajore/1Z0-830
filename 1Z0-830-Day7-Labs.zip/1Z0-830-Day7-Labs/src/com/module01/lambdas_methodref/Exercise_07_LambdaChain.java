package com.module01.lambdas_methodref;

import java.util.function.Function;

public class Exercise_07_LambdaChain {
    public static void main(String[] args) {
        // TODO: Create two functions and combine them using andThen() and compose()
        Function<Integer, Integer> doubleIt = x -> x * 2;
        Function<Integer, Integer> addTen = x -> x + 10;

        Function<Integer, Integer> chain1 = doubleIt.andThen(addTen);
        Function<Integer, Integer> chain2 = doubleIt.compose(addTen);

        System.out.println("andThen result (3): " + chain1.apply(3)); // (3*2)+10 = 16
        System.out.println("compose result (3): " + chain2.apply(3)); // (3+10)*2 = 26
    }
}
