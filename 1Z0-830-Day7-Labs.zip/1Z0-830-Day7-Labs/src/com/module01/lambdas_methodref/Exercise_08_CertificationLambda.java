package com.module01.lambdas_methodref;

import java.util.function.Predicate;

public class Exercise_08_CertificationLambda {
    public static void main(String[] args) {
        // TODO: Create a lambda and a method reference for the same operation, compare readability and syntax
        Predicate<String> isEmptyLambda = s -> s.isEmpty();
        Predicate<String> isEmptyRef = String::isEmpty;

        System.out.println("Using lambda: " + isEmptyLambda.test(""));
        System.out.println("Using method reference: " + isEmptyRef.test(""));
    }
}
