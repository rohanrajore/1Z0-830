package com.module01.lambdas_methodref;

import java.util.*;

public class Exercise_04_ComparatorLambda {
    public static void main(String[] args) {
        // TODO: Implement a Comparator lambda that sorts strings by their last character
        List<String> words = new ArrayList<>(List.of("banana", "apple", "grape", "kiwi"));
        words.sort((s1, s2) -> Character.compare(s1.charAt(s1.length() - 1), s2.charAt(s2.length() - 1)));

        System.out.println("Sorted by last character: " + words);
    }
}
