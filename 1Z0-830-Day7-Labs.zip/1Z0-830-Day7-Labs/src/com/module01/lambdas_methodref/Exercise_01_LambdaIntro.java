package com.module01.lambdas_methodref;

public class Exercise_01_LambdaIntro {
    public static void main(String[] args) {
        // TODO: Create a lambda that prints "Hello Java" using Runnable
        Runnable hello = () -> System.out.println("Hello Java");
        hello.run();
    }
}
