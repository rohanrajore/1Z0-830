package com.module01.lambdas_methodref;

import java.util.*;
import java.util.function.Function;

public class Exercise_05_MethodReferenceDemo {
    public static void main(String[] args) {
        // TODO: Rewrite a lambda expression using an equivalent method reference and verify output
        List<String> names = List.of("Ravi", "Meena", "Ankit");

        // Lambda version
        names.forEach(n -> System.out.println(n));

        // Method reference version
        names.forEach(System.out::println);

        Function<String, Integer> len = String::length;
        System.out.println("Length of 'Lambda': " + len.apply("Lambda"));
    }
}
