package com.module01.lambdas_methodref;

import java.util.function.Function;

public class Exercise_03_LambdaScope {
    public static void main(String[] args) {
        // TODO: Try modifying a local variable captured by a lambda and observe the compiler error
        int factor = 5;
        Function<Integer, Integer> multiply = x -> x * factor;

        // Uncommenting below line will cause compilation error
        // factor++;

        System.out.println(multiply.apply(10)); // Output: 50
    }
}
