package com.module01.lambdas_methodref;

import java.util.function.*;

public class Exercise_02_LambdaSyntax {
    public static void main(String[] args) {
        // TODO: Write three lambdas: one with no parameter, one with a single parameter, and one returning a value
        Runnable greet = () -> System.out.println("Welcome to Lambda Syntax Demo");
        Consumer<String> showUpper = s -> System.out.println(s.toUpperCase());
        BiFunction<Integer, Integer, Integer> multiply = (a, b) -> a * b;

        greet.run();
        showUpper.accept("java lambda");
        System.out.println("Product: " + multiply.apply(5, 3));
    }
}
