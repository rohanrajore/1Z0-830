package com.module01.lambdas_methodref;

import java.util.function.Supplier;

public class Exercise_06_ConstructorRef {
    public static void main(String[] args) {
        // TODO: Use a constructor reference to create a new StringBuilder instance and append text to it
        Supplier<StringBuilder> builderSupplier = StringBuilder::new;
        StringBuilder sb = builderSupplier.get();
        sb.append("Constructor Reference Example");
        System.out.println(sb.toString());
    }
}
