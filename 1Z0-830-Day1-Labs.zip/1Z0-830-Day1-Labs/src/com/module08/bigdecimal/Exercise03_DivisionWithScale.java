package com.module08.bigdecimal;
import java.math.BigDecimal;
import java.math.RoundingMode;
public class Exercise03_DivisionWithScale {
    public static void main(String[] args) {
        // TODO:
        // 1) Divide 10 by 3 -> demonstrate ArithmeticException without rounding mode.
        // 2) Repeat using divide(BigDecimal, scale, RoundingMode.HALF_UP).
        // 3) Show the effect of different scales (2, 4) on the result.
    }
}
