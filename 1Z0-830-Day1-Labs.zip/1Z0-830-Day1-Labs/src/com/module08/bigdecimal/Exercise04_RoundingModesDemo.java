package com.module08.bigdecimal;
import java.math.BigDecimal;
import java.math.RoundingMode;
public class Exercise04_RoundingModesDemo {
    public static void main(String[] args) {
        // TODO:
        // 1) For value 2.675, round to 2 decimals using HALF_UP, HALF_EVEN, DOWN, UP, FLOOR.
        // 2) Print each result and note differences.
    }
}
