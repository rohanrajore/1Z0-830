package com.module08.bigdecimal;
import java.math.BigDecimal;
import java.math.RoundingMode;
public class Exercise07_CumulativeRoundingError {
    public static void main(String[] args) {
        // TODO:
        // 1) Sum 0.01 one thousand times using double and print.
        // 2) Sum using BigDecimal("0.01") without rounding, then with setScale(2, HALF_UP) each step.
        // 3) Compare the three totals.
    }
}
