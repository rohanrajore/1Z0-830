package com.module08.bigdecimal;
import java.math.BigDecimal;
import java.math.RoundingMode;
public class Exercise02_BasicArithmetic {
    public static void main(String[] args) {
        // TODO:
        // 1) Create a=12.34, b=2.5 as BigDecimal (String ctor).
        // 2) Compute a+b, a-b, a*b.
        // 3) For division a/b: first call without scale (expect exception), then with setScale(2, RoundingMode.HALF_UP).
    }
}
