package com.module08.bigdecimal;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
public class Exercise08_FinancialCalculation {
    // EMI example (annuity formula):
    // principal P=250000, annual_rate=7.2% -> monthly_rate = annual_rate/12/100, term=60 months
    // EMI = P * r * (1+r)^n / ((1+r)^n - 1)
    public static void main(String[] args) {
        // TODO:
        // 1) Implement EMI using BigDecimal (String constructors). Use MathContext where needed.
        // 2) Round EMI to 2 decimals with HALF_EVEN (banking style). Print EMI.
        // 3) Compute total payable and interest component; round to 2dp.
    }
}
