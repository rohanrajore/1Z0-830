package com.module08.bigdecimal;
import java.math.BigDecimal;
public class Exercise01_CreatingBigDecimal {
    public static void main(String[] args) {
        // TODO:
        // 1) Create BigDecimal values using new BigDecimal("0.1") and new BigDecimal(0.1).
        // 2) Print both and explain why they differ.
        // 3) Create BigDecimal via BigDecimal.valueOf(0.1) and compare output.
    }
}
