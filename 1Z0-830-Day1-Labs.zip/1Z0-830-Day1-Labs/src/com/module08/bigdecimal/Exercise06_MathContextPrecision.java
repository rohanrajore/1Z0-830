package com.module08.bigdecimal;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
public class Exercise06_MathContextPrecision {
    public static void main(String[] args) {
        // TODO:
        // 1) Create BigDecimal p = new BigDecimal("3.1415926535897932384626").
        // 2) Multiply by 2 using a MathContext(5, HALF_UP) and print.
        // 3) Repeat with MathContext(10, HALF_UP). Observe intermediate rounding.
    }
}
