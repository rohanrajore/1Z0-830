package com.module08.bigdecimal;
import java.math.BigDecimal;
public class Exercise05_ComparisonsAndEquality {
    public static void main(String[] args) {
        // TODO:
        // 1) Create x = new BigDecimal("2.0") and y = new BigDecimal("2.00").
        // 2) Compare with equals (scale-sensitive) and compareTo (value-based).
        // 3) Use signum() to categorize -1, 0, 1 cases.
    }
}
