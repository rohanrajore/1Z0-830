package com.module01.java_structure;

// TODO: Use static imports for Math methods and constants to simplify calls like sqrt and PI.
// import static java.lang.Math.*;

public class Exercise7_StaticImportDemo {
    public static void main(String[] args) {
        // TODO: Compute hypotenuse for sides 3 and 4 using sqrt(3*3 + 4*4) and print PI
        // double hyp = sqrt(3*3 + 4*4);
        // System.out.println("hyp=" + hyp + ", PI=" + PI);
    }
}
