package com.module01.java_structure;

// TODO: Demonstrate wildcard import and a conflict scenario.
// Create two Date references: one from java.util and one from java.sql.
// Using 'import java.util.*;' and 'import java.sql.*;' together causes ambiguity for Date.

// import java.util.*;
// import java.sql.*;

public class Exercise5_WildcardImport {
    public static void main(String[] args) {
        // TODO: Show how to disambiguate with fully qualified names for Date
        // java.util.Date d1 = new java.util.Date();
        // java.sql.Date d2 = new java.sql.Date(System.currentTimeMillis());
        // System.out.println(d1 + " | " + d2);
    }
}
