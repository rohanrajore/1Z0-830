package com.module01.java_structure;
// TODO: Demonstrate conflict between java.util.Date and java.sql.Date.
// Import only one and use the other via fully qualified name to avoid ambiguity.

// import java.util.Date;

public class Exercise9_ImportConflictDemo {
    public static void main(String[] args) {
        // TODO: Date utilDate = new Date();
        // TODO: java.sql.Date sqlDate = new java.sql.Date(System.currentTimeMillis());
        // System.out.println(utilDate + " | " + sqlDate);
    }
}
