package com.module01.java_structure;

// TODO: Create two classes A and B in the same package. In B, use class A without import.
// Task: Compile both and instantiate A from B in main.

class A {
    String name() { return "A in same package"; }
}

public class Exercise3_ImportSamePackage {
    public static void main(String[] args) {
        // TODO: Create new A() and print A.name()
    }
}
