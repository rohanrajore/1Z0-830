package com.module01.java_structure;

// TODO: Create a simple class MainApp with a public static void main(String[] args)
// that prints "Hello, Packages!". Ensure the file path matches the package path.
// Task: Compile with: javac -d out src/com/learnato/training/structure/app/Exercise1_HelloPackage.java
// Run with: java -cp out com.learnato.training.structure.app.MainApp

public class Exercise1_HelloPackage { // TODO: Rename to MainApp and fix the filename accordingly
    // TODO: Implement main method to print the message
}
