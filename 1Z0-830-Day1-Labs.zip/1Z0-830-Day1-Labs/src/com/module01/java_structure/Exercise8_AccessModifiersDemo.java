package com.module01.java_structure;

// TODO: Create two classes in this package: PublicThing (public) and PackageThing (package-private).
// From a different package, try to instantiate both and observe which is accessible.

class PackageThing {
    String who() { return "package-private in same package"; }
}

public class Exercise8_AccessModifiersDemo {
    public static void main(String[] args) {
        System.out.println(new PackageThing().who());
    }
}
