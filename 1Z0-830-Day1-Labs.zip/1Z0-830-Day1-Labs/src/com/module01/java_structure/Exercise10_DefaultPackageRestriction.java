/* 
This exercise demonstrates that classes in the default package cannot be imported
by classes in a named package.

Steps:
1) Create a file in src/defaultpkg/DefaultHello.java WITHOUT a package declaration.
2) Try to import it from a class in package com.learnato.training.structure.defaultpkg.ImportDefault and observe the error.

Note: We provide the importing class below; you must create the default package class yourself.
*/
package com.module01.java_structure;

// TODO: Try: import DefaultHello; // This will NOT compile because default package is not importable.

public class Exercise10_DefaultPackageRestriction {
    public static void main(String[] args) {
        System.out.println("Default package classes cannot be imported into named packages.");
    }
}
