package com.module01.java_structure;

// TODO: Create two top-level classes in this file: One public and one package-private.
// Name the public class PublicEntry and the other Helper.
// Task: Ensure the filename is PublicEntry.java. Try making both classes public and observe the compiler error.

class Helper {
    // package-private utility
}

// TODO: Change the next class to 'public' and align the filename.
// public class PublicEntry {
class PublicEntry {
    public static void main(String[] args) {
        System.out.println("One public top-level class per file rule!");
    }
}
