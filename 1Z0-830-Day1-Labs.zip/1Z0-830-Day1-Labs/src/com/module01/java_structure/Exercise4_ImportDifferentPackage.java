package com.module01.java_structure;

// TODO: Use a class defined in com.learnato.training.structure.util package from here via explicit import.

// import com.learnato.training.structure.util.MessageUtil;

public class Exercise4_ImportDifferentPackage {
    public static void main(String[] args) {
        // TODO: Call MessageUtil.print("Hello from app via import")
        // If you don't import, try using fully qualified name.
    }
}
