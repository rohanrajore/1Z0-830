package com.module01.java_structure;

// TODO: Use classes without any imports by referencing their fully qualified names.

public class Exercise6_FullyQualifiedName {
    public static void main(String[] args) {
        // TODO: Create ArrayList via fully qualified name and add a string
        // java.util.ArrayList<String> list = new java.util.ArrayList<>();
        // list.add("FQN works without imports");
        // System.out.println(list.get(0));
    }
}
