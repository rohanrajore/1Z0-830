package com.module06.booleans;
public class Exercise03_OperatorPrecedence {
    // TODO:
    // Predict then compute these without extra parentheses:
    // a) true || false && false
    // b) !true || true && false
    // c) !(false || true) && true
    // d) true ? false || true : false && true  // ternary with booleans
    // Print all results.
    public static void main(String[] args) {
        boolean a = true || false && false;
        boolean b = !true || true && false;
        boolean c = !(false || true) && true;
        boolean d = true ? false || true : false && true;
        System.out.println("a=" + a + ", b=" + b + ", c=" + c + ", d=" + d);
    }
}
