package com.module06.booleans;
public class Exercise07_LoopConditions {
    // TODO:
    // 1) Use a while loop with boolean flags: keepGoing && i < 5
    // 2) Flip keepGoing to false when i reaches 3; verify short-circuit stops evaluation.
    // 3) Add print tracing for each iteration to observe evaluation order.
    public static void main(String[] args) {
        boolean keepGoing = true;
        int i = 0;
        while (keepGoing && i < 5) {
            System.out.println("Loop check: keepGoing=" + keepGoing + ", i=" + i);
            i++;
            if (i == 3) keepGoing = false;
        }
        System.out.println("Exited with i=" + i + ", keepGoing=" + keepGoing);
    }
}
