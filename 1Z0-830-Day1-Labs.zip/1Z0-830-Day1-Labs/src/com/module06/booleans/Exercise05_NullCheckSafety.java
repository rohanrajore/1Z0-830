package com.module06.booleans;
public class Exercise05_NullCheckSafety {
    static String mayReturnNull(boolean giveNull) {
        return giveNull ? null : "hello";
    }
    // TODO:
    // 1) Write: String s = mayReturnNull(true);
    // 2) Safely print length using short-circuit: if (s != null && s.length() > 0) ...
    // 3) Show that reversing operands causes NPE: if (s.length() > 0 && s != null) ... (leave commented)
    public static void main(String[] args) {
        // Your code here
    }
}
