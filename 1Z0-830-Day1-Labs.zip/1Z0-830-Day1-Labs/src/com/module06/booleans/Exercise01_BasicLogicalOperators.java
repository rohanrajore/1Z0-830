package com.module06.booleans;
public class Exercise01_BasicLogicalOperators {
    // TODO:
    // 1) Given ints a=5, b=10, c=-3, build boolean expressions using &&, ||, !
    //    - isBetween: a < b && b < 20
    //    - anyNegative: a < 0 || b < 0 || c < 0
    //    - noneZero: !(a == 0 || b == 0 || c == 0)
    // 2) Print each result.
    public static void main(String[] args) {
        int a = 5, b = 10, c = -3;
        // Your code here
    }
}
