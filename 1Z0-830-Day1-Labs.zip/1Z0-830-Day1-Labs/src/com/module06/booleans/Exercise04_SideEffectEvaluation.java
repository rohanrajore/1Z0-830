package com.module06.booleans;
public class Exercise04_SideEffectEvaluation {
    static int counter = 0;
    static boolean incAndReturn(String label, boolean v) {
        counter++;
        System.out.println("Step " + counter + ": " + label + " -> " + v);
        return v;
    }
    // TODO:
    // 1) Evaluate: incAndReturn("LHS", false) && incAndReturn("RHS", true)
    // 2) Reset counter and evaluate with &: incAndReturn("LHS", false) & incAndReturn("RHS", true)
    // 3) Repeat for || and | with a true LHS.
    public static void main(String[] args) {
        boolean x = incAndReturn("LHS(false)", false) && incAndReturn("RHS(true)", true);
        System.out.println("Result && = " + x + ", counter=" + counter);
        counter = 0;
        boolean y = incAndReturn("LHS(false)", false) & incAndReturn("RHS(true)", true);
        System.out.println("Result &  = " + y + ", counter=" + counter);

        counter = 0;
        boolean p = incAndReturn("LHS(true)", true) || incAndReturn("RHS(shouldSkip)", false);
        System.out.println("Result || = " + p + ", counter=" + counter);
        counter = 0;
        boolean q = incAndReturn("LHS(true)", true) | incAndReturn("RHS(evaluated)", false);
        System.out.println("Result |  = " + q + ", counter=" + counter);
    }
}
