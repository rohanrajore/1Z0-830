package com.module06.booleans;
public class Exercise06_TernaryIntegration {
    // TODO:
    // 1) Given score=72, print "PASS" if score>=60 else "FAIL" using ternary.
    // 2) Given flag=true, compute String msg = flag && (score > 70) ? "High Pass" : "Pass/Fail"; observe precedence.
    // 3) Add parentheses to make intent explicit.
    public static void main(String[] args) {
        int score = 72;
        boolean flag = true;
        // Your code here
    }
}
