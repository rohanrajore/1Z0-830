package com.module06.booleans;
public class Exercise08_TruthTableChallenge {
    // TODO:
    // 1) Generate a truth table for two booleans A,B over expression: (A && !B) || (!A && B)
    // 2) Print rows A, B, expr (this is XOR).
    public static void main(String[] args) {
        boolean[] vals = {false, true};
        System.out.println("A\tB\tExpr");
        for (boolean A : vals) {
            for (boolean B : vals) {
                boolean expr = (A && !B) || (!A && B);
                System.out.println(A + "\t" + B + "\t" + expr);
            }
        }
    }
}
