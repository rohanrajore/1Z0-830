package com.module06.booleans;
public class Exercise02_ShortCircuitDemo {
    static boolean probe(String label, boolean value) {
        System.out.println("Evaluating " + label + " -> " + value);
        return value;
    }
    // TODO:
    // 1) Compare short-circuit && vs non-short-circuit & using probe calls.
    // 2) Compare short-circuit || vs non-short-circuit |.
    // 3) Observe which operands are skipped due to short-circuiting.
    public static void main(String[] args) {
        System.out.println("-- && vs & --");
        boolean r1 = probe("A(false)", false) && probe("B(true)", true);
        System.out.println("Result r1=" + r1);
        boolean r2 = probe("C(false)", false) & probe("D(true)", true);
        System.out.println("Result r2=" + r2);

        System.out.println("-- || vs | --");
        boolean r3 = probe("E(true)", true) || probe("F(shouldSkip)", false);
        System.out.println("Result r3=" + r3);
        boolean r4 = probe("G(true)", true) | probe("H(evaluated)", false);
        System.out.println("Result r4=" + r4);
    }
}
