package com.module04.var_exercises;

import java.util.ArrayList;
import java.util.List;

public class Exercise3_VarAssignment {
    public static void main(String[] args) {
        var list = new ArrayList<String>();
        list.add("Java");

        // TODO: Try: list = new ArrayList<Integer>();  // Expect a compile error. Why?
        // TODO: Create a second variable with a wider compile-time type that allows reassignment:
        // List<?> any = list; // then reassign any = new ArrayList<Integer>();
        // Explain why this compiles and what the trade-offs are.
    }
}
