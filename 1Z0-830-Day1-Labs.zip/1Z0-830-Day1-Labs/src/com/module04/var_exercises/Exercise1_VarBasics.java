package com.module04.var_exercises;

public class Exercise1_VarBasics {
    public static void main(String[] args) {
        var a = 10;       // TODO: What is the inferred type?
        var b = 10.5;     // TODO: What is the inferred type?
        var c = 'A';      // TODO: What type is inferred here?

        // TODO: Print the runtime class name for a, b, c.
        // Hint: primitives don't have getClass(); wrap them or use ((Object) value).getClass().getName()
        // Example: System.out.println(((Object)a).getClass().getName());
    }
}
