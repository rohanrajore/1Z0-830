package com.module04.var_exercises;

import java.util.*;

public class Exercise5_VarAmbiguity {
    public static void main(String[] args) {
        var map = new HashMap<>();   // TODO: What is the inferred type?
        map.put("A", 10);
        // TODO: Retrieve value using var and check what methods are available (IDE intellisense).
        // var v = map.get("A");

        // TODO: Change declaration to: var map2 = new HashMap<String, Integer>();
        // What difference do you observe when calling map2.get()?

        var value = 1 + 2.5;  // TODO: What is inferred type and why?
        // Bonus: var result = 1 / 2; // What is the inferred type and printed value?
    }
}
