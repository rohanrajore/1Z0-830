package com.module04.var_exercises;

import java.util.List;

public class Exercise2_VarInLoop {
    public static void main(String[] args) {
        var numbers = List.of(10, 20, 30);

        // TODO: Use var in an enhanced for loop to print each element.
        // for (var n : numbers) { ... }

        // TODO: Replace var with Object in the loop. What changes? Any casts needed? Why/why not?

        // TODO: Use var in a lambda parameter (Java 11+):
        // numbers.forEach((var x) -> System.out.println(x));
        // Why are parentheses required when using 'var' in lambda parameters?
    }
}
