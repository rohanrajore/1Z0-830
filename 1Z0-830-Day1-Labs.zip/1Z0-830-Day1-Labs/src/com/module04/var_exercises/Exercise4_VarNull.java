package com.module04.var_exercises;

public class Exercise4_VarNull {
    public static void main(String[] args) {
        // TODO: Uncomment and see the compiler error
        // var name = null;   // Why can't 'var' infer a type from null?

        Object obj = null;
        var alias = obj;      // TODO: What type is inferred for alias?
        // TODO: Now try printing alias.getClass().getName() and observe what happens at runtime.
        // Explain the difference between compile-time type inference and runtime null value.
    }
}
