package com.module03.wrapper_autoboxing;

import java.util.ArrayList;
import java.util.List;

public class Exercise5_CollectionBoxing {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();
        // TODO: Add primitive ints directly to list. How does this work internally?
        for (int i = 0; i < 5; i++) {
            list.add(i);
        }

        // TODO: Sum all values using Integer temp variable — observe unboxing.
        Integer sum = 0;
        for (Integer val : list) {
            sum += val;
        }
        System.out.println("Sum: " + sum);

        // TODO: Try adding a null to the list and summing again. What happens?
    }
}
