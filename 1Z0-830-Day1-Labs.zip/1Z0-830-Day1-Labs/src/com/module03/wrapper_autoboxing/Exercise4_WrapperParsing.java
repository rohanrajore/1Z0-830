package com.module03.wrapper_autoboxing;

public class Exercise4_WrapperParsing {
    public static void main(String[] args) {
        String numStr = "200";
        String boolStr = "TrUe";
        // TODO: Convert numStr to Integer using parseInt and valueOf.
        // What's the difference between the two methods?

        // TODO: Parse boolStr into a boolean. What happens if you pass "Yes"?

        // TODO: Convert double primitive to Double wrapper and back to String in one line.

        // TODO: Observe how null behaves in parse methods — is it allowed?
    }
}
