package com.module03.wrapper_autoboxing;

public class Exercise10_BoxingGC {
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            Integer x = i;   // autoboxing
            // TODO: Print x using System.identityHashCode(x)
            // Observe new object creation for values beyond caching range.
        }

        // TODO: Discuss when wrappers become eligible for GC in a loop.
        // What happens if caching is applied vs not applied?
    }
}
