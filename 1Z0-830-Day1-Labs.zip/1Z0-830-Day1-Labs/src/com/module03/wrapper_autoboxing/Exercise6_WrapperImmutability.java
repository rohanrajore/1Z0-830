package com.module03.wrapper_autoboxing;

public class Exercise6_WrapperImmutability {
    public static void main(String[] args) {
        Integer a = 5;
        Integer b = a;
        a++;
        // TODO: Print a and b. Are both updated? Why not?
        // Explain how autoboxing creates new objects during increment.
    }
}
