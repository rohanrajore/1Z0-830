package com.module03.wrapper_autoboxing;

public class Exercise2_WrapperCache {
    public static void main(String[] args) {
        Integer i1 = 127;
        Integer i2 = 127;
        Integer i3 = 128;
        Integer i4 = 128;

        // TODO: Print (i1 == i2) and (i3 == i4). Why are results different?
        // What caching range does Integer maintain internally?

        Boolean b1 = Boolean.valueOf(true);
        Boolean b2 = Boolean.TRUE;
        // TODO: Check (b1 == b2). What about (b1.equals(b2))?

        // TODO: Try with Character wrappers — which range is cached?
    }
}
