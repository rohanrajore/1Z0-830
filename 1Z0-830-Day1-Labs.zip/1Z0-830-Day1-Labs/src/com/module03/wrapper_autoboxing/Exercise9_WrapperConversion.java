package com.module03.wrapper_autoboxing;

public class Exercise9_WrapperConversion {
    public static void main(String[] args) {
        Double d = 9.99;
        int val = d.intValue();  // TODO: What happens here?
        // Print and discuss truncation vs rounding.

        Float f = Float.NaN;
        // TODO: Compare f == Float.NaN. What’s the result and why?
        // Correct approach?

        Double inf = Double.POSITIVE_INFINITY;
        // TODO: Compare (inf > 1e308). Why true/false?
    }
}
