package com.module03.wrapper_autoboxing;

public class Exercise3_WrapperMix {
    public static void main(String[] args) {
        Integer i = 10;
        Double d = 20.5;
        // TODO: Perform i + d and print result. What type is inferred after unboxing?
        
        Float f = 12.3f;
        // TODO: Perform f + i. Explain automatic unboxing and promotion sequence.

        Character c = 'A';
        int result = c + 1; // TODO: Predict the value and resulting character
        System.out.println("Character arithmetic int value: " + result);
    }
}
