package com.module03.wrapper_autoboxing;

public class Exercise7_WrapperIdentity {
    public static void main(String[] args) {
        Integer i1 = 100;
        Integer i2 = i1 + 0;
        // TODO: Check (i1 == i2). Is caching applied when arithmetic is involved?

        Long l1 = 100L;
        Long l2 = i1 + 0L;
        // TODO: Compare (l1 == l2). What happens due to numeric promotion?
    }
}
