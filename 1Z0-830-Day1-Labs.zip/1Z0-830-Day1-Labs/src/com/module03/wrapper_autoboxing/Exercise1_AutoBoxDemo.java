package com.module03.wrapper_autoboxing;

public class Exercise1_AutoBoxDemo {
    public static void main(String[] args) {
        Integer a = 1000;
        Integer b = 1000;
        // TODO: Compare (a == b) and (a.equals(b)).
        // Explain why results differ despite same values.

        Integer x = 10;
        int y = 10;
        // TODO: Compare (x == y). Why does this compile and what happens at runtime?

        // TODO: What happens if you unbox a null value? Try it:
        // Integer z = null;
        // int n = z; // Uncomment and observe
    }
}
