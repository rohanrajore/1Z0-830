package com.module03.wrapper_autoboxing;

public class Exercise8_NullUnboxing {
    static Integer counter;
    public static void main(String[] args) {
        // TODO: Increment counter with ++ and observe the result.
        // Why does it throw an exception?
        
        // TODO: Add null-safe logic using ternary or Optional to handle this safely.
    }
}
