package com.module02.primitives;

public class Exercise6_UnderscoreNotation {
    public static void main(String[] args) {
        // TODO: Use underscores in numeric literals correctly and incorrectly.
        // Valid: int million = 1_000_000;
        // Invalid (uncomment one by one and note compile errors):
        // int x = _100;
        // int y = 100_;
        // double z = 10._5;
        // double w = 10_.5;
        // int base = 0x_1F;
        // Explain each error.
    }
}
