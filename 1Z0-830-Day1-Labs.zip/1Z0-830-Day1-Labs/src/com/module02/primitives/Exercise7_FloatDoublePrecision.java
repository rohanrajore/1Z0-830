package com.module02.primitives;

public class Exercise7_FloatDoublePrecision {
    public static void main(String[] args) {
        float f = 0.1f;
        double d = 0.1;
        // TODO: Print f and d with many decimals (use String.format).
        // TODO: Compare 0.1 + 0.2 == 0.3 for double and print result.
        // TODO: Show float to double promotion and its effect.
    }
}
