package com.module02.primitives;

public class Exercise10_BooleanDemo {
    public static void main(String[] args) {
        boolean flag = true;
        // TODO: Show boolean literals and simple logical operations.
        // Print results of &&, ||, ! and compare precedence by adding parentheses.
    }
}
