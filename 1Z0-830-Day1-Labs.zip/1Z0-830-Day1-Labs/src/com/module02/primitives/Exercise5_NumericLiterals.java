package com.module02.primitives;

public class Exercise5_NumericLiterals {
    public static void main(String[] args) {
        // TODO: Declare the same number (e.g., 42) in decimal, binary, octal, and hex.
        // int dec = 42;
        // int bin = 0b101010;
        // int oct = 052;
        // int hex = 0x2A;
        // Print and verify all are equal.
    }
}
