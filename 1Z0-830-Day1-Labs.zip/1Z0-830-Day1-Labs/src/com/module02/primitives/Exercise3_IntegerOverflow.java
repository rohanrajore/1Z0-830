package com.module02.primitives;

public class Exercise3_IntegerOverflow {
    public static void main(String[] args) {
        int max = Integer.MAX_VALUE;
        // TODO: Compute max + 1 and print result.
        // Then use Math.addExact(max, 1) inside try/catch to detect overflow.
    }
}
