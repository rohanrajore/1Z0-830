package com.module02.primitives;

public class Exercise4_DefaultValues {
    // TODO: Declare primitive FIELDS (not locals) to demonstrate default values.
    static byte b;
    static short s;
    static int i;
    static long l;
    static float f;
    static double d;
    static char c;
    static boolean bool;

    public static void main(String[] args) {
        // TODO: Print field defaults.
        // TODO: Create LOCAL primitives without initialization and try to print them -> compile error.
        // int local; System.out.println(local); // Uncomment and observe compilation failure
        System.out.println("Use comments to record the compiler error message for locals.");
    }
}
