package com.module02.primitives;

public class Exercise8_CastingAndPromotion {
    public static void main(String[] args) {
        byte b = 50;
        byte b2 = 70;
        // TODO: Add two bytes and store back to byte (requires cast); explain why.
        // byte sum = (byte)(b + b2);

        char ch = 'A';
        int code = ch; // TODO: implicit widening char -> int
        // TODO: Narrow back to char after arithmetic: char next = (char)(code + 1);
    }
}
