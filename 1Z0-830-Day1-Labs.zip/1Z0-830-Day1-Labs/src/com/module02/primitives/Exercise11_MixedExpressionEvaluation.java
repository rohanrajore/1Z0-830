package com.module02.primitives;

public class Exercise11_MixedExpressionEvaluation {
    public static void main(String[] args) {
        byte b = 1;
        short s = 2;
        char c = 'A'; // 65
        // TODO: Evaluate b + s + c and store in an int; explain type promotion chain.
        // int res = b + s + c;
        // TODO: Cast result back to short and observe potential overflow using large values.
    }
}
