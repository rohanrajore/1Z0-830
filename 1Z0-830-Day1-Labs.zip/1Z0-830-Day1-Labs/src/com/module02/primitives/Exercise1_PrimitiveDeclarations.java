package com.module02.primitives;

public class Exercise1_PrimitiveDeclarations {
    // TODO: Declare one variable of each primitive type and assign literal values:
    // byte, short, int, long, float, double, char, boolean
    // Use at least one suffix: L for long, F for float, D optional for double.
    public static void main(String[] args) {
        // TODO: Print each variable and comment its type and size in bits.
    }
}
