package com.module02.primitives;

public class Exercise9_CharUnicodeDemo {
    public static void main(String[] args) {
        // TODO: Initialize char three ways: literal, decimal code point, Unicode escape.
        // char a = 'A';
        // char b = 65;
        // char c = '\u0041';
        // Print all and confirm equality.
        // TODO: Show surrogate pair example using code point API: new String(Character.toChars(0x1F600))
    }
}
