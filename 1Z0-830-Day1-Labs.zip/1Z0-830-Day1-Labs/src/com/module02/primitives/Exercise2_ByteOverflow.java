package com.module02.primitives;

public class Exercise2_ByteOverflow {
    public static void main(String[] args) {
        byte b = 120;
        // TODO: Add 10 to b safely and observe overflow when casting back to byte.
        // Show: byte sum = (byte)(b + 10);
        // Print before/after and explain why overflow occurs.
    }
}
