package com.module05.operators;
public class Exercise07_EqualityOnPrimitives {
    // TODO: Compare primitives with == and !=. Show float/double traps with NaN.
    public static void main(String[] args) {
        double n = Double.NaN;
        // TODO: Print (n == n), (Double.isNaN(n)).
        // TODO: Compare 0.0 == -0.0 and 1.0/0 == -1.0/0 (Infinity vs -Infinity).
    }
}
