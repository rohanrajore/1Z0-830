package com.module05.operators;
public class Exercise10_BitwiseAND_OR_XOR {
    // TODO: Use &, |, ^ on int and long bit patterns and print binary.
    public static void main(String[] args) {
        int a = 0b0101, b = 0b0011;
        long x = 0b1010L, y = 0b1100L;
        // TODO: Print results of a&b, a|b, a^b; same for longs, with binary strings.
    }
}
