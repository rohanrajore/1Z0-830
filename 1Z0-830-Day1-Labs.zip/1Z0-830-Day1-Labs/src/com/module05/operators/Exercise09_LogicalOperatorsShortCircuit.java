package com.module05.operators;
public class Exercise09_LogicalOperatorsShortCircuit {
    // TODO: Demonstrate short-circuiting vs non-short-circuit (&, |) with side effects.
    static boolean test(String label, boolean v) {
        System.out.println(label);
        return v;
    }
    public static void main(String[] args) {
        // TODO: Observe order and side effects: test("A", false) && test("B", true)
        // TODO: Compare with '&': test("C", false) & test("D", true)
    }
}
