package com.module05.operators;
public class Exercise08_EqualityOnObjects {
    // TODO: Show reference equality vs value equality.
    public static void main(String[] args) {
        String a = new String("java");
        String b = new String("java");
        String c = "java";
        String d = "java";
        // TODO: Print a==b, a.equals(b), c==d, c.equals(d).
        // Explain string pool and new String() behavior.
    }
}
