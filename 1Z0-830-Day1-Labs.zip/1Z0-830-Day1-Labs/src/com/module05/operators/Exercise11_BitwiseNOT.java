package com.module05.operators;
public class Exercise11_BitwiseNOT {
    // TODO: Emphasize ~ operator effects on sign bits with int and long.
    public static void main(String[] args) {
        int i = 0;
        long l = -1L;
        // TODO: Print ~i and ~l; discuss two's complement width (32 vs 64 bits).
    }
}
