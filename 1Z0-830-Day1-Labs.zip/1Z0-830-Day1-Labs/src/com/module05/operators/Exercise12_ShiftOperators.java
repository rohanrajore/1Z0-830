package com.module05.operators;
public class Exercise12_ShiftOperators {
    // TODO: Demonstrate << and >> on positive and negative int/long.
    public static void main(String[] args) {
        int a = 0b0001_0000; // 16
        int b = -16;
        long L = 16L;
        // TODO: Print a<<2, a>>2; b<<1, b>>1; L<<3, L>>3 with values and binary.
    }
}
