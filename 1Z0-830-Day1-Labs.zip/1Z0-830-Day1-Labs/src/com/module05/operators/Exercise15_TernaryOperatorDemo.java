package com.module05.operators;
public class Exercise15_TernaryOperatorDemo {
    // TODO: Use ternary with different branches and show type unification.
    public static void main(String[] args) {
        int x = -1;
        // TODO: String label = x > 0 ? "positive" : x == 0 ? "zero" : "negative";
        // TODO: Number n = true ? 1 : 1.5; // what is the resulting type?
        // Discuss numeric promotion rules inside ternary.
    }
}
