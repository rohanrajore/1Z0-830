package com.module05.operators;
public class Exercise06_RelationalComparisons {
    // TODO: Use <, <=, >, >= with ints, doubles, chars. Show invalid with booleans.
    public static void main(String[] args) {
        char a = 'a', b = 'b';
        // TODO: Compare a < b, 'A' < 'a', and 10.0 == 10.
        // TODO: Attempt true < false (commented) and note compile error.
    }
}
