package com.module05.operators;
public class Exercise03_UnaryIncrementDemo {
    // TODO: Compare pre-increment (++i) and post-increment (i++ ) in expressions.
    public static void main(String[] args) {
        int i = 1;
        // TODO: Evaluate: int r = i++ + ++i; print i and r. Trace steps.
        // TODO: Repeat with i reset and a more complex chain.
    }
}
