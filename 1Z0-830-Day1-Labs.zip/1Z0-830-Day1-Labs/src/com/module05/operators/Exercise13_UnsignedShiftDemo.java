package com.module05.operators;
public class Exercise13_UnsignedShiftDemo {
    // TODO: Demonstrate >>> on negative int and long to show zero-fill right shift.
    public static void main(String[] args) {
        int n = -1;   // all bits 1 in 32-bit
        long m = -1L; // all bits 1 in 64-bit
        // TODO: Print n>>>1 and m>>>1 with binary; compare to >> (sign-propagating).
    }
}
