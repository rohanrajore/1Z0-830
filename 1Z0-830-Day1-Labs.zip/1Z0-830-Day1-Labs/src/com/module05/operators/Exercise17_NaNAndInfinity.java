package com.module05.operators;
public class Exercise17_NaNAndInfinity {
    // TODO: Compare doubles involving NaN, Infinity and -Infinity.
    public static void main(String[] args) {
        double inf = Double.POSITIVE_INFINITY;
        double ninf = Double.NEGATIVE_INFINITY;
        double nan = Double.NaN;
        // TODO: Print comparisons: inf > 1e308, ninf < -1e308, nan == nan, Double.isNaN(nan)
        // TODO: Print 0.0/0.0 and 1.0/0.0 results.
    }
}
