package com.module05.operators;
public class Exercise02_DivisionModuloEdge {
    // TODO: Explore division by zero behavior for int vs double.
    public static void main(String[] args) {
        int a = 1;
        double d = 1.0;
        // TODO: Try: a / 0 (compile/run), d / 0.0, and 0.0/0.0. Capture outcomes and exceptions.
    }
}
