package com.module05.operators;
public class Exercise16_OperatorPrecedenceChallenge {
    // TODO: Predict outcomes without parenthesis, then add parentheses and compare.
    public static void main(String[] args) {
        int r1 = 2 + 3 * 4 / 2;
        int r2 = (2 + 3) * (4 / 2);
        boolean r3 = true || false && false;
        boolean r4 = (true || false) && false;
        // TODO: Print r1..r4 and explain precedence and associativity.
    }
}
