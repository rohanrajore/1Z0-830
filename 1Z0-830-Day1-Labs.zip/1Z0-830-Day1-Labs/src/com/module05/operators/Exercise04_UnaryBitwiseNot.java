package com.module05.operators;
public class Exercise04_UnaryBitwiseNot {
    // TODO: Use bitwise NOT (~) on int and long and show two's-complement results.
    public static void main(String[] args) {
        int x = 0b0000_1111;
        long L = 0x00FF_FFFFL;
        // TODO: Print ~x and ~L in decimal and binary strings (Integer.toBinaryString / Long.toBinaryString).
    }
}
