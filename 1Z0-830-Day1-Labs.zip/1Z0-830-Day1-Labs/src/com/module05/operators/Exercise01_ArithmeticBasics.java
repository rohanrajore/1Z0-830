package com.module05.operators;

public class Exercise01_ArithmeticBasics {
    // TODO: Use +, -, *, /, % on ints and doubles. Show integer truncation and modulo on negatives.
    public static void main(String[] args) {
        int a = 7, b = 3;
        double x = 7, y = 3;
        // TODO: Print a/b and x/y; explain truncation vs floating division.
        // TODO: Print 10 % 3, 10 % -3, -10 % 3, -10 % -3 and discuss sign rules.
    }
}
