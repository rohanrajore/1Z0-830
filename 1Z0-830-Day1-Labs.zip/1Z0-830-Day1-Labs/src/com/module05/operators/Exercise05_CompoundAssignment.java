package com.module05.operators;
public class Exercise05_CompoundAssignment {
    // TODO: Show that b += 10 compiles for byte, while b = b + 10 needs cast.
    public static void main(String[] args) {
        byte b = 5;
        // TODO: b += 10; // ok
        // TODO: b = (byte)(b + 10); // required cast
        // Explain implicit cast in compound assignments.
    }
}
