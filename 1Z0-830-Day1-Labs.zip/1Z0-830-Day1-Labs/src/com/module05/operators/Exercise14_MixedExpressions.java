package com.module05.operators;
public class Exercise14_MixedExpressions {
    // TODO: Combine bitwise and logical conditions.
    public static void main(String[] args) {
        int v = 10;
        // even and positive test using bitwise + logical
        // TODO: boolean isEvenAndPositive = ((v & 1) == 0) && v > 0;
        // Print result.
    }
}
