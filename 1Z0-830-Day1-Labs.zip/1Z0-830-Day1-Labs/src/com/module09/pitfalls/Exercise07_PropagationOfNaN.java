package com.module09.pitfalls;
public class Exercise07_PropagationOfNaN {
    // TODO:
    // 1) Let x = Double.NaN; print x == x, Double.isNaN(x).
    // 2) Print x + 5, Math.sqrt(x), x * 0.
    // 3) Use Double.compare(x, x) and explain result.
    public static void main(String[] args) {
        // Your code here
    }
}
