package com.module09.pitfalls;
public class Exercise02_IntegerDivisionPrecisionLoss {
    // TODO:
    // 1) For a=7, b=3, print a/b and (double)a/b.
    // 2) Show (a/b)*1.0 vs a*1.0/b; explain difference.
    public static void main(String[] args) {
        int a = 7, b = 3;
        // Your code here
    }
}
