package com.module09.pitfalls;
public class Exercise03_ModuloWithNegatives {
    // TODO:
    // 1) Print 5 % -2, -5 % 2, -5 % -2 and explain sign of the result.
    // 2) Show that (a/b)*b + a%b == a for sample values.
    public static void main(String[] args) {
        // Your code here
    }
}
