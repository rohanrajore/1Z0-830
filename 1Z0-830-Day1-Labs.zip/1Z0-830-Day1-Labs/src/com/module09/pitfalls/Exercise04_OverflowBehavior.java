package com.module09.pitfalls;
public class Exercise04_OverflowBehavior {
    // TODO:
    // 1) Print Integer.MAX_VALUE and Integer.MIN_VALUE.
    // 2) Compute max+1 and min-1; observe wrap-around.
    // 3) Repeat for long.
    public static void main(String[] args) {
        // Your code here
    }
}
