package com.module09.pitfalls;
public class Exercise06_InfinityAndNaNOperations {
    // TODO:
    // 1) Print 5.0/0.0, -5.0/0.0, 0.0/0.0 results.
    // 2) Use Double.isInfinite and Double.isNaN to classify.
    public static void main(String[] args) {
        // Your code here
    }
}
