package com.module09.pitfalls;
public class Exercise08_MixedArithmeticEdgeCases {
    // TODO:
    // 1) Mix int, long, double in expressions: Integer.MAX_VALUE + 10L, Integer.MAX_VALUE + 10.0
    // 2) Compute (long)Integer.MAX_VALUE + 1 and compare to (int)((long)Integer.MAX_VALUE + 1).
    // 3) Show (1.0/0.0) + (-1.0/0.0) and 0.0/0.0.
    public static void main(String[] args) {
        // Your code here
    }
}
