package com.module09.pitfalls;
public class Exercise01_IntegerDivisionBasics {
    // TODO:
    // 1) Compute and print 5/2, -5/2, 5/-2, -5/-2 (int division).
    // 2) Compare to 5/2.0 and -5/2.0 (double).
    // 3) Add prints that show the expression and the result.
    public static void main(String[] args) {
        // Your code here
    }
}
