package com.module09.pitfalls;
public class Exercise05_OverflowDetectionAPI {
    // TODO:
    // 1) Use Math.addExact(Integer.MAX_VALUE, 1) inside try/catch and print the exception.
    // 2) Use Math.multiplyExact(100_000, 100_000) and catch overflow.
    // 3) Show negateExact(Integer.MIN_VALUE) exception.
    public static void main(String[] args) {
        // Your code here
    }
}
