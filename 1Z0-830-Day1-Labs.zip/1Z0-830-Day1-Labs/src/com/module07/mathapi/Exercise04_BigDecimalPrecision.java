package com.module07.mathapi;
import java.math.BigDecimal;
import java.math.RoundingMode;
public class Exercise04_BigDecimalPrecision {
    // TODO: Create BigDecimal from String for 0.1 and 0.2 and add accurately.
    // TODO: Demonstrate setScale with RoundingMode.HALF_UP, HALF_EVEN, DOWN on 2.675 to 2 decimals.
    // TODO: Show difference between new BigDecimal(0.1) vs new BigDecimal("0.1").
    public static void main(String[] args) {
        // Your code here
    }
}
