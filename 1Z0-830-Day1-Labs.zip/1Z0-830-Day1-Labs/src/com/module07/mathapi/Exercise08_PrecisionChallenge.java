package com.module07.mathapi;
import java.math.BigDecimal;
import java.math.RoundingMode;
public class Exercise08_PrecisionChallenge {
    // Compound interest: principal=1000, rate=5% annually, years=10.
    // TODO: Compute with double and print final amount.
    // TODO: Compute with BigDecimal using HALF_UP and HALF_EVEN; set scale to 2 at each year.
    // Compare results after 10 years.
    public static void main(String[] args) {
        // Your code here
    }
}
