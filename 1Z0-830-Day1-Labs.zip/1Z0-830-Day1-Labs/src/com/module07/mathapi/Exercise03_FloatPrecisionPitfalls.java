package com.module07.mathapi;
public class Exercise03_FloatPrecisionPitfalls {
    // TODO: Show that 0.1 + 0.2 != 0.3 for double.
    // TODO: Print with 20 decimal places using String.format.
    // TODO: Compare float 0.1f + 0.2f to 0.3f.
    public static void main(String[] args) {
        // Your code here
    }
}
