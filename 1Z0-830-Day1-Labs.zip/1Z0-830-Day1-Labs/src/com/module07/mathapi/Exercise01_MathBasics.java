package com.module07.mathapi;
public class Exercise01_MathBasics {
    // TODO: Print Math.PI and Math.E with high precision.
    // TODO: Compute hypotenuse using Math.sqrt and Math.pow for sides 5 and 12.
    // TODO: Use Math.abs on negative zero (-0.0) and compare to 0.0.
    public static void main(String[] args) {
        // Your code here
    }
}
