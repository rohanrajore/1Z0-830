package com.module07.mathapi;
public class Exercise05_TruncationVsRounding {
    // TODO: For x = 3.7 and y = -3.7, compare (int)x, Math.floor(x), Math.round(x) and same for y.
    // Document differences especially for negatives.
    public static void main(String[] args) {
        // Your code here
    }
}
