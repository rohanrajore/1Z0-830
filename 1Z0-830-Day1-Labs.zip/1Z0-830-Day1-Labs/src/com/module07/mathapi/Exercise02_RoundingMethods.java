package com.module07.mathapi;
public class Exercise02_RoundingMethods {
    // TODO: For values 2.5, 2.49, -2.5, -2.51 print Math.round, Math.floor, Math.ceil, Math.rint.
    // Observe bankers rounding behavior for rint (ties to even).
    public static void main(String[] args) {
        double[] vals = {2.5, 2.49, -2.5, -2.51};
        // Your code here
    }
}
