package com.module07.mathapi;
public class Exercise07_MathFunctionsMixedTypes {
    // TODO: Use Math.max and Math.min mixing int and double; observe promotion.
    // TODO: Compute pow(2, 10) and pow(9, 0.5) then compare to sqrt(9).
    // TODO: Use copySign to transfer sign from -0.0 to +3.5.
    public static void main(String[] args) {
        // Your code here
    }
}
