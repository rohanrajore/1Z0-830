package com.module07.mathapi;
import java.util.Random;
public class Exercise06_RandomNumbers {
    // TODO: Use Math.random() to generate an int in [1, 6] (dice).
    // TODO: Use Random with a fixed seed to generate 3 reproducible ints in [0, 100).
    // TODO: Show difference between nextInt(bound) and scaling Math.random().
    public static void main(String[] args) {
        // Your code here
    }
}
